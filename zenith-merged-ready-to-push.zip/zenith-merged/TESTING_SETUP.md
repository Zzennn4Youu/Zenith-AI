# Automated Tests — Setup Guide

## What's covered

Three pure-logic modules got extracted out of components/routes specifically
so they're unit-testable without a browser/React/Next.js runtime:

| Module | Extracted from | What it tests |
|---|---|---|
| `lib/portfolio/pnl.js` | `components/PortfolioDashboard.jsx` | P&L math — includes a regression test locking in the moving-average-cost-basis fix from earlier this session |
| `lib/alerts/backtestEngine.js` | `app/api/alerts/backtest/route.js` | Crossing-detection + forward-outcome logic |
| `lib/orchestrator/modelTierDefs.js` | `lib/orchestrator/modelTiers.js` | Tier classification + reasoning-param building |

Each has a matching `.test.js` file next to it. All 31 tests pass, verified
by actually running them (not just written and assumed correct) — one test
even caught a wrong assumption of my own on the first run (see below).

## What this doesn't cover

Everything with a real I/O dependency — Supabase queries, MEXC API calls,
`runMTFAnalysis`, the Midtrans webhook, React component rendering. Those
need either mocking (more setup) or integration tests against a real/staging
database — a reasonable next step, not done here.

## Running them

These use Node's **built-in** test runner (`node:test` + `node:assert`) —
zero new dependencies. Two ways to run, depending on whether your
`package.json` has `"type": "module"` set:

**If it does** (or you're not sure — try this first):
```bash
node --test
```
Auto-discovers every `*.test.js` file recursively from wherever you run it.

**If Node complains about `import`/`export` syntax:**
Either add `"type": "module"` to `package.json` (harmless for a Next.js
project — Next's own bundler doesn't care either way), or rename the test
files to `.test.mjs` instead, which forces ESM regardless of that setting.

**If your project already uses Jest** (worth checking — an earlier phase
mentioned a 48-test suite across 7 suites): these are trivial to port —
swap `import { test, describe } from 'node:test'` for Jest's globals, and
`assert.equal(a, b)` → `expect(a).toBe(b)`. The test logic itself doesn't
change, just the two lines of boilerplate per file.

## The one thing the tests already caught

`backtestEngine.test.js` initially asserted that a `price_above` alert
should never fire if price starts (and stays) above the threshold. That
assumption was wrong: the very first candle checked always "crosses" from
AlertChecker's `-Infinity` sentinel value, matching what a brand-new alert
does in production if the condition is already true the moment it's
created. Not a bug — the test was asserting the wrong thing, now fixed. Worth
knowing either way: any backtest's first fire event is often just this
sentinel effect at the start of the lookback window, not a "real" signal.
