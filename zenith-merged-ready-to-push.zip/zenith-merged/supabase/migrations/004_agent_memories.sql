-- ─────────────────────────────────────────────────────────────────────────────
-- AGENT MEMORIES — cross-session persistent context for Zenith AI v2
-- Run: supabase db push  (or paste in SQL editor)
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS agent_memories (
  id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  agent_id      TEXT,                                  -- agent that created this memory
  type          TEXT        NOT NULL DEFAULT 'fact'
                            CHECK (type IN (
                              'fact',         -- explicit user facts (portfolio, goals)
                              'preference',   -- user style / risk / format preferences
                              'task_summary', -- summary of a completed orchestration run
                              'insight',      -- market / analysis observations
                              'pattern'       -- recurring user behaviour patterns
                            )),
  content       TEXT        NOT NULL,
  tags          TEXT[]      DEFAULT '{}',
  metadata      JSONB       DEFAULT '{}',  -- { source_task_id, symbol, confidence, ... }
  importance    SMALLINT    DEFAULT 5 CHECK (importance BETWEEN 1 AND 10),
  access_count  INT         DEFAULT 0,
  last_accessed TIMESTAMPTZ,
  expires_at    TIMESTAMPTZ,               -- NULL = never expires
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_am_user_type
  ON agent_memories (user_id, type);

CREATE INDEX IF NOT EXISTS idx_am_user_importance
  ON agent_memories (user_id, importance DESC, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_am_tags
  ON agent_memories USING GIN (tags);

CREATE INDEX IF NOT EXISTS idx_am_expires
  ON agent_memories (expires_at)
  WHERE expires_at IS NOT NULL;

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS agent_memories_updated_at ON agent_memories;
CREATE TRIGGER agent_memories_updated_at
  BEFORE UPDATE ON agent_memories
  FOR EACH ROW EXECUTE PROCEDURE touch_updated_at();

-- RLS: each user owns only their memories
ALTER TABLE agent_memories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users_own_memories" ON agent_memories;
CREATE POLICY "users_own_memories" ON agent_memories
  FOR ALL USING (auth.uid() = user_id);
