-- 017_execution_log.sql
-- Creates the table logEvent() has been trying to write to. See
-- EXECUTION_LOG_REMEDIATION.md for the full field-by-field rationale.

CREATE TABLE execution_log (
  id                     BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  orchestration_task_id  UUID NOT NULL,
  user_id                UUID REFERENCES auth.users(id),
  agent_name             TEXT NOT NULL,
  event_type             TEXT NOT NULL,
  event_description      TEXT,
  metadata               JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_execution_log_task_id ON execution_log (orchestration_task_id);
CREATE INDEX idx_execution_log_created_at ON execution_log (created_at);

-- Operational/diagnostic table, not user-facing. RLS enabled but no
-- anon/authenticated policies — fail-closed by default, same pattern as
-- action_rate_limit_log. Written only by a service-role client (see the
-- logEvent() change in OrchestratorV3.js — not included in this file,
-- still pending your go-ahead), which bypasses RLS entirely.
ALTER TABLE execution_log ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON execution_log FROM PUBLIC, anon, authenticated;
