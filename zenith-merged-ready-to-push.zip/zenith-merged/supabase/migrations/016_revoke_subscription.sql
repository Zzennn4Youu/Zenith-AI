-- Symmetric counterpart to extend_subscription(): subtracts days instead of
-- adding them, for when a previously-settled payment is later refunded or
-- charged back. Subtracting (rather than just flipping tier to 'free'
-- outright) correctly preserves any OTHER separately-paid period the user
-- might have — e.g. if they paid twice and only one payment gets refunded,
-- the other legitimately-paid days remain intact instead of being wiped.

CREATE OR REPLACE FUNCTION revoke_subscription(p_user_id UUID, p_days INT)
RETURNS TIMESTAMPTZ
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_expiry TIMESTAMPTZ;
BEGIN
  UPDATE user_subscriptions
  SET expires_at = COALESCE(expires_at, NOW()) - (p_days || ' days')::INTERVAL,
      updated_at = NOW()
  WHERE user_id = p_user_id
  RETURNING expires_at INTO new_expiry;

  -- If this revocation pushed them into the past (or they had no future
  -- expiry to begin with), downgrade to free immediately rather than
  -- leaving a stale 'paid' tier with a lapsed date sitting in the table —
  -- resolveModelForUser() already checks expires_at live, so this is a
  -- data-hygiene step, not the only thing protecting against continued
  -- access; but it's cheap to do right here in the same statement.
  IF new_expiry IS NULL OR new_expiry <= NOW() THEN
    UPDATE user_subscriptions SET tier = 'free' WHERE user_id = p_user_id;
  END IF;

  RETURN new_expiry;
END;
$$;

REVOKE EXECUTE ON FUNCTION revoke_subscription(UUID, INT) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION revoke_subscription(UUID, INT) FROM anon;
REVOKE EXECUTE ON FUNCTION revoke_subscription(UUID, INT) FROM authenticated;
GRANT EXECUTE ON FUNCTION revoke_subscription(UUID, INT) TO service_role;
