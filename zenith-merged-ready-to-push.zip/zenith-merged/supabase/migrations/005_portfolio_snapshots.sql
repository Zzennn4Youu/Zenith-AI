-- ─────────────────────────────────────────────────────────────────────────────
-- PORTFOLIO SNAPSHOTS — hourly portfolio value snapshots for equity curve
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS portfolio_snapshots (
  id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  total_usdt  DECIMAL(18,4) NOT NULL,
  assets      JSONB       DEFAULT '{}',  -- { BTC: { qty, price, value }, ... }
  snapshot_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ps_user_time
  ON portfolio_snapshots (user_id, snapshot_at DESC);

ALTER TABLE portfolio_snapshots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users_own_snapshots" ON portfolio_snapshots;
CREATE POLICY "users_own_snapshots" ON portfolio_snapshots
  FOR ALL USING (auth.uid() = user_id);
