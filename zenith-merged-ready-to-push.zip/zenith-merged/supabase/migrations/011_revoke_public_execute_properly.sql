-- The previous migration (010) targeted `anon, authenticated` directly, but
-- Postgres grants EXECUTE to the PUBLIC pseudo-role by default on function
-- creation — anon/authenticated inherit through PUBLIC regardless of a
-- direct revoke from them specifically. Must revoke from PUBLIC itself.
--
-- Verified after applying: has_function_privilege('anon', ..., 'EXECUTE')
-- and the 'authenticated' equivalent both return false; service_role
-- returns true. This is the actual fix for the vulnerability described in
-- migration 010's comment.

REVOKE EXECUTE ON FUNCTION increment_daily_usage(UUID) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION extend_subscription(UUID, INT) FROM PUBLIC;

-- service_role bypasses grants entirely in Supabase's setup, but grant
-- explicitly too for clarity/robustness against that assumption changing.
GRANT EXECUTE ON FUNCTION increment_daily_usage(UUID) TO service_role;
GRANT EXECUTE ON FUNCTION extend_subscription(UUID, INT) TO service_role;
