-- The checkout route (using a per-user client) needs to record a pending
-- transaction at checkout time so the webhook can safely map order_id back
-- to user_id. payment_transactions only had a SELECT policy so far — add a
-- narrow INSERT policy that lets a user create ONLY their own row, and ONLY
-- with status='pending'. They can never insert (or later update — there's
-- still no UPDATE policy for users) a row claiming 'settlement'/'capture';
-- that transition only ever happens via the webhook's service-role client
-- after signature verification.

DROP POLICY IF EXISTS "users_insert_own_pending_payment" ON payment_transactions;
CREATE POLICY "users_insert_own_pending_payment" ON payment_transactions
  FOR INSERT
  WITH CHECK (auth.uid() = user_id AND status = 'pending');
