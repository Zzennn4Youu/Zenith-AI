-- ─────────────────────────────────────────────────────────────────────────────
-- PUSH SUBSCRIPTIONS — Web Push endpoints registered per browser installation
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint    TEXT        NOT NULL,
  p256dh      TEXT        NOT NULL,  -- subscription's public key (from PushSubscription.getKey('p256dh'))
  auth        TEXT        NOT NULL,  -- subscription's auth secret (from PushSubscription.getKey('auth'))
  user_agent  TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (endpoint)  -- one row per browser installation; re-subscribing upserts by endpoint
);

CREATE INDEX IF NOT EXISTS idx_push_subs_user ON push_subscriptions (user_id);

ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users_own_push_subs" ON push_subscriptions;
CREATE POLICY "users_own_push_subs" ON push_subscriptions
  FOR ALL USING (auth.uid() = user_id);

-- NOTE: the cron-triggered alert checker (app/api/cron/check-alerts) reads
-- across ALL users' subscriptions to deliver push notifications when no one
-- is logged into a browser session. It runs with the Supabase service-role
-- key, which bypasses RLS by design — that's expected and required here,
-- since a scheduled job has no per-user JWT to authenticate as.
