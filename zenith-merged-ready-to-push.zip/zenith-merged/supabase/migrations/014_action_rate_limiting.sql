-- Generic, namespaced per-action rate limiter — reusable across endpoints
-- without colliding with the existing check_and_log_rate_limit()'s shared
-- global bucket (which some other route from an earlier phase already uses
-- for its own purpose, at whatever limit that route sets).

CREATE TABLE IF NOT EXISTS action_rate_limit_log (
  id         UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  action     TEXT        NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_action_rate_limit_lookup
  ON action_rate_limit_log (user_id, action, created_at DESC);

ALTER TABLE action_rate_limit_log ENABLE ROW LEVEL SECURITY;
-- No policies for direct client access at all — reached exclusively via the
-- SECURITY DEFINER function below, which reads auth.uid() itself.

CREATE OR REPLACE FUNCTION check_and_log_action_rate_limit(p_action TEXT, p_limit INT, p_window_minutes INT DEFAULT 60)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_count INT;
  uid UUID := auth.uid();
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(uid::text || ':' || p_action));

  SELECT COUNT(*) INTO current_count
  FROM action_rate_limit_log
  WHERE user_id = uid AND action = p_action
    AND created_at > NOW() - (p_window_minutes || ' minutes')::INTERVAL;

  IF current_count >= p_limit THEN
    RETURN FALSE;
  END IF;

  INSERT INTO action_rate_limit_log (user_id, action) VALUES (uid, p_action);
  RETURN TRUE;
END;
$$;

REVOKE EXECUTE ON FUNCTION check_and_log_action_rate_limit(TEXT, INT, INT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION check_and_log_action_rate_limit(TEXT, INT, INT) TO authenticated;

REVOKE EXECUTE ON FUNCTION check_and_log_rate_limit(INT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION check_and_log_rate_limit(INT) TO authenticated;
