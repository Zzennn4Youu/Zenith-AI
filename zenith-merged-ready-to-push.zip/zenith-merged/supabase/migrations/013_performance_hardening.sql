-- Wrap auth.uid() in (select ...) across every RLS policy — lets Postgres
-- evaluate it once per query (an "initplan") instead of once per row
-- scanned. Pure query-planning optimization, no behavior change. Covers
-- both this session's new policies and pre-existing ones from earlier
-- phases, since the fix is identical and safe everywhere it applies.

DROP POLICY IF EXISTS "Users manage their own conversations" ON conversations;
CREATE POLICY "Users manage their own conversations" ON conversations
  FOR ALL USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can view their own rate limit log" ON rate_limit_log;
CREATE POLICY "Users can view their own rate limit log" ON rate_limit_log
  FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can view their own messages" ON messages;
CREATE POLICY "Users can view their own messages" ON messages
  FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can insert into their own conversations" ON messages;
CREATE POLICY "Users can insert into their own conversations" ON messages
  FOR INSERT WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete their own messages" ON messages;
CREATE POLICY "Users can delete their own messages" ON messages
  FOR DELETE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_own_memories" ON agent_memories;
CREATE POLICY "users_own_memories" ON agent_memories
  FOR ALL USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_own_snapshots" ON portfolio_snapshots;
CREATE POLICY "users_own_snapshots" ON portfolio_snapshots
  FOR ALL USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_own_alerts" ON alerts;
CREATE POLICY "users_own_alerts" ON alerts
  FOR ALL USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_own_triggers" ON alert_triggers;
CREATE POLICY "users_own_triggers" ON alert_triggers
  FOR ALL USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_own_push_subs" ON push_subscriptions;
CREATE POLICY "users_own_push_subs" ON push_subscriptions
  FOR ALL USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_read_own_subscription" ON user_subscriptions;
CREATE POLICY "users_read_own_subscription" ON user_subscriptions
  FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_read_own_usage" ON orchestration_usage_daily;
CREATE POLICY "users_read_own_usage" ON orchestration_usage_daily
  FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_read_own_payments" ON payment_transactions;
CREATE POLICY "users_read_own_payments" ON payment_transactions
  FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "users_insert_own_pending_payment" ON payment_transactions;
CREATE POLICY "users_insert_own_pending_payment" ON payment_transactions
  FOR INSERT WITH CHECK ((select auth.uid()) = user_id AND status = 'pending');

-- Missing foreign-key covering indexes
CREATE INDEX IF NOT EXISTS idx_alert_triggers_alert_id ON alert_triggers (alert_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages (user_id);
