-- CRITICAL FIX: increment_daily_usage() and extend_subscription() are
-- SECURITY DEFINER functions, which by default remain callable through
-- PostgREST's exposed RPC endpoint by the `anon` (unauthenticated!) and
-- `authenticated` roles. Since extend_subscription grants paid-tier access
-- for an arbitrary p_user_id with no ownership check, this meant literally
-- anyone on the internet could call it directly and grant themselves (or
-- anyone) unlimited free access, completely bypassing payment. Revoking
-- EXECUTE from anon/authenticated restricts both functions to being
-- callable only via the service-role key, which is how the trusted
-- server-side code (webhook handler, model-tier resolver) actually uses
-- them — never through the public REST API.
--
-- NOTE: this revoke alone is insufficient — see migration 011. Postgres
-- grants EXECUTE to PUBLIC by default on function creation, and
-- anon/authenticated inherit through PUBLIC regardless of a direct revoke
-- targeted at them specifically. Kept here for the historical record of
-- what was tried; 011 is the migration that actually closes this.

REVOKE EXECUTE ON FUNCTION increment_daily_usage(UUID) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION extend_subscription(UUID, INT) FROM anon, authenticated;
