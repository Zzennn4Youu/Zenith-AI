-- ─────────────────────────────────────────────────────────────────────────────
-- SUBSCRIPTIONS & USAGE — 3-tier model routing (Zenith Spark / Core / Apex)
-- ─────────────────────────────────────────────────────────────────────────────

-- One row per user. Free until a payment flow (not part of this migration)
-- sets tier='paid'. Standalone table referencing auth.users directly rather
-- than an assumed `profiles` table, so this doesn't depend on schema from
-- migrations outside this bundle.
CREATE TABLE IF NOT EXISTS user_subscriptions (
  user_id      UUID        PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  tier         TEXT        NOT NULL DEFAULT 'free' CHECK (tier IN ('free', 'paid')),
  activated_at TIMESTAMPTZ,
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users_read_own_subscription" ON user_subscriptions;
CREATE POLICY "users_read_own_subscription" ON user_subscriptions
  FOR SELECT USING (auth.uid() = user_id);

-- Deliberately NO insert/update policy for regular users — tier changes
-- should only happen through a trusted server path (e.g. a payment webhook
-- using the service-role key), never directly from a user's own client.
-- Otherwise a technically-savvy free user could just flip their own row to
-- 'paid' via a direct REST call using their own valid JWT.

-- ── Daily usage counter (free tier only — paid tier has no limit) ───────────
CREATE TABLE IF NOT EXISTS orchestration_usage_daily (
  user_id       UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  usage_date    DATE NOT NULL DEFAULT CURRENT_DATE,
  request_count INT  NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, usage_date)
);

ALTER TABLE orchestration_usage_daily ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users_read_own_usage" ON orchestration_usage_daily;
CREATE POLICY "users_read_own_usage" ON orchestration_usage_daily
  FOR SELECT USING (auth.uid() = user_id);

-- Same reasoning as above: no direct insert/update policy for users. Writes
-- go exclusively through increment_daily_usage() below, which is
-- SECURITY DEFINER (runs with the privileges of its owner, bypassing RLS
-- for its own internal write) — this lets trusted server code call it
-- safely with any per-user client, while still blocking a user from
-- resetting or forging their own counter via a direct table write.

CREATE OR REPLACE FUNCTION increment_daily_usage(p_user_id UUID)
RETURNS INT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_count INT;
BEGIN
  INSERT INTO orchestration_usage_daily (user_id, usage_date, request_count)
  VALUES (p_user_id, CURRENT_DATE, 1)
  ON CONFLICT (user_id, usage_date)
  DO UPDATE SET request_count = orchestration_usage_daily.request_count + 1
  RETURNING request_count INTO new_count;
  RETURN new_count;
END;
$$;

-- NOTE: increment_daily_usage() is only ever called from trusted server-side
-- code (lib/orchestrator/modelTiers.js) with a userId already authenticated
-- earlier in the request chain — never expose it directly to the client with
-- an arbitrary p_user_id, since SECURITY DEFINER bypasses RLS entirely.
