-- ─────────────────────────────────────────────────────────────────────────────
-- BILLING — Midtrans subscription payments (QRIS/GoPay/VA/cards via Snap)
-- ─────────────────────────────────────────────────────────────────────────────

ALTER TABLE user_subscriptions
  ADD COLUMN IF NOT EXISTS expires_at        TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS midtrans_order_id TEXT;

-- One row per payment attempt (not just successes) — keyed by order_id so
-- webhook processing can be idempotent per Midtrans's own recommendation
-- ("implement notification handling idempotently... use order_id as the key
-- to track entries, since duplicate notifications can occur").
CREATE TABLE IF NOT EXISTS payment_transactions (
  id                UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id           UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  order_id          TEXT        NOT NULL UNIQUE,
  amount            INT         NOT NULL,
  status            TEXT        NOT NULL, -- pending | settlement | capture | deny | cancel | expire | failure
  payment_type      TEXT,                  -- qris | gopay | bank_transfer | credit_card | ...
  raw_notification  JSONB,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payment_tx_user ON payment_transactions (user_id, created_at DESC);

ALTER TABLE payment_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users_read_own_payments" ON payment_transactions;
CREATE POLICY "users_read_own_payments" ON payment_transactions
  FOR SELECT USING (auth.uid() = user_id);

-- No write policy for users — only the webhook route (service-role client,
-- since Midtrans calls it server-to-server with no user session at all)
-- writes here.

-- ── Atomic subscription extension ───────────────────────────────────────────
-- Extends from whichever is later — current expires_at or now() — so paying
-- early doesn't waste remaining days, and paying after lapsing starts a
-- fresh period from today. SECURITY DEFINER + atomic UPDATE avoids a race
-- where two near-simultaneous webhook deliveries for the same renewal both
-- read a stale expires_at and only extend once instead of twice.
CREATE OR REPLACE FUNCTION extend_subscription(p_user_id UUID, p_days INT)
RETURNS TIMESTAMPTZ
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_expiry TIMESTAMPTZ;
BEGIN
  INSERT INTO user_subscriptions (user_id, tier, activated_at, expires_at, updated_at)
  VALUES (p_user_id, 'paid', NOW(), NOW() + (p_days || ' days')::INTERVAL, NOW())
  ON CONFLICT (user_id) DO UPDATE SET
    tier         = 'paid',
    activated_at = COALESCE(user_subscriptions.activated_at, NOW()),
    expires_at   = GREATEST(user_subscriptions.expires_at, NOW()) + (p_days || ' days')::INTERVAL,
    updated_at   = NOW()
  RETURNING expires_at INTO new_expiry;
  RETURN new_expiry;
END;
$$;

-- NOTE: like increment_daily_usage(), this bypasses RLS by design and is
-- only ever called from the trusted webhook route after signature
-- verification — never expose it to the client directly.
