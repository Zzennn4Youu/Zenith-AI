-- ROOT CAUSE (confirmed directly against pg_default_acl): this Supabase
-- project's default ACL grants EXECUTE on new functions DIRECTLY to `anon`
-- and `authenticated` (defaclrole=postgres, defaclobjtype='f' shows
-- anon=X, authenticated=X granted straight to those roles, not via PUBLIC
-- membership). Revoking from PUBLIC alone — what migrations 011 and 014
-- did — does nothing to remove a direct grant.
--
-- The earlier fix for extend_subscription/increment_daily_usage (migration
-- 011) actually worked because migration 010, applied just before it,
-- separately revoked from `anon, authenticated` directly — migration 011's
-- PUBLIC revoke was redundant, not the actual fix. Misdiagnosed at the
-- time; this comment corrects the record.
--
-- LESSON for any future SECURITY DEFINER function on this project: revoke
-- from `anon` explicitly, not just PUBLIC. Verify with
-- has_function_privilege('anon', ..., 'EXECUTE') directly — don't trust
-- the advisor's cache alone, and don't assume a PUBLIC-only revoke is
-- sufficient just because it's the standard Postgres pattern elsewhere.

REVOKE EXECUTE ON FUNCTION check_and_log_action_rate_limit(TEXT, INT, INT) FROM anon;
REVOKE EXECUTE ON FUNCTION check_and_log_rate_limit(INT) FROM anon;
