-- 018_close_trigger_function_exposure.sql
-- Closes the two confirmed-safe items from the security review in
-- MILESTONE0_BETA_READINESS.md. Deliberately does NOT touch restrict_signup —
-- its source wasn't in scope to verify; read it before changing its grants.

-- touch_conversation_updated_at: trigger-only function, no legitimate reason
-- to be RPC-callable. Same needless-exposure class as the anon-grant issue
-- already fixed in 010/011/015 for other functions — closing on the same
-- pattern for consistency.
REVOKE EXECUTE ON FUNCTION touch_conversation_updated_at() FROM PUBLIC, anon, authenticated;

-- touch_updated_at: missing the search_path hardening that 014/016 already
-- established as the house style. Low risk on its own (no dynamic SQL, no
-- object references), but matching the standard rather than leaving an
-- inconsistency.
ALTER FUNCTION touch_updated_at() SET search_path = public;
