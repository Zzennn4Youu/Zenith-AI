-- ─────────────────────────────────────────────────────────────────────────────
-- ALERTS SYSTEM — price triggers + SMC signal alerts
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS alerts (
  id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  symbol        TEXT        NOT NULL,                 -- e.g. 'BTCUSDT'
  type          TEXT        NOT NULL CHECK (type IN (
                              'price_above',           -- price crosses above threshold
                              'price_below',            -- price crosses below threshold
                              'pct_change',              -- |24h %change| >= threshold
                              'smc_signal',              -- new LONG/SHORT signal appears
                              'smc_score_above'         -- weighted MTF score >= threshold
                            )),
  timeframe     TEXT        DEFAULT '4h',              -- used by smc_* types
  threshold     DECIMAL(18,8),                          -- price / pct / score value
  signal_type   TEXT        CHECK (signal_type IN ('LONG','SHORT', NULL)),
  label         TEXT,                                   -- optional user note
  recurring     BOOLEAN     DEFAULT false,               -- if false, disables after first trigger
  status        TEXT        DEFAULT 'active'
                            CHECK (status IN ('active','triggered','disabled')),
  last_value    DECIMAL(18,8),                           -- last observed value (for cross-detection)
  last_checked_at TIMESTAMPTZ,
  triggered_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_alerts_user_status
  ON alerts (user_id, status);

CREATE INDEX IF NOT EXISTS idx_alerts_symbol_status
  ON alerts (symbol, status) WHERE status = 'active';

ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "users_own_alerts" ON alerts;
CREATE POLICY "users_own_alerts" ON alerts
  FOR ALL USING (auth.uid() = user_id);

-- ── Trigger history log ───────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS alert_triggers (
  id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  alert_id      UUID        NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
  user_id       UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  symbol        TEXT        NOT NULL,
  message       TEXT        NOT NULL,
  value_at_trigger DECIMAL(18,8),
  read          BOOLEAN     DEFAULT false,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_at_user_read
  ON alert_triggers (user_id, read, created_at DESC);

ALTER TABLE alert_triggers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "users_own_triggers" ON alert_triggers;
CREATE POLICY "users_own_triggers" ON alert_triggers
  FOR ALL USING (auth.uid() = user_id);
