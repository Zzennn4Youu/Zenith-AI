/**
 * UPGRADE BUTTON — Zenith AI v2
 *
 * Loads Midtrans Snap.js on demand and opens the payment popup (QRIS/GoPay/
 * ShopeePay/bank transfer — see lib/billing/midtrans.js for the enabled
 * channel list). On success, calls onUpgraded so the parent can refresh the
 * tier badge — the actual tier flip happens via the webhook, which may land
 * a moment after Snap's onSuccess fires client-side, so onUpgraded should
 * poll/refresh rather than assume it's instant.
 *
 * Props: session, onUpgraded
 */
'use client';
import { useState } from 'react';

let snapScriptPromise = null;
function loadSnapScript() {
  if (snapScriptPromise) return snapScriptPromise;
  snapScriptPromise = new Promise((resolve, reject) => {
    if (window.snap) return resolve(window.snap);
    const script = document.createElement('script');
    const isProd = process.env.NEXT_PUBLIC_MIDTRANS_IS_PRODUCTION === 'true';
    script.src = isProd
      ? 'https://app.midtrans.com/snap/snap.js'
      : 'https://app.sandbox.midtrans.com/snap/snap.js';
    script.setAttribute('data-client-key', process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY || '');
    script.onload = () => resolve(window.snap);
    script.onerror = () => reject(new Error('Failed to load Midtrans Snap.js'));
    document.head.appendChild(script);
  });
  return snapScriptPromise;
}

export default function UpgradeButton({ session, onUpgraded }) {
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);

  const upgrade = async () => {
    setLoading(true);
    setErr(null);
    try {
      const snap = await loadSnapScript();

      const res = await fetch('/api/billing/checkout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${session.access_token}` },
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to start checkout');

      snap.pay(data.token, {
        onSuccess: () => onUpgraded?.('success'),
        onPending: () => onUpgraded?.('pending'), // e.g. bank transfer/VA awaiting payment
        onError: (result) => setErr(result?.status_message || 'Payment failed'),
        onClose: () => { /* user closed the popup without paying — no error */ },
      });
    } catch (e) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <button onClick={upgrade} disabled={loading} style={{
        padding: '8px 16px', borderRadius: 8, border: 'none', cursor: loading ? 'default' : 'pointer',
        background: 'linear-gradient(135deg, #ffd43b, #ff922b)', color: '#1a1206',
        fontWeight: 800, fontSize: 12.5, opacity: loading ? 0.7 : 1,
      }}>
        {loading ? 'Loading…' : '⚡ Upgrade to Zenith Apex — Rp 99.000/bulan'}
      </button>
      {err && <div style={{ color: '#ff6b6b', fontSize: 11, marginTop: 6 }}>⚠ {err}</div>}
    </div>
  );
}
