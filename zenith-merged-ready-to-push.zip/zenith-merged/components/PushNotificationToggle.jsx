/**
 * PUSH NOTIFICATION TOGGLE — Zenith AI v2
 *
 * Lets the user opt into Web Push so alerts reach them even when no tab is
 * open (delivered by the /api/cron/check-alerts job, not the in-app SSE
 * stream). Handles service worker registration, permission request,
 * subscribe/unsubscribe, and persisting the subscription server-side.
 *
 * Props: session
 */
'use client';
import { useState, useEffect, useCallback } from 'react';

const C = {
  card: '#11151F', border: '#1a1f2e', dim: '#5a6070',
  text: '#e8e9f0', accent: '#7C9CFF', green: '#69db7c', red: '#ff6b6b',
};

// Web Push requires the VAPID public key as a Uint8Array, not the base64url
// string form it's normally shared/stored as.
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const output = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) output[i] = raw.charCodeAt(i);
  return output;
}

export default function PushNotificationToggle({ session }) {
  // 'unsupported' | 'checking' | 'off' | 'on' | 'denied' | 'busy'
  const [state, setState] = useState('checking');
  const [err, setErr] = useState(null);

  const checkStatus = useCallback(async () => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      setState('unsupported');
      return;
    }
    if (Notification.permission === 'denied') {
      setState('denied');
      return;
    }
    try {
      const reg = await navigator.serviceWorker.register('/sw.js');
      const sub = await reg.pushManager.getSubscription();
      setState(sub ? 'on' : 'off');
    } catch (e) {
      setErr(e.message);
      setState('off');
    }
  }, []);

  useEffect(() => { checkStatus(); }, [checkStatus]);

  const enable = async () => {
    setErr(null);
    setState('busy');
    try {
      const publicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
      if (!publicKey) throw new Error('NEXT_PUBLIC_VAPID_PUBLIC_KEY not configured');

      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        setState(permission === 'denied' ? 'denied' : 'off');
        return;
      }

      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey),
      });

      const res = await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({
          endpoint: sub.endpoint,
          keys: {
            p256dh: arrayBufferToBase64Url(sub.getKey('p256dh')),
            auth:   arrayBufferToBase64Url(sub.getKey('auth')),
          },
        }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to save subscription');

      setState('on');
    } catch (e) {
      setErr(e.message);
      setState('off');
    }
  };

  const disable = async () => {
    setErr(null);
    setState('busy');
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        await fetch('/api/push/subscribe', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
          body: JSON.stringify({ endpoint: sub.endpoint }),
        });
        await sub.unsubscribe();
      }
      setState('off');
    } catch (e) {
      setErr(e.message);
      setState('on'); // couldn't confirm it's off — don't lie about the state
    }
  };

  function arrayBufferToBase64Url(buffer) {
    const bytes = new Uint8Array(buffer);
    let bin = '';
    for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  if (state === 'unsupported') {
    return <div style={{ fontSize: 11, color: C.dim }}>Push notifications aren't supported in this browser.</div>;
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: C.text }}>Push notifications</div>
        <div style={{ fontSize: 10.5, color: C.dim, marginTop: 2 }}>
          {state === 'on'  && 'Enabled — alerts reach you even with the app closed.'}
          {state === 'off' && 'Off — alerts only show while this tab is open.'}
          {state === 'denied' && 'Blocked in browser settings — re-enable notifications for this site to use.'}
          {(state === 'checking' || state === 'busy') && 'Checking status…'}
        </div>
        {err && <div style={{ fontSize: 10.5, color: C.red, marginTop: 2 }}>⚠ {err}</div>}
      </div>
      <button
        disabled={state === 'busy' || state === 'checking' || state === 'denied'}
        onClick={state === 'on' ? disable : enable}
        style={{
          padding: '6px 14px', borderRadius: 7, fontSize: 11.5, fontWeight: 600, cursor: 'pointer',
          border: `1px solid ${state === 'on' ? C.green + '55' : C.border}`,
          background: state === 'on' ? C.green + '18' : 'transparent',
          color: state === 'on' ? C.green : C.text,
          opacity: (state === 'busy' || state === 'checking' || state === 'denied') ? 0.5 : 1,
        }}
      >
        {state === 'on' ? 'Disable' : 'Enable'}
      </button>
    </div>
  );
}
