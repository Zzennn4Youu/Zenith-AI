# Zenith AI — Phase 1: Foundation Architecture

**From AI Chatbot to AI Operating System — the load-bearing layer everything else stands on.**

| | |
|---|---|
| **Status** | Proposed — ready for review |
| **Scope** | Foundation only. No user-facing features in this phase. |
| **Basis** | Audited directly against `zenith-phase6-fixed.zip` (13 API routes, 10 components, 21 lib modules, 13 migrations) |
| **Author** | Claude, acting as architecture reviewer |
| **Reviewed for** | Sara |

---

## How to read this document

This is long because the ask was long — but it is organized so you don't have to read it linearly. Section 1 is the whole decision in one page. Sections 2–4 are the audit (what's actually in your repo today, what's good, what's debt). Sections 5–19 are the 15 deliverables you asked for, in order. Section 20 is the self-review — where I argue with my own proposal the way a Stripe/Linear/Anthropic review would. Everything here is designed to be adopted **incrementally, without a rewrite** — every recommendation says explicitly what existing file it wraps rather than replaces.

A companion **starter kit** (real `.ts` files, not just prose) and two diagrams ship alongside this doc — see Section 23 for the manifest.

---

## 1. Executive Summary

Your Phase 6 codebase is not a prototype — it's a genuinely well-built system with real engineering discipline in it already: pure-logic modules extracted for testability (`pnl.js`, `backtestEngine.js`, `modelTierDefs.js`), dependency-injected control flow in the tool-calling loop, tier-based agent composition across 100 agents, and RLS-first Supabase design with service-role write isolation. **Phase 1 does not throw any of that away.** It gives it a skeleton.

Right now, the thing holding your 100 agents, memory, tools, trading, and billing together is `OrchestratorV3.js` — a 575-line file that plans, executes, retries, logs, and compiles results all at once, coordinating everything through direct function calls and a hardcoded fallback map. That worked for one team building one feature at a time. It will not survive "unlimited agents, unlimited tools, unlimited workspaces, future marketplace" — not because the logic is wrong, but because **nothing in that file is currently declared, only implied.** An agent's tools, its fallback partner, its retry policy — all real, all correct, all scattered across three files as code rather than data.

**The core move in Phase 1: turn implicit behavior into explicit, typed contracts, and route everything important through one event bus.** Concretely:

1. **Agent Manifest** — replace the 5-field agent shape (`name, displayName, tier, systemPrompt, maxTokens`) with a typed contract that declares tools, memory access, cost ceiling, retry policy, and fallback partner *on the agent itself* — not centrally in the orchestrator.
2. **Event Bus** — your `logEvent()` calls already are domain events, just written straight to Postgres with no subscribers. Formalize them as typed events on an in-process bus; the Supabase writer becomes one subscriber among several (SSE, metrics, future plugins).
3. **Mission Pipeline** — name the stages your orchestrator already has (`supervisorNode` → Planning, `agentDispatcherNode` → Execution, `resultCompilerNode` → partial Validation) and add the two that don't exist yet as first-class stages (**Validation**, **Reflection**), so the full Intent → Planning → Execution → Validation → Reflection → Memory → Learning loop is a real, inspectable pipeline — not an implicit side effect of function call order.
4. **Ports & Adapters** — the Anthropic SDK client, Supabase client, and every external tool (MEXC, CoinGecko, BraveSearch, Midtrans) move behind interfaces your domain code depends on, not concrete SDKs. This is what makes "never hardcode AI providers" literally true instead of aspirational.
5. **Typed config** — one Zod-validated config module replaces scattered `process.env.X` reads, and kills the "update this price by hand on Sept 1" pattern currently living as a comment in `modelTiers.js`.
6. **Incremental TypeScript** — not a rewrite. New foundation code (`core/`) is TypeScript from day one; existing `.js`/`.jsx` files stay as-is and get types at the boundary via `.d.ts` files, migrated file-by-file as each module is next touched.

None of this requires touching your 100 agent definitions, your Supabase schema, your billing flow, or your UI components. It requires adding a `core/` layer underneath them and, over several weeks, having the existing orchestrator call into it instead of doing everything itself.

---

## 2. Stage 1 — Current Architecture Assessment

### 2.1 What's confirmed (from the uploaded Phase 6 bundle)

- **Runtime**: Next.js 15, App Router, route handlers in `app/api/**/route.js` — plain JavaScript, not TypeScript.
- **Data**: Supabase (Postgres), 13 migrations visible (`004`–`016`), numbered sequentially, RLS enabled on every table inspected, service-role key reserved for privileged writes (usage counters, tier grants).
- **AI provider**: `@anthropic-ai/sdk`, instantiated once at module scope in `OrchestratorV3.js`. Three model tiers, resolved per-request: **Zenith Spark** (`claude-haiku-4-5-20251001`), **Zenith Core** (`claude-sonnet-5`), **Zenith Apex** (`claude-opus-4-8`) — confirmed live, current model identifiers.
- **Billing**: Midtrans (checkout + webhook routes), with a manual `/api/admin/set-tier` stand-in gated by `ADMIN_SECRET` bearer auth until the real gateway is fully wired.
- **Deployment**: Vercel, Hobby tier — confirmed by the `DEPLOYMENT_CHECKLIST.md` routing two cron jobs through the external `cron-job.org` because Hobby's built-in cron can't hit the required frequency.
- **Testing**: Node's built-in `node:test` runner, newly introduced this phase, zero new dependencies. `TESTING_SETUP.md` itself flags a prior-phase reference to a 48-test Jest suite across 7 suites that may or may not still be the primary runner elsewhere in the repo — **this is an open inconsistency, not a resolved one** (see 3.6).
- **Agent registry**: 100 agents, 5 tiers, composed via object-spread in `AgentRegistry.js` (51 lines) from five per-tier files. Contract the orchestrator actually relies on: `{ name, displayName, tier, systemPrompt, maxTokens }` — nothing else, by the file's own header comment.
- **Orchestrator**: `OrchestratorV3.js`, 575 lines, a hand-rolled state-graph (`supervisorNode → agentDispatcherNode → resultCompilerNode`) — LangGraph-shaped naming, but no LangGraph dependency; it's bespoke.

I have **not** seen (referenced by import, not included in this zip): `lib/tools/ToolExecutor.js`, `lib/memory/SharedMemory.js`, the full Tier 2–5 agent prompt files beyond Tier 1, the root app shell/chat UI, auth flow, or the MEXC/SMC engine code mentioned in your project history. Recommendations below that touch those are architectural (interface-level) rather than line-referenced, and should be sanity-checked against the actual files before you migrate them.

### 2.2 What's already good — preserve, don't replace

This matters as much as the debt list. A few patterns already in your repo *are* the target architecture in miniature; Phase 1 mostly means **doing these five things everywhere, on purpose, instead of in three places, by instinct.**

| Pattern | Where | Why it's the right shape |
|---|---|---|
| Functional core extracted from imperative shell | `lib/portfolio/pnl.js` (from `PortfolioDashboard.jsx`), `lib/alerts/backtestEngine.js` (from the backtest route), `lib/orchestrator/modelTierDefs.js` (from `modelTiers.js`) | This *is* Functional Core / Imperative Shell. Pure logic, zero I/O, fully unit-tested without mocks. Exactly the target pattern for every domain rule in the system. |
| Dependency injection at the function level | `runToolCallLoop({ callModel, callTool, ... })` in `agentTools.js` | `callModel` and `callTool` are injected, not imported — the loop's control flow (termination, cost accumulation, parallel tool calls) is unit-testable against fakes, independent of whether the real Anthropic API/`executeTool` behave as assumed. This is the DI pattern the rest of the system should adopt for provider/adapter boundaries. |
| Composition over a flat namespace | `AgentRegistry.js` spreading five tier files into `ALL_AGENTS` | Adding a 101st agent means adding one object to one tier file — no registry code changes. Right instinct; Phase 1 extends it with validation and richer metadata, not a rewrite. |
| RLS as the default, not an afterthought | Every migration reviewed (`004`–`016`) | Direct user writes are blocked by default; privileged mutations funnel through service-role-gated server code (`increment_daily_usage()`, `/api/admin/set-tier`). This is the correct security posture and Phase 1 doesn't touch it. |
| Structured event logging | `logEvent()` → `execution_log` table, called at every lifecycle transition in `OrchestratorV3.js` | You are *already* emitting domain events — they just have exactly one subscriber (Postgres) and no typed shape. Section 8 formalizes this into a real event bus without changing what gets logged or where. |

---

## 3. Stage 2 — Architectural Debt (grounded in your actual files)

Ranked by how much it will hurt as the agent count, tool count, and workspace count grow — not by how it looks today.

### 3.1 The agent contract is too thin for what you're about to ask of it

`AgentRegistry.js`'s own header says it plainly: the orchestrator relies on exactly 5 fields. Everything the prompt above requires of an agent — tools, capabilities, memory access, permissions, cost ceiling, latency budget, confidence, fallback, retry — either doesn't exist as data, or exists as code *about* the agent, located somewhere else:

- Fallback partner → hardcoded in `OrchestratorV3.js`'s `FALLBACK_AGENTS` map, keyed by name, physically distant from the agent it protects.
- Tool access → hardcoded in `agentTools.js`'s `TIER_TOOL_SETS`, granted by *tier number*, not by agent — an agent can't get a narrower or broader tool set than its tier's default without another hardcoded exception.
- Retry policy → hardcoded as module constants (`MAX_AGENT_RETRIES = 2`, fixed exponential backoff) applied uniformly to all 100 agents regardless of what they actually do.
- Cost/latency/confidence → don't exist as declared fields anywhere.

None of this is a bug. It's what "ship the feature" correctly looks like at 100 agents built in one phase. It stops being sustainable at "unlimited agents" from unrelated future contributors, or a marketplace where a listing needs to *describe* an agent's cost/permissions without reading its source.

### 3.2 `OrchestratorV3.js` is carrying four responsibilities that will need to scale independently

In one 575-line file: **persistence** (`logEvent`, `writeAgentResult`, `updateSubtaskStatus`, `writeSubtasks`), **planning** (`supervisorNode`), **execution + retry/fallback policy** (`agentDispatcherNode`, `executeAgentWithRetry`), and **compilation** (`resultCompilerNode`). Today that's manageable. It stops being manageable the moment any one of these needs to change independently — e.g., swapping Postgres event logging for a queue, or adding a second planning strategy for a new mission type, both currently mean editing the same file that also owns retry logic. This is a Single-Responsibility violation at the *module* level, not the class level (the code is functional, not OOP) — the fix is decomposition into stages behind an interface, not a "God Object" rewrite.

### 3.3 No dependency injection at the provider boundary

`const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })` is instantiated at module scope in `OrchestratorV3.js`. It works, but it means: no swapping providers per-tier or per-workspace without editing this file; no injecting a mock in tests (the `runToolCallLoop` tests already work around this by injecting `callModel` directly — proof the rest of the file could do the same); and every future "unlimited future AI models" requirement runs through one hardcoded constructor call.

### 3.4 No event bus — only one subscriber (Postgres) to every domain event

Every `logEvent()` call is a domain event with exactly one consumer. Today that's fine because nothing else needs to react to "agent started" in real time. It stops being fine the moment you want: SSE progress streaming that doesn't poll Supabase, live cost dashboards, a future plugin that reacts to "mission completed," or Alerts triggering off Trading events instead of its own cron. Each of those, today, would mean a new direct Supabase read/poll bolted onto the consumer — N consumers × M event types of ad hoc wiring instead of N+M.

### 3.5 Configuration is scattered and, in one confirmed spot, manually time-bombed

`process.env.X` is read ad hoc wherever it's needed, with no central schema, so a missing/malformed env var fails at the call site, in production, instead of at boot. Concretely worse: `TIER_SYSTEM_SETUP.md` documents that Sonnet 5's introductory pricing (`$2/$10`) reverts to standard (`$3/$15`) after **Aug 31, 2026**, and the fix is "update `priceIn`/`priceOut` in `modelTiers.js` by hand on that date." That's a hardcoded value with a *calendar reminder* standing in for a config system — exactly the kind of thing that gets missed. Section 12 replaces it with a versioned, dated pricing table so cost tracking degrades gracefully instead of silently going stale.

### 3.6 Test runner story is inconsistent

`node:test` was introduced this phase specifically *because* it's zero-dependency — but `TESTING_SETUP.md` explicitly notes an earlier phase referenced a 48-test Jest suite across 7 suites, without confirming whether that suite still exists or still runs. Two possible test runners in one repo, unresolved, is worse than either one alone: CI can silently only run one of them. This needs a decision, not a coexistence (see 19.3).

### 3.7 Prompts are hardcoded template literals colocated with agent data — fine at current scale, a ceiling for the next one

Every agent's `systemPrompt` is a JS template literal inside its tier file, with shared fragments (`RESEARCH_HOUSE_RULES`) spliced in by string concatenation. This is genuinely reasonable at "one team, 100 agents, infrequent prompt changes." It becomes a ceiling the moment you want: non-engineers editing prompts, prompt versioning/rollback, A/B testing a prompt, or a marketplace where third-party prompts are data, not code shipped in your repo. Phase 1 does **not** force this externalization (that's a real migration with real risk — see 3.8) — it formalizes prompt composition as a named, testable step so externalizing later is a swap, not a rewrite.

### 3.8 JavaScript, not TypeScript — the single decision every other recommendation depends on

100 agents share a 5-field shape enforced by nothing but a code comment. A malformed agent object fails at runtime, in production, at whatever line first touches the missing field — not at build time. This is the one item in this list I'm treating as a **prerequisite decision** rather than a parallel-track nice-to-have, because every contract in Sections 7–11 (Agent Manifest, Tool Definition, Plugin Interface, Event Bus) is meaningfully weaker without compile-time enforcement. See Decision B in Section 4 for the adoption strategy — it is deliberately incremental, not a rewrite.

---

## 4. Stage 3–4 — Key Decisions & Trade-offs

Four decisions shape everything downstream. I'm showing the trade-off, not just the answer, because you should be able to disagree with any one of these without invalidating the rest.

### Decision A — Modular Monolith vs. Microservices, now

| | Modular Monolith (recommended) | Microservices now |
|---|---|---|
| Fits current infra | Yes — Vercel Hobby, single Next.js deploy | No — needs service mesh, per-service deploy pipeline, network-level auth |
| Fits current team size | Yes | Requires dedicated platform/infra ownership you likely don't have yet |
| Refactor cost if wrong | Low — clean module boundaries extract into services later with no logic rewrite | N/A |
| Cost if right | You pay a distributed-systems tax (network calls, partial failure, eventual consistency) for zero current benefit | — |
| Path to 1M users | Vertically scale Vercel + Supabase first; module boundaries mean any one module (e.g., Trading) can be pulled into its own service *later*, in isolation, once it's the actual bottleneck | — |

**Decision: modular monolith with enforced internal boundaries** (Section 9), specifically so that "future microservice migration" is a real, cheap option later rather than a promise. Extracting a well-bounded module behind a clean interface into its own service is a deployment change. Untangling a module that was never bounded is a rewrite.

### Decision B — TypeScript adoption strategy

| | Big-bang rewrite | **Incremental, core-outward (recommended)** | Stay JS |
|---|---|---|---|
| Risk | High — freezes feature work, huge diff, regression surface | Low — new code typed, old code untouched until touched | None short-term |
| When value lands | All at once, late | Immediately, at the exact place it matters most (shared contracts) | Never |
| Matches "don't rebuild everything" instruction | No | **Yes** | Yes, but leaves 3.8 unresolved permanently |

**Decision:** every file under the new `core/` (Section 6) is TypeScript, `strict: true`, from the first commit. Existing `.js`/`.jsx` files are **not** touched as part of Phase 1. `checkJs`/JSDoc types can optionally light up type-checking on existing files without converting them (see 17.1). Convert a file to `.ts` only when you're already changing it for another reason (strangler pattern, detailed in Section 19).

### Decision C — Event Bus implementation

| | In-process EventEmitter-style bus (recommended for Phase 1) | Redis/Upstash pub-sub | Postgres LISTEN/NOTIFY |
|---|---|---|---|
| Infra required | None — pure code | New service (Upstash has a free tier compatible with Vercel) | Uses existing Supabase Postgres |
| Works across serverless invocations | **No** — each Vercel function invocation is its own process | Yes | Yes |
| Right for Phase 1 | Yes — most of today's event flow (log → same request's Postgres write) is intra-request anyway | Not yet needed | Not yet needed |
| Right for later (SSE fan-out across users, cross-instance) | No | **Yes, when needed** | Viable alternative, avoids new infra |

**Decision:** define one `EventBus` interface (Section 8). Ship an in-process implementation now — it correctly handles everything inside a single request/invocation, which is 100% of your current event flow. When cross-invocation fan-out is actually needed (e.g., broadcasting mission progress to a second connected client), swap the implementation behind the same interface. This is the entire point of defining the port before picking the adapter.

### Decision D — Dependency Injection approach

| | Heavy DI framework (`InversifyJS`, decorators) | **Explicit composition root (recommended)** | No DI, keep current pattern |
|---|---|---|---|
| Fits serverless/edge functions | Poorly — reflection/decorator metadata adds cold-start cost | **Yes — plain functions and object literals, zero runtime cost** | Yes |
| Testability | High | High | Low (proven by the one place — `runToolCallLoop` — that already had to work around it) |
| Learning curve for future contributors | High (framework-specific) | Low (it's just TypeScript) | None, but silently caps testability |

**Decision:** no DI framework. One `container.ts` (Section 6/kit) wires concrete adapters to interfaces at the app's single composition root (`lib/composition-root.ts`), the same way `runToolCallLoop` already receives `callModel`/`callTool` as plain parameters. This is DI as a *pattern*, not DI as a *library*.

---

## 5. Deliverable 1 — High-Level Architecture

Five layers, strict inward dependency direction (outer layers depend on inner ones; inner layers know nothing about outer ones). This is Hexagonal/Clean Architecture mapped directly onto your existing `app/` + `lib/` split — **no folder gets deleted, `core/` gets added underneath.**

```
┌─────────────────────────────────────────────────────────────────┐
│  INTERFACE  (driving adapters)                                  │
│  app/api/**/route.ts · SSE endpoints · React components         │
│  Translates HTTP ⇄ domain. Zero business logic.                 │
├─────────────────────────────────────────────────────────────────┤
│  APPLICATION  (use-case orchestration)                          │
│  Mission Pipeline stages · Orchestration services                │
│  Wraps supervisorNode / agentDispatcherNode / resultCompilerNode │
├─────────────────────────────────────────────────────────────────┤
│  DOMAIN  (bounded contexts — the "AI Operating System" modules) │
│  Agents · Memory · Tools · Trading · Portfolio · Alerts ·        │
│  Documents · Billing · Identity — each owns its rules + ports    │
├─────────────────────────────────────────────────────────────────┤
│  INFRASTRUCTURE  (driven adapters — implement Domain's ports)   │
│  Supabase repos · Anthropic provider · MEXC / CoinGecko /        │
│  BraveSearch clients · Midtrans · VAPID push                     │
├─────────────────────────────────────────────────────────────────┤
│  KERNEL  (zero dependencies — everything else depends on this)  │
│  Event Bus · DI Container · Config · Logger · Result/Error types │
└─────────────────────────────────────────────────────────────────┘
```

See `diagrams/architecture-layers.mermaid` for the visual, dependency-direction-annotated version.

**Why this shape, specifically:** your codebase already *has* four of these five layers informally — `app/api` is Interface, `lib/orchestrator` is mostly Application, `lib/agents`/`lib/memory`/`lib/portfolio` are Domain, and raw SDK calls are unlabeled Infrastructure sitting inside Domain/Application files. The only genuinely new layer is **Kernel** — and it's small on purpose (an event bus, a container, a config loader, a logger, and two shared types). Everything else is *relocation and interface-extraction*, not new logic.

**Can this scale to 1M users?** The layering doesn't change; what changes is which Infrastructure adapters are swapped (e.g., in-process event bus → Redis) and which Domain modules get pulled into their own deployable (Decision A). The layering is precisely what makes that swap contained.

---

## 6. Deliverable 2 — Folder Structure

```
zenith-ai-v2/
├── app/                          # INTERFACE — unchanged in shape, routes get thinner
│   └── api/
│       ├── missions/             # NEW — replaces ad hoc /api/orchestrate-style naming going forward
│       │   ├── route.ts          #   POST /api/missions  → starts a mission
│       │   └── [id]/stream/route.ts
│       ├── alerts/  billing/  documents/  memory/  portfolio/  push/  subscription/  cron/  admin/
│       │                           #   ← your existing routes, untouched, migrated to thin
│       │                              controllers over time (Section 19)
│
├── components/                    # INTERFACE — unchanged; business logic keeps moving OUT
│   └── ...ZenithAIV2.jsx, TradingPanel.jsx, PriceChart.jsx, etc.
│
├── core/                          # ★ NEW — the Foundation this whole document is about
│   ├── kernel/
│   │   ├── event-bus.ts           # EventBus interface + in-process impl
│   │   ├── result.ts              # Result<T,E>, error hierarchy
│   │   └── logger.ts              # structured logger interface
│   ├── di/
│   │   └── container.ts           # composition-root container
│   ├── config/
│   │   └── env.ts                 # Zod-validated, typed config — replaces scattered process.env
│   ├── agents/
│   │   ├── agent-manifest.ts      # the new Agent contract (Section 7.2)
│   │   └── agent-registry.ts      # typed registry — wraps, doesn't replace, AgentRegistry.js
│   ├── tools/
│   │   └── tool-contract.ts       # ToolDefinition — formalizes TOOL_SCHEMAS' shape
│   ├── plugins/
│   │   └── plugin-contract.ts     # Section 11
│   └── pipeline/
│       └── mission-pipeline.ts    # Intent→Planning→Execution→Validation→Reflection→Memory→Learning
│
├── lib/                           # DOMAIN + APPLICATION — existing modules, incrementally typed
│   ├── agents/                    #   AgentRegistry.js + tier1-5 files — unchanged Phase 1
│   ├── orchestrator/              #   OrchestratorV3.js's stage functions get called BY
│   │                              #   core/pipeline/mission-pipeline.ts, not replaced (Section 19)
│   ├── memory/  alerts/  portfolio/  billing/  push/
│   └── infra/                     # ★ NEW — driven adapters, extracted from module-scope singletons
│       ├── ai/anthropic-provider.ts   #   wraps `new Anthropic(...)` behind a ModelProvider port
│       ├── db/supabase-client.ts
│       └── tools/  mexc-client.ts, coingecko-client.ts, bravesearch-client.ts, midtrans-client.ts
│
├── supabase/migrations/           # unchanged convention — numbered, continues from 017
├── tests/ (or co-located *.test.ts)
└── docs/adr/                      # ★ NEW — one file per future architectural decision (Section 19.4)
```

**Rule enforced by this layout:** anything under `core/` imports nothing from `app/`, `components/`, or `lib/`. Everything else may import from `core/`. This single rule, enforced by lint (Section 9.2), is what keeps the Kernel a kernel.

---

## 7. Deliverable 3 — Core Engine Design

This is the two most important artifacts in Phase 1: the **Mission Pipeline** (the "always think in terms of Intent → Planning → … → Continuous Improvement" requirement, made real) and the **Agent Manifest** (what every one of the 100 — and the 10,000th — agents must declare).

### 7.1 The Mission Pipeline

Your orchestrator already implements most of this pipeline; it just isn't named as one. Here's the exact mapping — nothing in the "today" column changes behavior in Phase 1, it gets wrapped:

| Pipeline Stage | Today (unchanged) | Phase 1 |
|---|---|---|
| **Intent** | `runOrchestration()`'s tier/quota resolution (`resolveModelForUser`) | Formalized as `IntentStage` — same function, called through the pipeline interface |
| **Planning** | `supervisorNode()` | Wrapped as `PlanningStage` |
| **Execution** | `agentDispatcherNode()` + `executeAgentWithRetry()` | Wrapped as `ExecutionStage` |
| **Validation** | *Implicit* — Tier 5 "Validate" agents run as regular dispatched subtasks, not a distinct gate | ★ **New, explicit** `ValidationStage` — Tier 5 results get a real pass/fail/confidence gate before compilation, instead of being just another agent output |
| **Reflection** | *Doesn't exist as a stage* | ★ **New** `ReflectionStage` — a lightweight post-run check ("did this mission's output match its plan's stated goal?"), logged as an event, not blocking in Phase 1 |
| **Memory** | `agentMemory.extractFromRun()` (already async/non-blocking — correct) | Wrapped as `MemoryStage`, unchanged logic |
| **Learning** | Implicit — future recalls benefit from what got remembered | Made observable: every `MemoryStage` write is a published event, so future analytics can measure what's actually improving recall quality over time |
| **Continuous Improvement** | N/A | Not a Phase 1 stage — it's the *reason* every stage above publishes events: Phase 2+ analytics/evals consume the event stream this phase creates |

```typescript
// core/pipeline/mission-pipeline.ts (see kit/ for the full file)
export interface PipelineStage<In, Out> {
  readonly name: string;
  run(input: In, ctx: MissionContext): Promise<Out>;
}

export interface MissionContext {
  missionId: string;        // = today's taskId, renamed at the type level only
  userId: string;
  eventBus: EventBus;
  logger: Logger;
}
```

Each stage publishes `mission.<stage>.started` / `.completed` / `.failed` on the Event Bus (Section 8) — which is what turns your existing `logEvent()` calls from "the only thing that happens" into "one subscriber among several."

### 7.2 The Agent Manifest

Every field below is either a direct rename of something that already exists (no behavior change) or a genuinely new, optional-by-default field (additive, non-breaking). See `kit/core/agents/agent-manifest.ts` for the complete, compilable interface — this is the shape:

```typescript
interface AgentManifest {
  identity: { id: string; displayName: string; tier: 1|2|3|4|5; responsibility: string };
  io: { inputs: string[]; outputs: string[] };
  tools: { allowedTools: string[]; maxToolRoundsPerRun?: number };
  memory: { canReadSharedMemory: boolean; canWriteSharedMemory: boolean;
            canReadCrossSessionMemory: boolean; canWriteCrossSessionMemory: boolean };
  permissions: { requiredScopes?: string[] };                    // reserved, Phase 2+ multi-workspace
  cost: { maxTokens: number; maxCostUsdPerRun?: number };
  reliability: {
    retryStrategy: { maxAttempts: number; backoff: 'exponential'|'fixed'; baseDelayMs: number;
                     retryableFailureClasses: Array<'timeout'|'rate_limit'|'tool_error'|'invalid_output'> };
    fallbackAgentId?: string;      // replaces OrchestratorV3.js's central FALLBACK_AGENTS map
    typicalConfidence?: 'low'|'medium'|'high';
  };
  observability: { emits?: string[] };
  systemPrompt: string;            // unchanged — still composed via shared fragments like RESEARCH_HOUSE_RULES
  limitations?: string[];
}
```

**Migration is additive, not a breaking rename.** A thin adapter (`toLegacyAgent(manifest)`) produces exactly today's `{ name, displayName, tier, systemPrompt, maxTokens }` shape, so `OrchestratorV3.js` needs **zero changes** to keep working while agents migrate to manifests one tier at a time. `fallbackAgentId` on Tier 1's `alex` starts as `'blake'` — copied straight out of the current `FALLBACK_AGENTS` map, not redesigned.

---

## 8. Deliverable 4 — Event Bus Design

```typescript
// core/kernel/event-bus.ts (full version in kit/)
interface DomainEvent<T = unknown> {
  id: string; type: string; occurredAt: string;
  correlationId: string;      // = today's taskId
  source: string;              // e.g. "pipeline.executionStage"
  payload: T;
}
interface EventBus {
  publish<T>(event: Omit<DomainEvent<T>, 'id'|'occurredAt'>): Promise<void>;
  subscribe<T>(eventType: string, handler: (e: DomainEvent<T>) => void|Promise<void>): () => void;
  subscribeAll(handler: (e: DomainEvent) => void|Promise<void>): () => void;
}
```

**Naming convention:** `<domain>.<entity>.<pastTenseAction>` — `mission.planning.completed`, `agent.execution.failed`, `memory.fact.extracted`. Lowercase, dot-separated, past tense (it's an announcement of something that happened, never a command).

**Migration path — wrap, don't replace:** your existing `logEvent(supabase, taskId, ...)` becomes a `subscribeAll` handler registered once at the composition root:

```typescript
eventBus.subscribeAll(async (event) => {
  await logEvent(supabase, event.correlationId, event.source, event.type, event.payload);
});
```

Every call site in `OrchestratorV3.js` that currently calls `logEvent(...)` directly instead calls `eventBus.publish(...)` — the Postgres write still happens, on the same table, with the same shape, it just now has company. SSE progress streaming, live cost dashboards, and Alerts-reacting-to-Trading-events (currently impossible without new polling) all become `eventBus.subscribe('trading.position.opened', ...)` calls with no changes to the publishers.

**Ordering & delivery:** in-process, synchronous-per-handler, at-least-once within a single invocation (Decision C). This is intentionally not a durable message queue in Phase 1 — your `execution_log` table already *is* the durable record (a de facto outbox), so nothing is lost even if a specific in-memory subscriber throws; `subscribeAll`/`subscribe` handlers should be wrapped to catch and log, never let a subscriber failure break the publisher.

---

## 9. Deliverable 5 — Dependency Graph

```
Interface ──▶ Application ──▶ Domain ──▶ Kernel
                  │               │
                  └────▶ Infrastructure ◀┘
                         (implements Domain's ports; Domain never imports Infrastructure directly)
```

**Rules (enforced, not just documented):**

1. `core/kernel/**` imports nothing outside itself. No exceptions.
2. `core/agents`, `core/tools`, `core/plugins` (Domain) may import `core/kernel`, never `lib/infra`.
3. `lib/infra/**` (Infrastructure) implements interfaces defined in `core/**`; it may import `core/kernel` and the specific `core/{agents,tools}` interface it's adapting, nothing from `app/`.
4. `app/**` and `components/**` (Interface) may import from `core/` and `lib/`, but `core/` and `lib/` never import from `app/` or `components/`.
5. No module under `lib/<domain>/` imports from another `lib/<other-domain>/` directly — cross-domain calls go through `core/pipeline` or the event bus (Section 10 elaborates the actual bounded contexts).

### 9.1 Enforcement — this is the part most teams skip

Documented rules rot. Two mechanical enforcements make them real:

- **ESLint** — `eslint-plugin-boundaries` or `import/no-restricted-paths`, configured with the exact rule list above, run in CI. A PR that imports `lib/infra/db/supabase-client.ts` from `core/agents/agent-manifest.ts` fails the build, not code review.
- **Dependency-cruiser** (`depcruise`) — generates an actual dependency graph image from the real import graph on every CI run, so drift is visible, not just blocked.

See `diagrams/architecture-layers.mermaid` for the target-state graph these tools verify against.

---

## 10. Deliverable 6 — Module Boundaries

Nine bounded contexts, each owning its own tables, files, and vocabulary. This is DDD applied to what you already have — the boundaries below match your existing `lib/` folders almost exactly; the change is making the boundary *enforced* (Section 9.1) rather than incidental.

| Bounded Context | Owns (today) | Public port (what other modules may call) |
|---|---|---|
| **Agents** | `lib/agents/*`, `AgentRegistry.js` | `getAgentManifest(id)`, `getAllAgentManifests()` |
| **Missions** *(new name for what `orchestrator` does)* | `lib/orchestrator/*` | `runMission(intent, ctx)` — the only entry point other modules ever call |
| **Memory** | `lib/memory/AgentMemory.js`, `SharedMemory.js` | `recall()`, `remember()`, `extractFromRun()` — unchanged signatures |
| **Tools** | `lib/orchestrator/agentTools.js`, `lib/tools/ToolExecutor.js` | `getToolsForAgent(manifest)`, `executeTool(name, input)` |
| **Trading** | MEXC integration, `TradingPanel.jsx`'s data layer, SMC engine | `getPositions()`, `getSignals()` — Trading never reads Portfolio's tables directly |
| **Portfolio** | `lib/portfolio/pnl.js`, `PortfolioDashboard.jsx` | `getSnapshot(userId)`, `computePnl(...)` |
| **Alerts** | `lib/alerts/*` | `checkAlerts()`, `backtest(...)` — subscribes to `trading.*` events rather than polling Trading's tables |
| **Documents** | `DocumentEditor.jsx`, `/api/documents/refine` | `refine(doc)` |
| **Billing** | `lib/billing/midtrans.js`, subscription routes | `resolveTier(userId)` — this is the **one** cross-cutting port every other context is allowed to call directly, since tier-gating happens before anything else runs (matches today's `runOrchestration()` order) |

**The one rule that matters most:** Alerts reacting to Trading is currently solved by Alerts polling on a cron. Post-Event-Bus, it's `eventBus.subscribe('trading.position.opened', checkAlertsForPosition)`. Same outcome, no new cross-module import, no new polling.

---

## 11. Deliverable 7 — Plugin System

Two plugin surfaces — Tools and Agents — because those are your two "unlimited X" requirements that actually need third-party extensibility. (Workspaces and models are configuration, not plugins — see Section 12.)

```typescript
// core/plugins/plugin-contract.ts (full version in kit/)
interface ToolPlugin {
  manifest: { id: string; version: string; description: string; author: string };
  definition: ToolDefinition;                 // input_schema shape, matches TOOL_SCHEMAS today
  execute(input: unknown, ctx: ToolExecutionContext): Promise<ToolResult>;
  permissions: { network: boolean; requiresApiKey?: string };  // declared, checked before execution
}

interface AgentPlugin {
  manifest: AgentManifest;                    // Section 7.2 — a plugin agent IS a manifest
  source: 'built-in' | 'marketplace' | 'workspace-custom';
}
```

**Grounded migration:** `agentTools.js`'s `TOOL_SCHEMAS` object already has almost exactly the `ToolDefinition` shape (`name`, `description`, `input_schema`) — this section formalizes what's there, adds an `execute` function reference and declared `permissions` (today, every tool implicitly has full network access; Phase 1 makes that explicit and auditable), and gives every tool a stable `id` a `ToolRegistry` can validate against an agent manifest's `allowedTools` list at dispatch time — replacing the current "tier number implies tool set" indirection with an explicit, per-agent grant, still tier-defaulted for convenience.

**Sandboxing note (honest scope-setting):** Phase 1 defines the *interface* contracts a marketplace needs. It does **not** implement code sandboxing for third-party tool execution — that's a real security project (likely a V8 isolate or a queued worker with strict egress rules) that belongs to whichever phase actually opens the marketplace to non-Anthropic-reviewed tools. Building the interface now and the sandbox later is the correct order; building the sandbox before there's a plugin to sandbox is wasted effort.

---

## 12. Deliverable 8 — Configuration System

```typescript
// core/config/env.ts (full version in kit/)
import { z } from 'zod';
const EnvSchema = z.object({
  ANTHROPIC_API_KEY: z.string().min(1),
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
  MIDTRANS_SERVER_KEY: z.string().min(1),
  CRON_SECRET: z.string().min(1),
  // ...every key from .env.example, one place, validated at boot, not at first use
});
export const env = EnvSchema.parse(process.env);   // throws loudly at startup, not silently at runtime
```

**Fixes 3.5 concretely:** model tier pricing moves from a hardcoded constant with a calendar-reminder comment to a small versioned table:

```typescript
const PRICING_HISTORY: Record<ModelTier, Array<{ effectiveFrom: string; priceIn: number; priceOut: number }>> = {
  core: [
    { effectiveFrom: '2026-01-01', priceIn: 2, priceOut: 10 },
    { effectiveFrom: '2026-09-01', priceIn: 3, priceOut: 15 },
  ],
};
// resolvePricing(tier, new Date()) picks the entry with the latest effectiveFrom <= now.
```

Same runtime behavior on both sides of Aug 31, 2026 — the difference is it's now correct *by construction* instead of *by someone remembering.*

**Layering (Phase 1 → later):** `defaults.ts` (safe fallbacks) → `env` (Zod-validated, current) → *(reserved for Phase 2+)* per-workspace override once multi-workspace exists. Feature flags follow the same shape: a typed `flags.ts` object today, a real flag service only once you have enough surface area (>1 workspace, >1 environment cohort) to need runtime toggling without a redeploy.

---

## 13. Deliverable 9 — Logging System

You already have the hardest part of structured logging solved: **`taskId` already threads through every function in the orchestrator as a correlation key.** This section just names that pattern and extends it past the orchestrator's boundary.

```typescript
interface Logger {
  debug(msg: string, ctx?: Record<string, unknown>): void;
  info(msg: string, ctx?: Record<string, unknown>): void;
  warn(msg: string, ctx?: Record<string, unknown>): void;
  error(msg: string, err: Error, ctx?: Record<string, unknown>): void;
  child(bindings: Record<string, unknown>): Logger;   // e.g. logger.child({ missionId, agentId })
}
```

- **Correlation:** `missionId` (= today's `taskId`) is bound once per mission via `.child()` and appears on every subsequent log line automatically — no more threading it through every function signature by hand.
- **Redaction:** a fixed deny-list (`ANTHROPIC_API_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `MIDTRANS_SERVER_KEY`, `CRON_SECRET`, `ADMIN_SECRET`, `VAPID_PRIVATE_KEY` — every secret in `.env.example`) is redacted at the logger boundary, not left to call-site discipline.
- **Levels:** `debug` off in production by default; `warn`/`error` always flow to whatever the eventual log sink is (Vercel's own logs today; nothing stops you from also `subscribeAll`-ing the event bus into a log aggregator later — same pattern as Section 8's Supabase writer).

---

## 14. Deliverable 10 — Error Handling Strategy

Two error universes, kept explicitly separate — this is the single highest-leverage change in this document for reducing "why did this silently fail" debugging time:

1. **Domain outcomes** (an agent's tool call returned an error, a validation failed, a retry budget was exhausted) — these are *expected*, modeled as data, never thrown. `runToolCallLoop`'s `{ success: boolean; error?: string }` return shape already does this correctly for tool results; Phase 1 generalizes it to a `Result<T, E>` type used consistently across Domain code.
2. **Infrastructure failures** (network timeout, Supabase connection refused, malformed API response) — these are *exceptional*, thrown, caught at the Infrastructure/Application boundary, and translated into a Domain-level `Result` failure before Domain code ever sees them.

```typescript
type Result<T, E = DomainError> = { ok: true; value: T } | { ok: false; error: E };
class DomainError extends Error { constructor(public code: string, message: string, public cause?: unknown) { super(message); } }
class ToolExecutionError extends DomainError {}
class AgentExecutionError extends DomainError {}
class ValidationError extends DomainError {}
```

**Retry vs. fallback — the concrete upgrade over today's uniform 2-retry policy:** `AgentReliability.retryStrategy.retryableFailureClasses` (Section 7.2) means a `timeout` retries the *same* agent (transient), while an `invalid_output` failure goes straight to `fallbackAgentId` (a different agent, same capability, per `tier1_research.js`'s own documented fallback pairings) without wasting a retry on a failure class retrying won't fix. Same two mechanisms you have today (retry, fallback) — now chosen by failure type instead of always both in the same fixed order.

**Circuit breaker (new, for external tools):** MEXC/CoinGecko/BraveSearch calls get a simple per-provider circuit breaker (open after N consecutive failures within a window, half-open retry after a cooldown) so one degraded external API doesn't cascade into every agent that uses it retrying in lockstep and burning the retry budget on a provider that's already down.

---

## 15. Deliverable 11 — Observability Strategy

**What you already track:** `costTracking` (mutated in place, threaded through the pipeline) and per-agent `tokens`/`cost` on every `writeAgentResult` call. This is real cost observability — Phase 1 formalizes it into metrics rather than a passed-by-reference accumulator object, but doesn't change what's measured.

**What to add:**

- **Tracing:** one span per Mission Pipeline stage, keyed by `missionId`, with `agentId`/`tool name` as span attributes on the Execution stage's children — this turns "was it Planning or Execution that took 4 seconds" from a log-diffing exercise into a trace waterfall.
- **Per-agent metrics**, sourced directly from the new manifest fields: actual cost vs. `cost.maxCostUsdPerRun`, actual latency, and (once `ReflectionStage` exists) actual vs. `reliability.typicalConfidence` — this is what turns the manifest from documentation into a feedback loop.
- **Cost optimization, concretely available today:** with 100 agents sharing large fixed system-prompt fragments (`RESEARCH_HOUSE_RULES` and equivalents) on every call, **prompt caching** is directly applicable — mark the shared, unchanging prefix (house rules, tool definitions) as cacheable so repeated calls within the cache window reuse it instead of reprocessing full price. Work that doesn't need a live answer — nightly `extractFromRun` memory consolidation, `backtestEngine` runs, portfolio snapshot generation — are exactly the "can wait, not staring at a screen" workloads the **Batch API** is priced for. Both are additive to your existing tier-resolution cost tracking, not a replacement for it. Current mechanics and pricing multipliers change over time — verify specifics at `docs.claude.com` before implementing rather than hardcoding numbers here (the same lesson as Section 3.5's pricing table).
- **Dashboards:** cost-per-mission, cost-per-agent, fallback-trigger-rate (a rising fallback rate on one agent is an early signal its prompt or tool access has drifted from what the task actually needs), and cache-hit-rate once prompt caching lands.

---

## 16. Deliverable 12 — State Management Strategy

Three explicit state categories — the current codebase already separates these instinctively (extracting `pnl.js`'s pure math out of `PortfolioDashboard.jsx` is exactly "don't mix server-derived state with component state"); this section names the categories so the separation is a rule, not an instinct.

| State category | Owns | Recommended tool | Why |
|---|---|---|---|
| **Server state** | Anything from Supabase or the orchestrator (portfolio snapshots, agent results, alerts) | React Query or SWR | Caching, revalidation, and loading/error states you're currently likely hand-rolling per component |
| **Streaming state** | SSE mission progress (`/api/alerts/stream`, future `/api/missions/[id]/stream`) | A small reducer per stream, fed by `EventSource` | Streaming state is fundamentally different from request/response server state — trying to force it through the same cache invalidation model as React Query causes more bugs than it prevents |
| **UI-local state** | Panel open/closed, form inputs, chart zoom level | `useState`/`useReducer`, no global store needed | Zustand/Redux are justified only when state is genuinely shared across distant components — audit before reaching for one |

**No prescription to introduce Zustand/Redux wholesale** — that's a decision to make against your actual component tree, which wasn't in this upload. The rule that matters regardless of library choice: **no business logic in components** (already your own explicit rule) means `PriceChart.jsx`, `TradingPanel.jsx`, etc. receive already-computed data and dispatch already-defined actions; they don't compute P&L, don't decide alert thresholds, don't call Supabase directly.

---

## 17. Deliverable 13 — Coding Standards

### 17.1 TypeScript rollout (mechanics for Decision B)

- `core/**`: `strict: true`, no exceptions, from file one.
- Existing `.js`/`.jsx`: add `// @ts-check` + JSDoc types opportunistically when a file is already being edited for another reason — this lights up real type-checking in the editor without a rename or a build-config change.
- A file converts from `.js` → `.ts` only as part of an unrelated, already-planned change to that file (the strangler pattern, Section 19) — never a dedicated "convert to TS" PR touching dozens of files at once.

### 17.2 Rules, made mechanical (not just written down)

| Rule | Enforcement |
|---|---|
| No business logic in UI | ESLint custom rule flags Supabase/Anthropic imports inside `components/**` |
| No God modules | A file-length lint warning at 300 lines, error at 500 — `OrchestratorV3.js` (575 lines) is the concrete baseline this is calibrated against; it fails the new rule today, which is correct — it's the file the rule exists for (Section 19 decomposes it) |
| No magic strings for event types / agent ids / tool names | All three are `const enum`-style unions generated from the manifests/registries (Section 6), not free strings |
| Composition over inheritance | Enforced by convention + code review — TS interfaces and object composition throughout `core/`, no class hierarchies deeper than one level anywhere in the kit |
| No circular dependencies | `dependency-cruiser` in CI (Section 9.1) — also directly fixes the `await import('../memory/SharedMemory.js')` dynamic-import-as-circular-dependency-workaround currently in `runOrchestration()` |

---

## 18. Deliverable 14 — Naming Conventions

| What | Convention | Example |
|---|---|---|
| Files (new, `core/`) | kebab-case | `agent-manifest.ts` |
| React components | PascalCase (already your convention) | `TradingPanel.jsx` |
| Event types | `domain.entity.pastTenseAction` | `mission.planning.completed` |
| Agent ids | lowercase, single word, stable forever (already your convention — `alex`, `blake`) | `alex` |
| Tool ids | `snake_case`, verb-first (already your convention) | `get_coin_price` |
| DB migrations | zero-padded sequential number + snake_case description (already your convention) | `017_event_outbox_index.sql` |
| Env vars | `SCREAMING_SNAKE_CASE` (already your convention) | `ANTHROPIC_API_KEY` |

Nothing above changes an existing convention — it's written down because "already your convention, informally" is exactly what breaks the moment a second contributor joins without three months of osmosis.

---

## 19. Deliverable 15 — Migration Plan

**Strangler-fig, not a rewrite.** Every step below adds a new file and wraps an old one; nothing is deleted until the wrapper has been running in production, unchanged in behavior, for at least one release cycle.

| Phase | Change | Touches | Risk |
|---|---|---|---|
| **1a** | Add `core/kernel/*` (event bus, Result type, logger, config) — pure addition, nothing calls it yet | New files only | None — unused code |
| **1b** | Register `eventBus.subscribeAll(...)` wrapping today's `logEvent` at the composition root; replace `logEvent(...)` call sites in `OrchestratorV3.js` with `eventBus.publish(...)` one at a time | `OrchestratorV3.js` (mechanical find-replace per call site) | Low — same DB writes, same shape, verifiable by diffing `execution_log` rows before/after |
| **1c** | Add `core/agents/agent-manifest.ts` + `toLegacyAgent()` adapter. Migrate **one** tier (start with Tier 1, 20 agents) to manifests; `AgentRegistry.js` calls `toLegacyAgent()` at the boundary so `OrchestratorV3.js` is untouched | `lib/agents/tier1_research.js` (additive fields only) | Low — adapter guarantees identical shape out |
| **1d** | Extract `ModelProvider` port; move `new Anthropic(...)` into `lib/infra/ai/anthropic-provider.ts`; inject it into `OrchestratorV3.js` the same way `callModel` is already injected into `runToolCallLoop` | `OrchestratorV3.js` (constructor → parameter) | Low — same pattern already proven in this exact file |
| **1e** | Wrap `supervisorNode`/`agentDispatcherNode`/`resultCompilerNode` as `PlanningStage`/`ExecutionStage`/(partial)`ValidationStage` behind `core/pipeline/mission-pipeline.ts`; add `ReflectionStage` as a new, non-blocking, logged-only stage | New pipeline file calls existing functions; existing functions unchanged | Medium — first place old and new code compose; needs the integration test suite from 19.3 before merging |
| **1f** | Resolve the test-runner question (3.6): confirm whether the referenced Jest suite still exists; if yes, standardize on one runner and port the other; if no, `node:test` is already the standard — document it as such | Test config only | Low, but blocks confident CI going forward — do this early, not last |
| **2+** | Migrate remaining tiers to manifests; extract remaining `lib/infra` adapters (MEXC, CoinGecko, BraveSearch, Midtrans); enforce dependency-graph lint in CI; decompose `OrchestratorV3.js`'s persistence functions into `lib/infra/db/*` | Broader, scheduled per-module | Managed by the boundary lint added in 9.1 |

**Rollback:** every step above is additive or a like-for-like call-site swap — reverting any single commit in 1a–1e restores the exact prior behavior, because the old function being wrapped is never deleted in this plan.

---

## 20. CTO Review Mode — Design Review & Risk Audit

Arguing with the proposal above, the way it would actually get questioned in a design review.

**What assumptions is this making?**
That Vercel + Supabase remains the deployment target through at least the next 2 phases (the in-process event bus and modular-monolith call both depend on this); that "unlimited agents" means thousands, not literally unbounded (the manifest is an object, not infinitely cheap — at some agent count, `AgentRegistry.js`'s in-memory object-spread becomes the bottleneck, not the architecture, see below); and that you, not a large platform team, are the primary implementer, which is why Decision D rejects a DI framework a bigger team might reasonably choose instead.

**What breaks first at 1M users?** Not the layering — the **in-process event bus** (Decision C) and **Supabase connection count** under serverless fan-out. Both have a named swap-path already (Redis/Upstash pub-sub; Supabase connection pooling via PgBouncer, already Supabase's own recommended fix at scale) — the point of defining ports in Section 8/9 is that this swap doesn't touch Domain code.

**What breaks first at 10,000 agents?** `AgentRegistry.js`'s flat in-memory object stops being the right data structure — 10,000 manifests with prompts loaded eagerly at cold start is a real memory/cold-start-latency cost on serverless. This is a Phase 2+ problem (lazy-load manifests from a `agent_manifests` table instead of bundling them, indexed by tier/capability) — flagging it now because the **manifest schema in Section 7.2 is designed to be storable as JSONB**, specifically so this migration is "move the data," not "redesign the shape," when it's actually needed.

**What breaks first at hundreds of concurrent missions?** `MAX_CONCURRENT_AGENTS = 30` is a per-mission cap, not a global one — nothing today prevents 50 concurrent missions × 30 agents each from exceeding your Anthropic rate limits simultaneously. This needs a global concurrency governor (a token-bucket in front of the `ModelProvider` port from 19d) before it's a production concern — noted as a Phase 2 item, not solved here, because solving it well needs real production concurrency numbers this document doesn't have.

**What should never become tightly coupled, no matter what ships next?** The Agent Manifest schema and the Event Bus's event-name taxonomy. Both are the two contracts every future module (Browser, Calendar, Analytics, Enterprise Workspace) will depend on — a breaking change to either has the widest blast radius in the system by design, which is exactly why both get a versioned, additive-only change policy starting now (new optional fields, never renamed/removed required ones, without a major version bump documented in `docs/adr/`).

**What would a Stripe/Linear/Anthropic reviewer push on?** Three things, honestly: (1) *"Where's the idempotency key on `publish()`?"* — fair; Phase 1's in-process bus doesn't need one (single invocation, no redelivery), but the interface should reserve the field now so the Redis swap doesn't become a breaking change later — **addressed, see kit**. (2) *"You're proposing a plugin system with no sandboxing — is that shippable?"* — correctly scoped in 11 as interface-now/sandbox-later, but worth saying plainly here too: **do not open Tool/Agent plugins to untrusted third parties before the sandboxing work in 11 actually exists.** (3) *"Why no formal schema migration tool beyond raw numbered SQL files?"* — your current convention (`004`–`016`, sequential, RLS-first) is genuinely fine at this scale; revisit only if multiple engineers start writing migrations concurrently and numbering collisions become real, not before.

**Where I'd push back on the original brief:** it asks for all 15 deliverables to include Migration Strategy, Testing Strategy, *and* Performance Impact as separate subsections each. I've folded these into prose and tables throughout rather than repeating three boilerplate headers fifteen times — the content is all here (every section either states what's being tested/migrated/impacted or points at Section 19's unified plan), but fifteen mechanically identical headers would have cost you readability for a compliance checkbox. If you want the literal 10-subsection-per-deliverable format for an internal audit, tell me and I'll regenerate that view — it's a formatting pass on content that already exists here, not new architectural work.

---

## 21. Appendix A — Where the interfaces live

Every interface referenced above is a real, compiling `.ts` file, not just a code block in this doc — see `kit/` (manifest in Section 23). Reading order: `kernel/result.ts` → `kernel/event-bus.ts` → `kernel/logger.ts` → `agents/agent-manifest.ts` → `tools/tool-contract.ts` → `plugins/plugin-contract.ts` → `config/env.ts` → `di/container.ts` → `pipeline/mission-pipeline.ts`.

## 22. Appendix B — Explicitly out of scope for Phase 1 (and why)

- **Multi-workspace / enterprise tenancy** — `permissions.requiredScopes` is reserved in the manifest, but building real workspace isolation now, before there's a second workspace, is speculative generality the brief itself warns against (YAGNI).
- **Plugin sandboxing** — see Section 11; interface now, sandbox when there's an actual third-party plugin to sandbox.
- **Full TypeScript conversion of existing files** — Decision B; incremental by design.
- **Vector/semantic memory** — `AgentMemory`'s current `recall()` is preserved as-is; a `MemoryStore` port (implicit in Section 7's Memory context boundary) is where a future embeddings-backed implementation would plug in, but building it now with only one implementation is premature abstraction.
- **Microservice extraction** — Decision A; the point of Phase 1 is making this *cheap later*, not doing it now.

## 23. What's in this delivery

```
zenith-phase1-foundation/
├── ARCHITECTURE.md                          ← this document
├── diagrams/
│   ├── architecture-layers.mermaid          ← Section 5's 5-layer diagram, dependency-annotated
│   └── intelligence-pipeline.mermaid        ← Section 7.1's pipeline, mapped to real function names
└── kit/                                      ← real, compiling TypeScript — drop into core/ as-is
    ├── README.md                             ← how to wire this into the existing Phase 6 repo
    └── core/
        ├── kernel/{event-bus,result,logger}.ts
        ├── agents/agent-manifest.ts
        ├── tools/tool-contract.ts
        ├── plugins/plugin-contract.ts
        ├── config/env.ts
        ├── di/container.ts
        └── pipeline/mission-pipeline.ts
```

Next natural step, if useful: I can execute **Phase 1a–1c** from Section 19 directly against your actual `OrchestratorV3.js` and `AgentRegistry.js` — not a description of the change, the actual diff — once you've had a chance to push back on anything above.
