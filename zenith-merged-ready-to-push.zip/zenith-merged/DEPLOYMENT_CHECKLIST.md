# Deployment Checklist — Zenith AI v2 Phase 6+

Everything from this session, in the order to actually do it. Each step
says why it matters, not just what to click.

## Step 0 — Already done for you this session

- ✅ Supabase database (`zenith-ai`, was paused, now restored) migrated —
  17 migrations applied directly, live schema matches this code.
- ✅ Security audit on every new DB function — verified directly against
  the database, not just the advisor's cache.
- ✅ Every file in this bundle syntax-checked (`node --check` for .js,
  TypeScript's parser for .jsx) and cross-referenced for broken imports.
- ✅ 31 automated tests written and passing for the pure business logic.

## Step 1 — Merge these files into your real repo

This zip only contains what changed/was added this session — it's not a
full project. You have two ways to bring it into your actual `Zenith-AI`
GitHub repo:

**Option A — GitHub Desktop (no terminal):**
1. Open your local clone of `Zenith-AI` in Finder/Explorer.
2. Extract this zip, then drag-and-drop each file into the matching folder
   in your local repo (create new folders like `app/api/billing/` if they
   don't exist yet — matching the same path as in this zip).
3. Open GitHub Desktop → it should show all the new/changed files.
4. Write a commit message (e.g. "Phase 6: alerts, payments, 3-tier models"),
   click **Commit to main**, then **Push origin**.

**Option B — Terminal, if you're comfortable with it:**
```bash
cd path/to/your/Zenith-AI
# copy the extracted files over, preserving folder structure, then:
git add .
git commit -m "Phase 6: alerts, payments, 3-tier models, tests"
git push origin main
```

## Step 2 — Install the two new packages

```bash
npm install midtrans-client web-push
```
Do this locally first — commit the updated `package.json`/`package-lock.json`
and push again, so Vercel installs them too on deploy.

## Step 3 — Add environment variables

Use `.env.example` (in this zip) as the checklist. For each one:
- **Local**: add to `.env.local`
- **Production**: Vercel dashboard → your project → Settings → Environment
  Variables → add each one → redeploy after saving

Get real values for: `SUPABASE_SERVICE_ROLE_KEY` (Supabase dashboard),
`MIDTRANS_SERVER_KEY`/`MIDTRANS_CLIENT_KEY` (Midtrans dashboard, sandbox
first), `CRON_SECRET`/`ADMIN_SECRET` (generate your own random strings),
`OWNER_USER_IDS` (your own Supabase user ID). VAPID keys are already
provided, ready to use.

## Step 4 — Deploy to Vercel and check the build

Push (Step 1) should auto-trigger a Vercel deployment if it's already
connected to this repo. **Watch the build log** — this is the first time
this exact code has ever been built. If it fails, the error message will
point at the specific file/line; paste it back to me and I'll fix it.

## Step 5 — Set up the two external cron jobs

Neither of these can use Vercel's own Cron Jobs (Hobby plan caps those at
once/day — far too infrequent). Both use the same free external scheduler:

At [cron-job.org](https://cron-job.org), create two jobs:

| URL | Schedule | Header |
|---|---|---|
| `/api/cron/check-alerts` | every 1-2 min | `Authorization: Bearer <CRON_SECRET>` |
| `/api/cron/expire-subscriptions` | once daily | `Authorization: Bearer <CRON_SECRET>` |

## Step 6 — Configure the Midtrans webhook

Midtrans dashboard → Settings → Configuration → Payment Notification URL:
```
https://<your-app>.vercel.app/api/billing/webhook
```
Easy to forget, and without it no payment ever actually activates a
subscription no matter how many times you test it.

## Step 7 — Test in this order

1. **Load the app** — confirm it builds and the chat UI loads at all.
2. **Trigger one orchestration request** — confirms `resolveModelForUser`
   and the Supervisor/Fusion changes work end-to-end. Check the response
   actually comes back, and check `orchestration_usage_daily` in Supabase
   got a row.
3. **Create + backtest an alert** in the Alerts panel — confirms auth +
   rate limiting on that route work, and exercises `getMexcKlines`/
   `runMTFAnalysis` for real (the one part of this session's code I
   couldn't verify myself, since those files weren't in this bundle).
4. **Enable push notifications** and trigger a test alert — confirms the
   service worker registers and a real push notification arrives.
5. **Sandbox payment** — use Midtrans's test credentials, complete a fake
   QRIS payment, confirm `user_subscriptions.tier` flips to `paid`.
6. **Manually backdate `expires_at`** on your test subscription, hit
   `/api/cron/expire-subscriptions` yourself, confirm it flips back to
   `free`.

## Step 8 — Go live

Once sandbox testing passes: swap Midtrans keys to production, flip both
`MIDTRANS_IS_PRODUCTION` vars to `true`, update the webhook URL in
Midtrans's production settings (separate from sandbox settings).
