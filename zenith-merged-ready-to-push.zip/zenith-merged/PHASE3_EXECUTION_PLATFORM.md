# Zenith AI — Phase 3: Execution Platform

**The runtime layer that turns a planned Mission into work actually being done — by an AI agent, a human, a browser, or whatever executes work five years from now.**

| | |
|---|---|
| **Status** | Proposed — one open dependency, see §0.2 |
| **Scope** | Runtime/execution layer only. Sits below Mission Intelligence, above Workers. |
| **Basis** | Phase 1 (`core/`, real, in your repo) + the actual Phase 6 codebase (`OrchestratorV3.js` et al.) + this brief |
| **Format note** | Per this phase's explicit instruction, no code or pseudocode below — contracts are described as tables, not `.ts` files (Phase 1's kit was code because that brief asked for it; this one doesn't) |

---

## 0.1 How to read this document

24 subsystems were requested, each with a 15-part format — literally applied, that's 360 sections, most of them repeating the same boilerplate under a different name. Instead: the 24 are grouped into 15 substantive sections organized the way you'd actually navigate this system (model → contract → lifecycle → runtime → durability → resilience → observability → security → performance → scale → migration), and **§20 is a coverage map** — every one of the 24 named subsystems, mapped to exactly where it's addressed, so you can audit completeness in one glance instead of trusting my organization.

## 0.2 Dependency note — please read before the rest

This brief says Phase 2 ("Mission Intelligence": Intent Analyzer, Executive Supervisor, Mission Planner, Task Graph, Capability Routing, Reflection Engine, Validation Engine, Confidence Engine, Response Composer, Mission Lifecycle, Mission Timeline, Shared Context) is complete and production-ready, and instructs me not to redesign it.

I want to flag directly: **I have no record of Phase 2 as real code.** Everything I have is Phase 1 (`core/` — Event Bus, Logger, DI, Result, Config, Plugin/Tool Registry, Agent Manifest, all real files in your repo) and the actual Phase 6 codebase (`OrchestratorV3.js` and friends). Phase 1's kit includes a `mission-pipeline.ts` with generic Intent/Planning/Execution/Validation/Reflection/Memory *stages* — conceptually adjacent to what you're calling Phase 2, but nowhere near as fleshed out as a Task Graph, Capability Routing table, or a standalone Confidence Engine.

Two possibilities, and I don't know which is true: **(a)** you built Phase 2 separately (another session, or by hand) and it exists somewhere I haven't seen, or **(b)** this brief describes Phase 2 prescriptively — the target shape, not yet built. Either way, blocking on this felt worse than being explicit about it, so here's what I did: **§2.2 below defines the minimal contract Phase 3 needs from Phase 2** (a `TaskGraph` shape and a few call signatures) — clearly marked as an assumption, not a verified interface. If real Phase 2 code exists, send it and I'll re-ground Phase 3 against the actual shapes, the same way Phase 1 got re-grounded once I actually read `zenith-phase6-fixed.zip` instead of guessing. If it doesn't exist yet, this section doubles as a lightweight spec for it.

---

## 1. Executive Summary

Phase 3's one real idea: **the runtime executes Workers, not Agents.** An AI agent, a human approval step, a browser automation run, a MEXC order, a future robot — all of them enter the runtime through the same contract (§5) and move through the same state machine (§6), and none of that contract knows or cares which one it's holding. This is what makes "unlimited future worker types" true by construction instead of by promise.

The second real idea, and the one most likely to get skipped under a brief this ambitious: **this has to work on what you're actually deployed on.** You're on Vercel (Hobby tier, per `DEPLOYMENT_CHECKLIST.md`) with Supabase as your only durable store, and zero message-queue infrastructure today. A serverless function is time-boxed and doesn't persist a process between invocations — so "Checkpoint Manager," "Distributed Scheduling," and "<10ms dispatch" all mean something different here than they would on a fleet of long-running workers. §9 and §15 handle this head-on rather than quietly assuming infrastructure you don't have. The design below runs **today**, on your current stack, at the concurrency you actually need — with every seam in place to swap in a real worker fleet, queue, and scheduler later without touching the Worker contract, the Event taxonomy, or Mission Intelligence.

Everything here wraps `agentDispatcherNode()` / `executeAgentWithRetry()` the same way Phase 1 wrapped `logEvent()` — formalized, not replaced.

---

## 2. Grounding

### 2.1 What's real today (verified, not assumed)

| Layer | Real artifact | Relevance to Phase 3 |
|---|---|---|
| Kernel (Phase 1) | `core/kernel/event-bus.ts`, `logger.ts`, `result.ts` | Phase 3's Event Bus is the *same* bus, extended with a new event catalog (§13) — not a second bus |
| Contracts (Phase 1) | `core/agents/agent-manifest.ts`, `core/tools/tool-contract.ts`, `core/plugins/plugin-contract.ts` | `AgentManifest.reliability` (retryStrategy + fallbackAgentId) is the exact shape §10's Resilience Policy generalizes to every Worker kind |
| Pipeline (Phase 1) | `core/pipeline/mission-pipeline.ts` | Its `execution` stage is precisely where Phase 3 plugs in — this document is what's *inside* that stage |
| Current execution reality | `lib/orchestrator/OrchestratorV3.js`: `agentDispatcherNode()`, `executeAgentWithRetry()`, `buildDependencyGraph()`, `chunkArray()`, `MAX_CONCURRENT_AGENTS = 30`, `MAX_AGENT_RETRIES = 2` | This already **is** a rudimentary Dispatcher + Scheduler + Dependency Resolver, fused into one function. Phase 3 separates what's fused, keeps what works. |
| Durable state | Supabase `execution_log`, `agent_results` tables | Already, informally, an execution log and a checkpoint store — §9 formalizes what's already happening |
| Deployment | Vercel, Hobby tier, external cron for anything the platform's own scheduler can't trigger | The single biggest constraint on this whole document — see §9 and §15 |

### 2.2 Assumed Mission Intelligence contract (Phase 2 bridge — see §0.2)

The absolute minimum Phase 3 needs from whatever sits upstream of it:

| Element | Assumed shape | Notes |
|---|---|---|
| `TaskGraph` | A set of task nodes, each with: a stable `taskId`, `dependsOn: taskId[]`, a `targetCapability` (what kind of Worker can satisfy it — e.g. an agent id, a tool id, `"human_approval"`), and an `input` payload | Directly generalizes `buildDependencyGraph()`'s existing node/edge shape — same idea, one more field (`targetCapability`) so Phase 3 doesn't have to know it's specifically an *agent* id |
| `MissionPlan` | A `TaskGraph` plus `missionId`, `userId`, and priority | Produced by whatever Phase 2 calls its planner; consumed by Phase 3's Dispatcher (§7) as its only input |
| A callback back into Mission Intelligence | Something Phase 3 calls once all tasks resolve, handing back the raw results for Phase 2's Response Composer / Validation Engine to finish | Mirrors today's `resultCompilerNode()` receiving `agentDispatcherNode()`'s output |

Nothing in §§4–19 depends on more than this. If real Phase 2 code turns out to have a richer shape, the Dispatcher's input contract is the one place that needs updating — everything downstream of it (Scheduler, Worker Pool, Workers, state machine) is unaffected.

---

## 3. Core Philosophy — Workers, Not Agents

A **Worker** is anything that can accept an input, do something with it (possibly over time, possibly involving a human), and produce an output or fail. Today's AI agents are the first Worker kind implemented, not a special case the runtime is built around.

**How an Agent becomes a Worker** — the pattern that keeps this honest rather than aspirational: a thin adapter (`AgentWorker`) wraps an `AgentManifest` (Phase 1) and implements the Worker contract (§5) by calling into whatever executes an agent turn today (`executeAgentWithRetry()`, eventually Phase 2's actual execution call). The Dispatcher never imports `AgentManifest` directly — it only ever sees `Worker`. The same pattern produces `ToolWorker` (wrapping `ToolDefinition` from Phase 1), and, when they exist, `HumanApprovalWorker`, `BrowserWorker`, `TradingEngineWorker`, `ExternalServiceWorker` — each an adapter, none of them special-cased in the runtime.

**Why this is the load-bearing decision in this document:** every "future X" requirement in the brief (robotics, IoT, edge devices, a marketplace of third-party workers) reduces to "write one more adapter." None of them require touching the Dispatcher, Scheduler, state machine, or Event Bus. That's the entire test of whether this abstraction is real: can a genuinely new worker kind show up in two years without a design review of the runtime itself? By construction, yes — provided nothing outside `lib/infra/workers/**` (the adapter layer) ever imports a concrete worker-kind type.

---

## 4. The Execution Model

```
MissionPlan (§2.2)
      │
      ▼
  Dispatcher ──────────────► reads TaskGraph, creates one Execution per ready task
      │
      ▼
  Scheduler ───────────────► decides order/priority within the concurrency budget
      │
      ▼
  Worker Pool ──────────────► assigns an available Worker instance to the Execution
      │
      ▼
  Worker.run() ─────────────► does the work; may stream; may checkpoint
      │
      ▼
  Execution Events ─────────► published to the Event Bus at every transition (§13)
      │
      ▼
  Execution Store ──────────► durable record (Supabase) — what Mission State is built from
      │
      ▼
  Mission State updated ────► Dispatcher checks: any newly-ready tasks? loop; else →
      │
      ▼
  Callback to Mission Intelligence (Composer, per §2.2)
      │
      ▼
  Response
```

See `diagrams/execution-model-flow.mermaid` for the annotated version, including the Event Bus as a spine (matching Phase 1 §7.1's pipeline-events pattern exactly).

**Grounded mapping:** `agentDispatcherNode()` today does Dispatcher + Scheduler + Worker Pool assignment in one pass, over one flat list of subtasks. Splitting it into three named components doesn't change what runs first — it changes what's independently swappable. The Scheduler is the one most likely to need a different implementation later (priority queue, external queue) without the Dispatcher or Worker Pool caring.

---

## 5. The Worker Contract

Every Worker — regardless of kind — is described by one contract. No `.ts` file here per this brief's instruction; this is the field-level spec an implementation must satisfy.

| Section | Field(s) | Description |
|---|---|---|
| **Identity** | `workerId`, `kind`, `version` | `kind` is an open string, not a closed enum — `'agent'`, `'tool'`, `'human_approval'`, `'browser_automation'`, `'api_request'`, `'file_operation'`, `'trading_engine'`, `'external_service'`, and anything registered later |
| **Responsibilities** | `capability` | What `targetCapability` values (§2.2) this Worker can satisfy — an `AgentWorker` for `alex` declares capability `"agent:alex"`; a `ToolWorker` for CoinGecko declares `"tool:get_coin_price"` |
| **Lifecycle hooks** | `assign()`, `run(input, ctx)`, `cancel()` *(optional)*, `healthCheck()` | `cancel()` is optional and honestly so — an in-flight fetch to an external API can't always be aborted mid-flight; a Worker that can't truly cancel must say so, not pretend to |
| **Inputs / Outputs** | `inputSchema`, `outputSchema` | Same JSON-schema-shaped contract as Phase 1's `ToolDefinition.input_schema` — one pattern, reused, not reinvented |
| **Capabilities** | `supportsStreaming`, `supportsCheckpointing`, `supportsCancellation` | Declared booleans — the runtime checks these before promising a caller something the Worker can't do |
| **Permissions** | `permissions: { network, requiresApiKey?, requiredScopes? }` | Directly extends Phase 1's `ToolPermissions` / `AgentManifest.permissions` shape to every Worker kind, not just tools |
| **Execution limits** | `maxDurationMs`, `maxCostUsdPerRun` | `maxCostUsdPerRun` reuses `AgentCostProfile` verbatim; `maxDurationMs` is new — and must be ≤ whatever the hosting invocation's own time budget is (§9) |
| **Timeout / Retry rules** | `resiliencePolicy` | See §10 — the exact `AgentReliability.retryStrategy` shape from Phase 1, generalized |
| **Cancellation rules** | `cancellationBehavior: 'graceful' | 'hard' | 'unsupported'` | What happens when `cancel()` is called or unavailable |
| **Streaming support** | `emitsChunks: boolean` | If true, the Worker publishes `execution.stream.chunk` events (§13) as it produces partial output |
| **Metrics** | *(no new field — see §12)* | Every Worker gets latency/cost/token metrics for free from the Execution Store; a Worker never reports its own metrics, so a misbehaving Worker can't lie about its own health |
| **Health checks** | `healthCheck()` | Cheap, side-effect-free — used by the Health Monitor (§12) and, for external-service Workers, by the circuit breaker (§10) |
| **Failure recovery** | *(governed by §9/§10, not declared per-Worker)* | A Worker doesn't decide its own recovery strategy — the platform does, from the resilience policy, so recovery behavior is consistent and auditable across every Worker kind |
| **Extension points** | `kind` is open; adapters live in `lib/infra/workers/**`, one file per kind | Adding a Worker kind is adding a file, exactly like adding an agent is adding an object to a tier file in Phase 1 |

---

## 6. Execution Lifecycle & State Machine

States (16, as specified): `Created → Queued → Waiting → Scheduling → Executing → [Streaming] → [Checkpointing] → Completed`, with `Retrying`, `Paused/Resuming`, `Recovering`, `Cancelled`, `Failed`, `TimedOut` as branches off the main line. Full transition diagram: `diagrams/execution-state-machine.mermaid`.

**Every failure path, explicitly:**

| Where it can fail | What happens |
|---|---|
| Queue is at capacity when a task becomes ready | `Waiting` — held, not rejected; re-evaluated every Scheduler tick. A queue that silently drops work under load is worse than one that's briefly slow. |
| No Worker available for the required capability | `Waiting`, with a distinct reason code (`no_capable_worker`) so this is visibly different from ordinary backpressure in metrics (§12) |
| Worker crashes immediately on start | → `Retrying` if the resilience policy's `retryableFailureClasses` covers it, else straight to `Failed` with a fallback lookup (§10) |
| Checkpoint write fails | The *execution* does not fail because of it — retried on its own short backoff, logged as a distinct warning; losing a checkpoint write must never be conflated with losing the work it describes |
| Validation fails (Phase 2's Validation Engine rejects the output) | Same branch as a worker-level failure — `Retrying` or `Failed`+fallback, decided by the same resilience policy, not a second parallel failure system |
| Timeout during `Executing` or `Streaming` | `TimedOut` → Cancellation Engine attempts `cancel()` if supported, else the execution is marked orphaned and the Dispatcher proceeds without waiting for it → resilience policy decides retry vs. fallback |
| External cancellation requested | `Cancelled` — propagated via `execution.cancellation.requested` (§13); cleanup runs regardless of whether the Worker's own `cancel()` succeeded |
| Resilience policy exhausted, no fallback | `Failed` → Dead Letter Queue (§10) |
| Mid-mission process restart (a serverless invocation ends before completion) | `Recovering` on the next invocation that picks the mission back up — see §9, this is the state serverless reality makes unavoidable and worth designing for directly rather than around |

---

## 7. Scheduling & Dispatch

| Subsystem | What it is here, concretely | Grounded in |
|---|---|---|
| **Dispatcher** | Consumes a `MissionPlan`; for every task whose `dependsOn` are all satisfied, creates an `Execution` and hands it to the Scheduler. Owns nothing about *when* — only *what's ready*. | `agentDispatcherNode()`'s existing readiness check |
| **Dependency Resolver** | Pure function: `TaskGraph` → topologically-sorted ready sets. No I/O. | `buildDependencyGraph()` — already close to pure; this is an extraction, not a rewrite (same move as Phase 1's `pnl.js`/`backtestEngine.js` precedent) |
| **Execution Scheduler** | Within the concurrency budget, picks which ready Execution actually starts next | Today: array order + `MAX_CONCURRENT_AGENTS = 30`. Phase 3: same cap, plus explicit priority (mission priority from §2.2, then FIFO) |
| **Priority Scheduler** | Not a separate subsystem — priority is one input to the Execution Scheduler's ordering, not a second scheduler competing with the first | Avoids two components arguing over the same decision |
| **Execution Queue** | In-process (array/set) within one invocation — because that's honestly what you have today. See §9 for what changes when a mission outlives one invocation. | `chunkArray()`'s batching |
| **Rate Limiting** | Per-provider token bucket in front of the Worker Pool's `assign()` call — specifically for external APIs (Anthropic, MEXC, CoinGecko, BraveSearch) where the limit isn't yours to set | New — flagged in Phase 1 §20 as a Phase 2+ concern; this is where it actually lands |

**Concurrency ceiling, stated honestly:** `MAX_CONCURRENT_AGENTS = 30` is a per-mission cap today (Phase 1 §20 already flagged this). Phase 3's Scheduler makes it a **platform-wide** budget, shared across concurrently-running missions, specifically so 50 concurrent missions can't each independently believe they have 30 slots and collectively blow through your Anthropic rate limits. This is a behavior change from today, called out because it's the one place this document intentionally does more than formalize existing behavior.

---

## 8. Worker Management

| Subsystem | Design |
|---|---|
| **Worker Registry** | A capability → Worker-kind lookup. In Phase 3a: in-memory, populated at composition-root time from `lib/infra/workers/**` adapters (mirrors Phase 1's `AgentRegistry.js` pattern exactly). Moves to Supabase-backed once the registered-capability count makes eager loading costly (same trigger condition as Phase 1 §20's agent-manifest JSONB migration). |
| **Worker Pool** | Doesn't pool *processes* (there are none to pool on serverless) — pools *capacity*: how many concurrent instances of a given Worker kind are allowed to run at once, independent of the platform-wide concurrency budget. An `AgentWorker` calling Opus and a `ToolWorker` calling CoinGecko shouldn't share a capacity limit; they compete for different scarce resources (cost/rate-limit vs. a free API's rate limit). |
| **Worker Lifecycle** | `Registered → Assignable → Assigned → Running → Idle` (back to Assignable) or `Retired`. "Idle" and "pooled long-running instance" only mean something once Workers run on infrastructure that persists between calls (§16) — on serverless, a Worker's lifecycle today is really just `Assigned → Running → done`, and this document says so rather than describing pool warm-up behavior you can't have yet. |

---

## 9. State & Durability — the section serverless reality actually decides

This is the one place in the brief where "design for 100,000 workers" and "you're on Vercel Hobby with only Supabase" pull in genuinely different directions, so it gets the most direct treatment.

**The constraint:** a serverless function invocation is time-boxed and does not persist a process across invocations. There is no long-lived memory a "Checkpoint Manager" can simply hold state in between one worker finishing and the next one starting, if that gap crosses an invocation boundary. Anything Phase 3 calls durable *must* be a Supabase write, or it isn't durable — full stop.

**What this means concretely, per subsystem:**

- **Execution Context** — exists in memory *within* one invocation (the current mission's in-flight state, exactly like today). Never assumed to survive past the invocation that created it.
- **Execution Store** — Supabase, and it already exists: `execution_log` + `agent_results`, exactly as they are today. Phase 3 doesn't invent a new store; it defines what gets written to the existing one (an `Execution` row per task, keyed by `missionId` + `taskId`, status, and last-known state).
- **Checkpoint Manager** — you have been doing this, informally, since Phase 6: every `writeAgentResult()` call *is* a checkpoint. Phase 3 formalizes the checkpoint as "the Execution Store row for this task is up to date as of event X" — no new infrastructure, a naming and consistency exercise on top of what's already being written.
- **Recovery Engine** — on any new invocation (a user re-opening a mission, or a cron sweep for missions that went quiet mid-run), read the Execution Store for the mission, recompute the ready-set from the Dependency Resolver against what's actually completed, and resume from there. This is genuinely implementable today, on current infrastructure — it's a read + a topological sort, not a new subsystem.

**What doesn't work today, said plainly:** true cross-invocation *queueing* (a task waiting for a worker slot that isn't currently running in any invocation) needs something outside the current stack — at minimum a scheduled sweep (another cron job, same pattern as the two you already run via cron-job.org) that periodically resumes stalled missions; at most, a real queue service once volume justifies the operational cost. **Recommendation for Phase 3a: the cron-sweep approach.** It's honest about what you have, ships without new infrastructure, and the Recovery Engine described above is the exact same code path either way — a queue service later changes *what triggers* recovery, not *how* recovery works.

---

## 10. Resilience Policies

Not four separate engines competing for the same decision — **one policy, generalized from `AgentManifest.reliability` in Phase 1**, attached to every Worker:

| Element | Shape (same as Phase 1's `AgentReliability`, generalized) |
|---|---|
| Retry | `maxAttempts`, `backoff: exponential \| fixed`, `baseDelayMs`, `retryableFailureClasses` — but the failure-class vocabulary is now Worker-kind-specific: an `AgentWorker` retries on `timeout \| rate_limit \| tool_error \| invalid_output` (unchanged from Phase 1); a `BrowserWorker` might retry on `element_not_found \| navigation_timeout`; a `TradingEngineWorker` on `exchange_timeout \| stale_quote`. One policy shape, many vocabularies — the shape is what the Dispatcher understands; the vocabulary is the adapter's business. |
| Fallback | `fallbackWorkerId?` — directly generalizes `fallbackAgentId` |
| Timeout | `maxDurationMs` from the Worker contract (§5) is the hard ceiling; the Timeout Engine is the thing enforcing it, not a separate declared policy |
| Cancellation | Governed by the Worker's declared `cancellationBehavior` (§5) — the Cancellation Engine's job is dispatching the signal and handling the `unsupported` case honestly (mark orphaned, move on), not pretending every Worker can be stopped cleanly |
| Dead Letter Queue | An execution that exhausts retries *and* has no fallback (or whose fallback also exhausts) lands here — a Supabase table, `execution.deadletter.created` published, available for manual replay or automated alerting. Nothing is silently dropped; this is where "we don't know what to do with this" becomes visible instead of lost. |

**Circuit breaker** (Phase 1 §14 flagged this for external tools — it lives here): per external-provider (MEXC, CoinGecko, BraveSearch, Anthropic itself), open after N consecutive failures within a window, half-open retry after cooldown. Prevents every Worker that depends on a degraded provider from independently retrying in lockstep and burning the platform-wide concurrency budget on a provider that's already down.

---

## 11. Streaming

`execution.stream.chunk` events (§13) are published by any Worker with `emitsChunks: true`, and relayed to whichever SSE connection the mission's client has open — the same mechanism your `/api/alerts/stream` route already uses, and the same one Phase 1 §6 proposed for `/api/missions/[id]/stream`. The Streaming Engine's actual job is narrow: buffer chunks for a client that briefly disconnects and reconnects (so a flaky mobile connection doesn't lose output), and cap buffer size so a client that never reconnects doesn't leak memory in a long-running invocation.

---

## 12. Observability

Extends Phase 1's Event Bus + Logger — does not stand up a second system next to them.

| Subsystem | Design |
|---|---|
| **Metrics Collector** | A `subscribeAll` handler on the Event Bus (same pattern as Phase 1 §8's Supabase writer) that aggregates `execution.*` events into per-Worker-kind and per-mission latency/cost/retry-rate numbers |
| **Tracing** | One span per Execution, keyed by `missionId` + `taskId`, child spans for retries — extends Phase 1 §15's "one span per pipeline stage" down one more level, into the stage's actual work |
| **Health Monitor** | Polls each registered Worker kind's `healthCheck()` on an interval; feeds the circuit breaker (§10) and a simple platform-status view |
| **Execution Audit Log** | Not a new table — the Execution Store (§9) *is* the audit log, provided nothing overwrites a row in place (append-only status transitions, not a single mutable `status` column with no history) |

---

## 13. Event Model

The brief's proposed names are PascalCase (`ExecutionCreated`, `WorkerAssigned`, …). Phase 1 §18 already established the event-naming convention for this platform: lowercase, dot-separated, `<domain>.<entity>.<pastTenseAction>`. Holding that line rather than letting each new phase invent its own casing:

| Requested | Zenith taxonomy |
|---|---|
| ExecutionCreated | `execution.instance.created` |
| ExecutionQueued | `execution.instance.queued` |
| ExecutionStarted | `execution.instance.started` |
| WorkerRegistered | `worker.registry.registered` |
| WorkerAssigned | `execution.worker.assigned` |
| WorkerStarted | `execution.worker.started` |
| WorkerHeartbeat | `execution.worker.heartbeat` |
| WorkerCompleted | `execution.worker.completed` |
| WorkerFailed | `execution.worker.failed` |
| WorkerTimedOut | `execution.worker.timed_out` |
| WorkerRetried | `execution.worker.retried` |
| CheckpointCreated | `execution.checkpoint.created` |
| CheckpointLoaded | `execution.checkpoint.loaded` |
| ExecutionPaused | `execution.instance.paused` |
| ExecutionResumed | `execution.instance.resumed` |
| ExecutionCancelled | `execution.instance.cancelled` |
| ExecutionRecovered | `execution.instance.recovered` |
| ExecutionCompleted | `execution.instance.completed` |
| StreamingStarted | `execution.stream.started` |
| StreamingChunk | `execution.stream.chunk` |
| StreamingCompleted | `execution.stream.completed` |
| DeadLetterCreated | `execution.deadletter.created` |

Every one of these is a `DomainEvent<T>` (Phase 1's `core/kernel/event-bus.ts` type, unchanged) with `correlationId = missionId`. No new event type, no new bus.

---

## 14. Security

| Concern | Design |
|---|---|
| Execution isolation | Each Execution's context (§9) is scoped to one `missionId`/`taskId` — Workers never receive another execution's context, by construction (the Dispatcher builds the context, the Worker only ever sees what it's handed) |
| Permission boundaries | Enforced at Worker Pool assignment time, from the Worker's declared `permissions` (§5) — a Worker without `network: true` should structurally be unable to reach an adapter that makes an HTTP call, not merely instructed not to |
| Worker sandbox | Same honest scope as Phase 1 §11: this document defines the permission *contract*; it does not implement code-level sandboxing (V8 isolate or equivalent) for untrusted third-party Workers. Don't open the Worker Registry to unreviewed third parties before that exists — same rule as Phase 1's Plugin System. |
| Tool permission model | Reuses Phase 1's `ToolPermissions` exactly — a `ToolWorker` adapter *is* a `ToolPlugin`, not a parallel concept |
| Secret isolation | Reuses Phase 1 §13's Logger redaction — no new secret-handling code path |
| Rate limiting | §7/§10's per-provider circuit breaker + token bucket |
| Audit logging | §12's Execution Audit Log |
| Failure containment | One Worker's failure never blocks unrelated ready tasks — the Dispatcher continues dispatching everything else in the ready set regardless of one task's outcome |

---

## 15. Performance Targets — Reality Check

Taking the brief's numbers seriously means scoping them honestly rather than restating them as achieved. Each one, evaluated:

| Target | Verdict | Why |
|---|---|---|
| Task Dispatch <10ms | **Achievable — scope it to warm, in-memory only.** The dispatch decision itself (pick next ready task) is a pure in-memory operation. It stops meaning anything the moment it includes a cold serverless start or a Supabase round-trip, and it will include one of those on a fair number of real invocations. |
| Scheduler <5ms / Worker Assignment <5ms / Queue Processing <5ms | **Same caveat as above.** All three are in-memory decisions today; state them as "decision latency," separate from any I/O the decision triggers. |
| Streaming Latency <50ms | **Realistic as stated**, once a stream is established — this is normal SSE relay overhead. Exclude initial connection setup from this number; that's a different, larger budget. |
| Checkpoint Save <20ms | **Optimistic as a hard ceiling.** This is a Supabase network write — 20ms is plausible for a well-colocated p50, not a safe guarantee for p99. Recommend: 20ms p50 target, a separately-stated (larger) p99 budget, and — critically — a checkpoint write that's merely slow must never be allowed to fail the execution it's describing (§6). |
| Mission Recovery <100ms | **Depends entirely on mission size.** Fine for a handful of tasks; optimistic for a mission with hundreds. Recommend splitting this into "recovery *decision* latency" (how fast the system notices and starts recovering — genuinely sub-100ms) versus "full state reconstruction time" (scales with mission size, and should be allowed to). |

None of this is a rejection of the targets — it's the difference between a target that's true because it's been scoped honestly and one that's true until the first cold start proves it wasn't.

---

## 16. Scale Path — 100 → 100,000 Workers

| Scale | What's actually true |
|---|---|
| **100** | Today's design, as specified above, fully sufficient. No infrastructure changes. |
| **1,000** | Worker Registry moves from in-memory to Supabase-backed (same trigger, same fix, as Phase 1 §20's agent-manifest migration). Nothing about the Worker or Dispatcher contract changes. |
| **10,000** | This is where a real external queue earns its operational cost, and where the Scheduler plausibly becomes a long-running process rather than a Vercel function — because *that specific component*, not the whole platform, needs to persist state between decisions faster than a database round-trip allows. The Worker contract is exactly what makes this swap contained: Workers and the Dispatcher don't know or care where the Scheduler lives. |
| **100,000** | Genuinely a different deployment — likely multi-region, dedicated Worker fleets, real cluster orchestration. **Said plainly: no real system reaches 1,000x scale with literally zero redesign, and a document that claimed otherwise wouldn't survive the review this brief itself asks for.** What *is* true, and is the actual promise this architecture makes: the **contracts** (Worker interface, Event taxonomy, Resilience policy shape) don't change at any of these scales — only the **deployment** of Scheduler and Worker Pool does. That's a narrower claim than "no redesign," and it's the one this document can actually back. |

---

## 17. Testing Strategy

One consolidated strategy, not 24 repeated subsections:

- **Dependency Resolver** — pure function, tested the same way `pnl.js`/`backtestEngine.js` already are (Phase 1 §2.2's precedent): no mocks, table-driven cases including cycles and diamond dependencies.
- **Dispatcher / Scheduler** — tested against fake Workers (instant-resolve, instant-fail, never-resolve) the same way `runToolCallLoop()` is already tested against injected `callModel`/`callTool` fakes.
- **Worker adapters** (`AgentWorker`, `ToolWorker`, …) — one contract test suite, run against every registered adapter, asserting the Worker contract's declared capabilities are actually true (e.g., a Worker that declares `supportsCancellation: true` actually stops within a bounded time when `cancel()` is called).
- **State machine** — every transition in §6's table gets a test asserting the *only* reachable next states from each state — this is what catches an accidental illegal transition (e.g., `Cancelled → Executing`) before it ships.
- **Recovery** — integration test: kill a mission mid-run (simulate an invocation ending), assert the next invocation's Recovery Engine resumes from the correct ready-set.

---

## 18. Migration & Integration Plan

Strangler-fig, same discipline as Phase 1 §19 — every step wraps an existing function, nothing is deleted until its wrapper has run unchanged in production for a release cycle.

| Step | Change | Touches | Risk |
|---|---|---|---|
| **3a** | Define the Worker contract + `AgentWorker`/`ToolWorker` adapters. Nothing calls them yet. | New files only | None |
| **3b** | Extract `buildDependencyGraph()` into a standalone, pure Dependency Resolver; `agentDispatcherNode()` calls the extracted version instead of its inline logic — same output, tested in isolation now | `OrchestratorV3.js` (extraction, not rewrite) | Low |
| **3c** | Introduce the platform-wide concurrency budget (§7) alongside the existing per-mission `MAX_CONCURRENT_AGENTS`; run both for one release to confirm the platform-wide cap doesn't starve any single mission unexpectedly, then retire the per-mission-only cap | `OrchestratorV3.js` | Medium — the one genuine behavior change in this document; ship it observable (§12) before relying on it |
| **3d** | Formalize Execution Store writes on top of existing `execution_log`/`agent_results` — additive columns/rows, not a schema replacement | Supabase migration (append-only) | Low |
| **3e** | Add the cron-sweep Recovery Engine (§9) as a third scheduled job, alongside the two `DEPLOYMENT_CHECKLIST.md` already documents | New cron endpoint | Low — same pattern, proven twice already |
| **3f** | Wire the resilience policy (§10) to actually replace `FALLBACK_AGENTS` and the fixed retry constants, once Phase 1 §19's step 1c (Agent Manifest migration) has landed for at least one tier | `OrchestratorV3.js`, `AgentManifest` instances | Low — this step is *why* Phase 1's manifest migration should land before this one |

---

## 19. CTO Review Mode

**Can this support 100,000 workers?** The contracts can. The deployment described can't, and §16 says so directly instead of implying otherwise.

**Distributed execution?** Not in Phase 3a — intentionally. The Worker/Dispatcher/Scheduler separation is what makes distributing it later a deployment change instead of a rewrite; that's the actual claim, not "this is already distributed."

**Enterprise SaaS?** Same deferral as Phase 1 §22: workspace scoping isn't built, but the Execution Context (§9) reserves a `workspaceId` field now, unused until there's a second workspace to isolate.

**Cloud-native deployment?** Today's target is Vercel, not Kubernetes. The separation this document insists on is exactly what makes a future K8s-hosted Scheduler + Worker Pool a swap behind the same Worker contract, not a new design.

**AI Agents, Humans, APIs, Browser Automation, future types?** Yes, by the adapter pattern in §3 — the test that matters (a new Worker kind needs no runtime design review) is stated explicitly, not just asserted.

**Would OpenAI, Anthropic, DeepMind, or Stripe approve this?** Yes to the contracts, the phased rollout, and the honesty in §15/§16. **No** to shipping the brief's performance numbers as unqualified hard SLOs — a reviewer at any of those companies would ask "p50 or p99? warm or cold? in-memory or including I/O?" before approving a single one of them, which is exactly why §15 answers that instead of restating the numbers. And no reviewer would sign off on "100,000 workers, zero redesign" as literally written — §16 is the version of that claim I'd actually defend in a design review.

**Where I'd push back on the brief, directly:** the "24 subsystems × 15 sections" output format, taken literally, optimizes for the appearance of thoroughness over actually-load-bearing content — most of those 360 cells would restate the same two or three real design decisions (Worker contract, resilience policy, event taxonomy) under different headings. I organized around the real decisions instead and mapped every requested subsystem to where it's actually covered (§20). Same trade I made in Phase 1's review, for the same reason.

---

## 20. Subsystem Coverage Map

Every subsystem named in the brief, mapped to where it's addressed:

| Requested subsystem | Covered in |
|---|---|
| Execution Platform (overall) | §1, §4 |
| Execution Runtime | §4, §7 |
| Dispatcher | §7 |
| Execution Scheduler | §7 |
| Priority Scheduler | §7 (folded into Scheduler — one decision, not two) |
| Worker Registry | §8 |
| Worker Pool | §8 |
| Worker Lifecycle | §8 |
| Execution Queue | §7, §9 |
| Dependency Resolver | §7 |
| Execution Context | §9 |
| Execution Store | §9 |
| Execution State Machine | §6 |
| Checkpoint Manager | §9 |
| Recovery Engine | §9 |
| Retry Engine | §10 |
| Timeout Engine | §10 |
| Cancellation Engine | §10 |
| Streaming Engine | §11 |
| Metrics Collector | §12 |
| Tracing System | §12 |
| Health Monitor | §12 |
| Dead Letter Queue | §10 |
| Execution Audit Log | §12 |
| Worker Contract | §5 |
| Execution Lifecycle | §6 |
| Event Model | §13 |
| Security (all sub-items) | §14 |
| Performance targets | §15 |

---

## 21. What's next

Two things worth resolving before code:

1. **The §0.2 dependency question** — if Phase 2 exists as real code, send it; I'll re-ground §2.2 against the actual `TaskGraph`/planner shape the same way Phase 1 got re-grounded against your real `OrchestratorV3.js` instead of a guess.
2. If it doesn't exist yet, it's a genuinely smaller job than this document — §2.2 is close to a full spec for it already, and I can turn it into one directly.

Either way, Phase 3a (§18) is buildable now, against what's real today.
