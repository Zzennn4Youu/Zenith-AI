# Midtrans Billing Setup Guide

Zenith Apex — Rp 99.000/month, paid via Midtrans Snap (QRIS/GoPay/ShopeePay/
bank transfer). Recurring here means "renews each cycle when paid," not
"silently auto-charged" — QRIS/e-wallets in Indonesia require the customer
to actively scan/confirm each payment, there's no card-style auto-debit for
these channels. The reminder cron (step 5) exists specifically because of this.

## ✅ Already done (via the Supabase connector, this session)

- Ran migrations 004 through 012 against your live `zenith-ai` project —
  it was fully unmigrated before this (only 4 pre-Phase-6 tables existed).
- **Found and fixed a critical vulnerability**: `increment_daily_usage()`
  and `extend_subscription()` were callable by anyone on the internet,
  unauthenticated, through Supabase's public REST API — meaning anyone
  could have granted themselves free unlimited Zenith Apex access with a
  single HTTP request, completely bypassing payment. Fixed via migrations
  010/011 (revoke EXECUTE from `PUBLIC`, grant only to `service_role`).
  Verified directly against the database, not just by re-running the
  advisor. **If you ever write another `SECURITY DEFINER` function, revoke
  from `PUBLIC` explicitly — Postgres grants it by default.**
- Flagged (not fixed — not part of this bundle, needs your review):
  `restrict_signup()` and `check_and_log_rate_limit()` from earlier phases
  have the same publicly-callable pattern. `restrict_signup` might
  legitimately need `anon` access if it runs during signup — check intent
  before revoking.

## 1. Install the package

```bash
npm install midtrans-client
```

## 2. Get your Midtrans keys

Sign up at [midtrans.com](https://midtrans.com) → Dashboard → Settings →
Access Keys. Start in **Sandbox mode** to test end-to-end before going live.

## 3. Environment variables

```
MIDTRANS_SERVER_KEY=<sandbox or production server key — secret>
MIDTRANS_CLIENT_KEY=<sandbox or production client key — safe to expose>
NEXT_PUBLIC_MIDTRANS_CLIENT_KEY=<same value as MIDTRANS_CLIENT_KEY>
MIDTRANS_IS_PRODUCTION=false
NEXT_PUBLIC_MIDTRANS_IS_PRODUCTION=false
```

Flip both `IS_PRODUCTION` vars to `true` (and swap in production keys) only
once you've tested a full payment in sandbox.

`SUPABASE_SERVICE_ROLE_KEY` and `CRON_SECRET` are reused from the earlier
Web Push / tier-system setup — nothing new needed there if you already set
those.

## 4. Configure the webhook URL in Midtrans

Dashboard → Settings → Configuration → **Payment Notification URL**:

```
https://<your-app>.vercel.app/api/billing/webhook
```

This is the step it's easiest to forget — without it, Midtrans never tells
your app a payment succeeded, and no subscription ever activates no matter
how many test payments you make.

## 5. Add the second cron job

You already have one external cron job (cron-job.org) hitting
`/api/cron/check-alerts` every 1-2 minutes. Add a second one:

- URL: `https://<your-app>.vercel.app/api/cron/expire-subscriptions`
- Schedule: **once daily** (e.g. 3 AM)
- Header: `Authorization: Bearer <your CRON_SECRET>` (same secret, reused)

This downgrades lapsed subscriptions back to free and sends a Web Push
reminder ~2 days before expiry (reuses the Push feature — make sure that's
set up too, or reminders silently have nothing to deliver to).

## 6. Testing end-to-end (sandbox)

1. Set all env vars above with **sandbox** keys, `IS_PRODUCTION=false`.
2. Log in as a non-owner test account, open the chat, click the free-tier
   badge in the header → "Upgrade to Zenith Apex."
3. Use Midtrans's [sandbox test
   credentials](https://docs.midtrans.com/docs/testing-payment-on-sandbox)
   to complete a fake payment (e.g. their test QRIS simulator).
4. Confirm: `payment_transactions` gets a row, then flips to `settlement`;
   `user_subscriptions` for that user shows `tier='paid'` with `expires_at`
   ~30 days out; the header badge shows "⚡ Zenith Apex."
5. Manually run a query to backdate `expires_at` to yesterday, then hit
   `/api/cron/expire-subscriptions` yourself (with the right header) and
   confirm it flips back to `free`.

## 7. Going live

Swap in production Midtrans keys, flip both `IS_PRODUCTION` vars to `true`,
update the webhook URL in Midtrans's dashboard to point at the same
production URL (sandbox and production have separate settings pages).
