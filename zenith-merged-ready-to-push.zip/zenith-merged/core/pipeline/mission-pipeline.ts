/**
 * core/pipeline/mission-pipeline.ts
 *
 * Names the pipeline your orchestrator already implements and adds the
 * two stages that don't exist yet (Validation as an explicit gate,
 * Reflection as a new stage). See ARCHITECTURE.md §7.1 for the full
 * stage-by-stage mapping and §19 step 1e for how this gets introduced
 * without changing OrchestratorV3.js's existing functions.
 *
 * HONEST SCOPE NOTE: the composition below wraps runOrchestration() as a
 * single stage, because supervisorNode / agentDispatcherNode /
 * resultCompilerNode are currently fused inside it. Splitting those into
 * genuinely separate PipelineStage entries (true Planning / Execution /
 * Validation stages) is a real refactor of OrchestratorV3.js itself —
 * planned for Phase 2, done once, carefully, with integration tests in
 * place first (ARCHITECTURE.md §19 step 1f). Phase 1 only needs the SEAM
 * to exist, which this file provides without touching OrchestratorV3.js.
 */

import type { EventBus } from '../kernel/event-bus';
import type { Logger } from '../kernel/logger';

export interface MissionContext {
  /** = today's taskId. */
  missionId: string;
  userId: string;
  eventBus: EventBus;
  logger: Logger;
}

export interface PipelineStage<In, Out> {
  readonly name: string;
  run(input: In, ctx: MissionContext): Promise<Out>;
}

/**
 * Wraps a stage so it publishes mission.<name>.started/completed/failed
 * around whatever the stage actually does — this is the ONLY new
 * behavior; the wrapped function's own logic is untouched.
 */
function withEvents<In, Out>(stage: PipelineStage<In, Out>): PipelineStage<In, Out> {
  return {
    name: stage.name,
    async run(input, ctx) {
      await ctx.eventBus.publish({
        type: `mission.${stage.name}.started`,
        correlationId: ctx.missionId,
        source: `pipeline.${stage.name}`,
        payload: {},
      });
      try {
        const result = await stage.run(input, ctx);
        await ctx.eventBus.publish({
          type: `mission.${stage.name}.completed`,
          correlationId: ctx.missionId,
          source: `pipeline.${stage.name}`,
          payload: {},
        });
        return result;
      } catch (error) {
        await ctx.eventBus.publish({
          type: `mission.${stage.name}.failed`,
          correlationId: ctx.missionId,
          source: `pipeline.${stage.name}`,
          payload: { message: (error as Error).message },
        });
        throw error;
      }
    },
  };
}

/**
 * Example composition — what ARCHITECTURE.md §19 step 1e actually wires
 * up. `legacyRunOrchestration` is OrchestratorV3.js's existing
 * runOrchestration(), imported as-is; nothing inside it changes for this
 * to work.
 */
export function buildMissionPipeline(
  legacyRunOrchestration: (
    userInput: string,
    supabase: unknown,
    userId: string,
    taskId: string,
  ) => Promise<unknown>,
) {
  const planningAndExecution: PipelineStage<{ userInput: string; supabase: unknown }, unknown> = withEvents({
    name: 'planningAndExecution',
    async run({ userInput, supabase }, ctx) {
      return legacyRunOrchestration(userInput, supabase, ctx.userId, ctx.missionId);
    },
  });

  const reflection: PipelineStage<unknown, { reflected: true }> = withEvents({
    name: 'reflection',
    // New in Phase 1: non-blocking, logged-only. Does not gate the
    // mission's result — an observability addition, not a new failure
    // mode, until it's been watched in production for a while.
    async run(_missionOutput, ctx) {
      ctx.logger.info('Reflection stage ran (Phase 1: logging only, no gating)', {
        missionId: ctx.missionId,
      });
      return { reflected: true };
    },
  });

  return { planningAndExecution, reflection };
}
