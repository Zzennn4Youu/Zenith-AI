/**
 * core/kernel/result.ts
 *
 * Two error universes, kept explicitly separate (see ARCHITECTURE.md §14):
 *
 *  1. Domain OUTCOMES — an agent's tool call failed, validation failed, a
 *     retry budget ran out. Expected, modeled as data, never thrown.
 *     `runToolCallLoop`'s existing `{ success, error? }` shape in
 *     lib/orchestrator/agentTools.js already does this correctly for tool
 *     results — Result<T, E> below is that same idea, generalized and typed.
 *
 *  2. Infrastructure FAILURES — network timeout, DB connection refused,
 *     malformed API response. Exceptional, thrown, caught at the
 *     Infrastructure/Application boundary, translated into a Result
 *     failure before Domain code ever sees them.
 *
 * Nothing in lib/**.js has to change for this file to exist — it's additive
 * kernel code. Domain modules opt in as they're migrated (ARCHITECTURE.md §19).
 */

export type Result<T, E = DomainError> =
  | { ok: true; value: T }
  | { ok: false; error: E };

export function ok<T>(value: T): Result<T, never> {
  return { ok: true, value };
}

export function err<E extends DomainError>(error: E): Result<never, E> {
  return { ok: false, error };
}

export function isOk<T, E>(r: Result<T, E>): r is { ok: true; value: T } {
  return r.ok;
}

export function isErr<T, E>(r: Result<T, E>): r is { ok: false; error: E } {
  return !r.ok;
}

/**
 * Unwraps or throws. Use only at a boundary that has already decided to
 * fail hard (e.g. a route handler's outermost catch) — never inside
 * Domain code, which should be handling both branches of the Result.
 */
export function unwrap<T, E extends Error>(r: Result<T, E>): T {
  if (r.ok) return r.value;
  throw r.error;
}

/**
 * Base class for every Domain-level error. `code` is the stable,
 * machine-checkable identifier — log on this, alert on this, branch on
 * this. `message` is for humans reading logs and is free to change
 * wording without breaking anything that depends on `code`.
 */
export class DomainError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly cause?: unknown,
  ) {
    super(message);
    this.name = new.target.name;
  }
}

/** Maps to failures inside executeTool() / runToolCallLoop()'s tool_result path. */
export class ToolExecutionError extends DomainError {
  constructor(public readonly toolName: string, message: string, cause?: unknown) {
    super('TOOL_EXECUTION_FAILED', message, cause);
  }
}

/** Maps to executeAgentWithRetry()'s exhausted-retries path. */
export class AgentExecutionError extends DomainError {
  constructor(public readonly agentId: string, message: string, cause?: unknown) {
    super('AGENT_EXECUTION_FAILED', message, cause);
  }
}

/** Raised by the new ValidationStage (ARCHITECTURE.md §7.1) when a Tier-5 gate fails. */
export class ValidationError extends DomainError {
  constructor(message: string, public readonly details?: Record<string, unknown>) {
    super('VALIDATION_FAILED', message);
  }
}

/** Raised by core/config/env.ts at boot if required configuration is missing or malformed. */
export class ConfigurationError extends DomainError {
  constructor(message: string, cause?: unknown) {
    super('CONFIGURATION_INVALID', message, cause);
  }
}
