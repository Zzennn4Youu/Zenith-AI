/**
 * core/kernel/event-bus.ts
 *
 * Formalizes what lib/orchestrator/OrchestratorV3.js's logEvent() already
 * does — every meaningful lifecycle transition becomes a typed event — and
 * gives it more than one subscriber. See ARCHITECTURE.md §8 for the full
 * design and the migration path (wrap logEvent as a subscribeAll handler,
 * replace call sites one at a time).
 *
 * Naming convention for `type`: "<domain>.<entity>.<pastTenseAction>",
 * e.g. "mission.planning.completed", "agent.execution.failed".
 */

export interface DomainEvent<T = unknown> {
  id: string;
  type: string;
  occurredAt: string; // ISO 8601
  /** = today's taskId. Renamed at the type level only — same value, same column if you keep writing to execution_log. */
  correlationId: string;
  /** e.g. "pipeline.executionStage", "agent.alex" — where the event came from, for tracing. */
  source: string;
  payload: T;
  /**
   * Reserved, unused by the in-process implementation below (a single
   * invocation can't redeliver to itself). Exists now so that swapping to
   * a Redis/Upstash-backed EventBus later — the only implementation that
   * *can* redeliver — is a new adapter, not a breaking interface change.
   * See ARCHITECTURE.md §20 ("Where's the idempotency key on publish()?").
   */
  idempotencyKey?: string;
}

export type EventHandler<T = unknown> = (event: DomainEvent<T>) => void | Promise<void>;

export interface EventBus {
  publish<T>(event: Omit<DomainEvent<T>, 'id' | 'occurredAt'>): Promise<void>;
  /** Returns an unsubscribe function. */
  subscribe<T>(eventType: string, handler: EventHandler<T>): () => void;
  /** Wildcard — used for cross-cutting subscribers like the Supabase execution_log writer below. */
  subscribeAll(handler: EventHandler): () => void;
}

/**
 * Phase 1 implementation — correct for 100% of today's event flow, which
 * is entirely intra-request (see ARCHITECTURE.md §4, Decision C). Swap
 * for a Redis/Upstash pub-sub adapter behind this same interface only
 * once you actually need cross-invocation fan-out (e.g. SSE to a second
 * connected client) — don't pre-build that before it's a real requirement.
 */
export class InMemoryEventBus implements EventBus {
  private handlers = new Map<string, Set<EventHandler>>();
  private wildcardHandlers = new Set<EventHandler>();

  async publish<T>(event: Omit<DomainEvent<T>, 'id' | 'occurredAt'>): Promise<void> {
    const fullEvent: DomainEvent<T> = {
      ...event,
      id: crypto.randomUUID(),
      occurredAt: new Date().toISOString(),
    };

    const specific = this.handlers.get(fullEvent.type) ?? new Set<EventHandler>();
    const all = [...specific, ...this.wildcardHandlers];

    // Never let one subscriber's failure break the publisher or its siblings.
    await Promise.all(
      all.map(async (handler) => {
        try {
          await handler(fullEvent);
        } catch (error) {
          console.error(`[EventBus] handler failed for "${fullEvent.type}":`, error);
        }
      }),
    );
  }

  subscribe<T>(eventType: string, handler: EventHandler<T>): () => void {
    if (!this.handlers.has(eventType)) this.handlers.set(eventType, new Set());
    this.handlers.get(eventType)!.add(handler as EventHandler);
    return () => this.handlers.get(eventType)?.delete(handler as EventHandler);
  }

  subscribeAll(handler: EventHandler): () => void {
    this.wildcardHandlers.add(handler);
    return () => this.wildcardHandlers.delete(handler);
  }
}

/**
 * ─────────────────────────────────────────────────────────────────────
 * Example migration wiring for OrchestratorV3.js's existing logEvent().
 * Register this once at the composition root (core/di/container.ts),
 * then replace call sites like:
 *
 *   await logEvent(supabase, taskId, agent.name, 'agent_started', desc, meta);
 *
 * with:
 *
 *   await eventBus.publish({
 *     type: 'agent.execution.started',
 *     correlationId: taskId,
 *     source: agent.name,
 *     payload: { desc, ...meta },
 *   });
 *
 * and register the writer once:
 *
 *   eventBus.subscribeAll(async (event) => {
 *     await logEvent(supabase, event.correlationId, event.source, event.type, event.payload);
 *   });
 *
 * Same table, same shape, same durability — it just now has company.
 * ─────────────────────────────────────────────────────────────────────
 */
