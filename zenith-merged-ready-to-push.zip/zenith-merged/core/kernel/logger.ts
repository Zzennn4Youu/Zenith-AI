/**
 * core/kernel/logger.ts
 *
 * Names a pattern you already have: `taskId` already threads through
 * every function in OrchestratorV3.js as a de facto correlation key. This
 * file generalizes that into `.child()` bindings so a missionId (or
 * agentId, or userId) gets attached once and appears on every subsequent
 * log line automatically — instead of being a parameter threaded by hand
 * through every function signature. See ARCHITECTURE.md §13.
 */

export interface Logger {
  debug(msg: string, ctx?: Record<string, unknown>): void;
  info(msg: string, ctx?: Record<string, unknown>): void;
  warn(msg: string, ctx?: Record<string, unknown>): void;
  error(msg: string, err: Error, ctx?: Record<string, unknown>): void;
  /** Returns a new Logger with `bindings` merged into every future call's ctx, e.g. logger.child({ missionId, agentId }). */
  child(bindings: Record<string, unknown>): Logger;
}

/**
 * Every secret in .env.example — redacted at the logger boundary, not
 * left to call-site discipline. Extend this list if new secrets are
 * added to core/config/env.ts.
 */
const REDACTED_KEYS = new Set([
  'ANTHROPIC_API_KEY',
  'SUPABASE_SERVICE_ROLE_KEY',
  'MIDTRANS_SERVER_KEY',
  'CRON_SECRET',
  'ADMIN_SECRET',
  'VAPID_PRIVATE_KEY',
]);

function redact(ctx?: Record<string, unknown>): Record<string, unknown> | undefined {
  if (!ctx) return ctx;
  const clean: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(ctx)) {
    clean[key] = REDACTED_KEYS.has(key) ? '[REDACTED]' : value;
  }
  return clean;
}

class ConsoleLogger implements Logger {
  constructor(private bindings: Record<string, unknown> = {}) {}

  private merge(ctx?: Record<string, unknown>) {
    return redact({ ...this.bindings, ...ctx });
  }

  debug(msg: string, ctx?: Record<string, unknown>): void {
    if (process.env.NODE_ENV === 'production') return; // off in prod by default, per §13
    console.debug(JSON.stringify({ level: 'debug', msg, ...this.merge(ctx) }));
  }

  info(msg: string, ctx?: Record<string, unknown>): void {
    console.info(JSON.stringify({ level: 'info', msg, ...this.merge(ctx) }));
  }

  warn(msg: string, ctx?: Record<string, unknown>): void {
    console.warn(JSON.stringify({ level: 'warn', msg, ...this.merge(ctx) }));
  }

  error(msg: string, err: Error, ctx?: Record<string, unknown>): void {
    console.error(
      JSON.stringify({ level: 'error', msg, error: err.message, stack: err.stack, ...this.merge(ctx) }),
    );
  }

  child(bindings: Record<string, unknown>): Logger {
    return new ConsoleLogger({ ...this.bindings, ...bindings });
  }
}

/** Swap this factory's return for a pino/winston-backed implementation later — every call site depends on the Logger interface above, not on console. */
export function createLogger(): Logger {
  return new ConsoleLogger();
}
