/**
 * core/di/container.ts
 *
 * Not a DI framework — a composition root, the same pattern already
 * proven in lib/orchestrator/agentTools.js's runToolCallLoop(), which
 * receives callModel/callTool as plain parameters instead of importing
 * concrete implementations. This file just gives that pattern one place
 * to live instead of repeating it ad hoc per function. See
 * ARCHITECTURE.md §4 (Decision D) for why no framework/decorators.
 */

import type { EventBus } from '../kernel/event-bus';
import type { Logger } from '../kernel/logger';
import type { ToolRegistry } from '../tools/tool-contract';

/**
 * Everything the Application layer needs, wired once. Extend this
 * interface as new ports are extracted (ModelProvider, MemoryStore, ...)
 * — see ARCHITECTURE.md §19 step 1d for the ModelProvider extraction
 * that's the natural next addition here.
 */
export interface AppContainer {
  eventBus: EventBus;
  logger: Logger;
  toolRegistry: ToolRegistry;
}

let instance: AppContainer | null = null;

/**
 * Called exactly once, at app startup (e.g. a module-scope call in a new
 * lib/composition-root.ts) — mirrors where `const anthropic = new
 * Anthropic(...)` currently lives at the top of OrchestratorV3.js, just
 * generalized to every adapter instead of one.
 */
export function initContainer(container: AppContainer): void {
  if (instance) {
    throw new Error('[container] initContainer() called more than once — this is almost always a bug.');
  }
  instance = container;
}

/**
 * Resolve the composed container from Application/Interface code. Domain
 * and Kernel code should receive dependencies as parameters instead of
 * calling this directly — see ARCHITECTURE.md §9's dependency rules.
 */
export function getContainer(): AppContainer {
  if (!instance) {
    throw new Error('[container] getContainer() called before initContainer() — check your composition root runs first.');
  }
  return instance;
}

/** Test-only escape hatch — swap in fakes without touching the real composition root. */
export function __setContainerForTests(container: AppContainer): void {
  instance = container;
}

/** Test-only teardown, pairs with __setContainerForTests. */
export function __resetContainerForTests(): void {
  instance = null;
}
