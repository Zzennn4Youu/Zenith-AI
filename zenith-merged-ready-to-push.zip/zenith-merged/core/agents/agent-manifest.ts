/**
 * core/agents/agent-manifest.ts
 *
 * The single source of truth for what a Zenith agent IS. Every field is
 * either a typed rename of something lib/agents/*.js already has (no
 * behavior change) or a new, additive field with a safe default (nothing
 * breaks if it's omitted). See ARCHITECTURE.md §7.2 for the migration story.
 *
 * Today's actual contract, per AgentRegistry.js's own header comment:
 *   { name, displayName, tier, systemPrompt, maxTokens }
 * That shape is exactly toLegacyAgent(manifest)'s output below — the
 * orchestrator needs zero changes while agents migrate one tier at a time.
 */

export type AgentTier = 1 | 2 | 3 | 4 | 5;

export interface AgentIdentity {
  /** Stable, lowercase, single word. Never reused, even after retirement (matches today's naming: "alex", "blake", ...). */
  id: string;
  displayName: string;
  tier: AgentTier;
  /** One sentence. If the job can't be summarized in one sentence, split the agent — don't grow this field. */
  responsibility: string;
}

export interface AgentIO {
  inputs: string[];
  outputs: string[];
}

export interface AgentToolAccess {
  /**
   * Explicit per-agent grant, replacing agentTools.js's TIER_TOOL_SETS
   * (tier-number → tool list) as the source of truth. A ToolRegistry
   * (core/tools/tool-contract.ts) can still apply a tier default when
   * this is empty, for convenience — but the manifest, not the tier
   * number, is the actual permission record.
   */
  allowedTools: string[];
  /** Falls back to the pipeline default (today's MAX_TOOL_ROUNDS = 4) when unset. */
  maxToolRoundsPerRun?: number;
}

export interface AgentMemoryAccess {
  canReadSharedMemory: boolean;
  canWriteSharedMemory: boolean;
  /** AgentMemory.recall() */
  canReadCrossSessionMemory: boolean;
  /** AgentMemory.remember() / extractFromRun() */
  canWriteCrossSessionMemory: boolean;
}

export interface AgentPermissions {
  /** Reserved for Phase 2+ multi-workspace RBAC. Optional and unchecked until then. */
  requiredScopes?: string[];
}

export interface AgentCostProfile {
  maxTokens: number;
  /** Hard USD ceiling for one run of THIS agent — the pipeline aborts the agent, not the whole mission, past it. Unset = no per-agent ceiling beyond the mission-level tier cap. */
  maxCostUsdPerRun?: number;
}

export type RetryableFailureClass = 'timeout' | 'rate_limit' | 'tool_error' | 'invalid_output';

export interface AgentReliability {
  retryStrategy: {
    /** Today: hardcoded MAX_AGENT_RETRIES = 2 for all 100 agents. Now per-agent. */
    maxAttempts: number;
    backoff: 'exponential' | 'fixed';
    baseDelayMs: number;
    /** Only these failure classes consume a retry attempt; anything else goes straight to fallbackAgentId (if set). See ARCHITECTURE.md §14. */
    retryableFailureClasses: RetryableFailureClass[];
  };
  /** Replaces OrchestratorV3.js's central FALLBACK_AGENTS map — e.g. alex's fallbackAgentId is 'blake', copied straight from today's map, not redesigned. */
  fallbackAgentId?: string;
  /** Informational — feeds the new ReflectionStage. Not a hard gate in Phase 1. */
  typicalConfidence?: 'low' | 'medium' | 'high';
}

export interface AgentObservability {
  /** Event types this agent's lifecycle publishes beyond the pipeline's own defaults. Most agents never need to set this. */
  emits?: string[];
}

export interface AgentManifest {
  identity: AgentIdentity;
  io: AgentIO;
  tools: AgentToolAccess;
  memory: AgentMemoryAccess;
  permissions: AgentPermissions;
  cost: AgentCostProfile;
  reliability: AgentReliability;
  observability: AgentObservability;
  /** Unchanged — still composed via shared fragments like tier1_research.js's RESEARCH_HOUSE_RULES. This field holds the final assembled string. */
  systemPrompt: string;
  /** Human-readable, shown in admin/debug UI and any future marketplace listing. */
  limitations?: string[];
}

/** Exactly today's shape — see AgentRegistry.js. */
export interface LegacyAgent {
  name: string;
  displayName: string;
  tier: AgentTier;
  systemPrompt: string;
  maxTokens: number;
}

/** The adapter that makes migration additive instead of breaking. OrchestratorV3.js keeps calling getAgentByName() → LegacyAgent, unaware manifests exist underneath. */
export function toLegacyAgent(manifest: AgentManifest): LegacyAgent {
  return {
    name: manifest.identity.id,
    displayName: manifest.identity.displayName,
    tier: manifest.identity.tier,
    systemPrompt: manifest.systemPrompt,
    maxTokens: manifest.cost.maxTokens,
  };
}

/**
 * Minimal runtime guard — cheap enough to run at registry load time for
 * all 100 (and eventually more) manifests without meaningfully affecting
 * cold start. Not a replacement for the TypeScript compiler; a defense
 * against manifests loaded from data (DB/JSON) rather than authored as
 * .ts, which is exactly the path a future marketplace listing takes.
 */
export function validateManifest(m: AgentManifest): string[] {
  const problems: string[] = [];
  if (!m.identity.id || m.identity.id !== m.identity.id.toLowerCase()) {
    problems.push('identity.id must be a non-empty, lowercase string');
  }
  if (m.cost.maxTokens <= 0) {
    problems.push('cost.maxTokens must be positive');
  }
  if (m.reliability.retryStrategy.maxAttempts < 0) {
    problems.push('reliability.retryStrategy.maxAttempts cannot be negative');
  }
  if (m.reliability.fallbackAgentId === m.identity.id) {
    problems.push('an agent cannot be its own fallback');
  }
  return problems;
}

/**
 * Example — Tier 1's "alex", migrated. Every value here is copied
 * directly from tier1_research.js and OrchestratorV3.js's FALLBACK_AGENTS
 * map, not redesigned. This is what "migrate one agent" actually looks
 * like (ARCHITECTURE.md §19, step 1c).
 */
export const EXAMPLE_ALEX_MANIFEST: AgentManifest = {
  identity: {
    id: 'alex',
    displayName: 'Alex — General Web Research',
    tier: 1,
    responsibility: 'Answer broad, open-ended research questions that don\u2019t fit a specialist\u2019s lane.',
  },
  io: {
    inputs: ['subtask.description', 'sharedMemory context', 'agentMemoryContext'],
    outputs: ['research findings, sourced and confidence-labeled'],
  },
  tools: { allowedTools: ['web_search', 'news_search'] }, // was: implicit via TIER_TOOL_SETS[1]
  memory: {
    canReadSharedMemory: true,
    canWriteSharedMemory: true,
    canReadCrossSessionMemory: true,
    canWriteCrossSessionMemory: false, // extractFromRun() writes at the mission level, not per-agent
  },
  permissions: {},
  cost: { maxTokens: 1500 }, // unchanged from tier1_research.js
  reliability: {
    retryStrategy: {
      maxAttempts: 2, // unchanged from MAX_AGENT_RETRIES
      backoff: 'exponential',
      baseDelayMs: 600, // unchanged from Math.pow(2, attempt) * 600
      retryableFailureClasses: ['timeout', 'rate_limit', 'tool_error'],
    },
    fallbackAgentId: 'blake', // copied from FALLBACK_AGENTS.alex
    typicalConfidence: 'medium',
  },
  observability: {},
  systemPrompt: '/* unchanged — the actual template literal from tier1_research.js, including RESEARCH_HOUSE_RULES */',
};
