/**
 * core/plugins/plugin-contract.ts
 *
 * The two extensibility surfaces the "unlimited tools / unlimited agents /
 * future marketplace" requirement actually needs. See ARCHITECTURE.md §11
 * for scope — this file defines the interface; it deliberately does NOT
 * implement sandboxed execution for untrusted third-party code.
 *
 * assertSafeToRegister() below is a real, enforced gate, not just a
 * comment: do not register anything with source !== 'built-in' until a
 * real sandbox exists. See ARCHITECTURE.md §20's review note on this.
 */

import type { ToolDefinition, ToolExecutionContext, ToolResult, ToolPermissions } from '../tools/tool-contract';
import type { AgentManifest } from '../agents/agent-manifest';

export interface PluginManifest {
  id: string;
  version: string; // semver
  description: string;
  author: string;
  /** Anthropic-reviewed built-ins vs. marketplace vs. a workspace's own private tools/agents. Gates whether sandboxing is required at all — built-in trusted code doesn't need it. */
  source: 'built-in' | 'marketplace' | 'workspace-custom';
}

export interface ToolPluginPackage {
  manifest: PluginManifest;
  definition: ToolDefinition;
  permissions: ToolPermissions;
  execute(input: unknown, ctx: ToolExecutionContext): Promise<ToolResult>;
}

export interface AgentPluginPackage {
  manifest: PluginManifest;
  agent: AgentManifest;
}

export interface PluginRegistry {
  registerTool(pkg: ToolPluginPackage): void;
  registerAgent(pkg: AgentPluginPackage): void;
  listTools(source?: PluginManifest['source']): ToolPluginPackage[];
  listAgents(source?: PluginManifest['source']): AgentPluginPackage[];
}

/**
 * Phase 1 scope check before registering anything with source !==
 * 'built-in': is there an actual sandboxing mechanism in front of
 * execute()? If not, refuse the registration rather than silently trust
 * it. This gate isn't bypassable by a config flag on purpose — see
 * ARCHITECTURE.md §11.
 */
export function assertSafeToRegister(pkg: ToolPluginPackage, sandboxAvailable: boolean): void {
  if (pkg.manifest.source !== 'built-in' && !sandboxAvailable) {
    throw new Error(
      `Refusing to register tool "${pkg.definition.id}" from source "${pkg.manifest.source}": ` +
        `no sandbox is configured. See ARCHITECTURE.md §11.`,
    );
  }
}

export class InMemoryPluginRegistry implements PluginRegistry {
  private tools: ToolPluginPackage[] = [];
  private agents: AgentPluginPackage[] = [];

  constructor(private sandboxAvailable: boolean = false) {}

  registerTool(pkg: ToolPluginPackage): void {
    assertSafeToRegister(pkg, this.sandboxAvailable);
    this.tools.push(pkg);
  }

  registerAgent(pkg: AgentPluginPackage): void {
    if (pkg.manifest.source !== 'built-in' && !this.sandboxAvailable) {
      throw new Error(
        `Refusing to register agent "${pkg.agent.identity.id}" from source "${pkg.manifest.source}": ` +
          `no sandbox is configured for its tool access. See ARCHITECTURE.md §11.`,
      );
    }
    this.agents.push(pkg);
  }

  listTools(source?: PluginManifest['source']): ToolPluginPackage[] {
    return source ? this.tools.filter((t) => t.manifest.source === source) : this.tools;
  }

  listAgents(source?: PluginManifest['source']): AgentPluginPackage[] {
    return source ? this.agents.filter((a) => a.manifest.source === source) : this.agents;
  }
}
