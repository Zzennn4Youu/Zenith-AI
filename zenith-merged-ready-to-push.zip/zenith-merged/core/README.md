# Zenith Foundation Kit

Real, compiling TypeScript — not pseudocode. Companion to `../ARCHITECTURE.md`, specifically Sections 6–19.

## What this is

The `core/` layer described in the architecture document, ready to drop into the existing Phase 6 repo. Nothing here requires changing `lib/**.js`, `app/**`, or `components/**` on day one — see **Day 1** below for the smallest possible first step.

## Install

```bash
npm install zod
```

Everything else here is zero-dependency TypeScript.

## Where it goes

Copy `core/` to your repo root, next to `app/`, `components/`, and `lib/`. Add a path alias in `tsconfig.json` if you don't already have one:

```json
{
  "compilerOptions": {
    "paths": { "@/core/*": ["./core/*"] }
  }
}
```

## Reading order

1. `core/kernel/result.ts` — the `Result` type + error hierarchy everything else uses
2. `core/kernel/event-bus.ts` — the event system, with the exact migration snippet for `logEvent()`
3. `core/kernel/logger.ts` — structured logging with automatic secret redaction
4. `core/agents/agent-manifest.ts` — the new Agent contract + `toLegacyAgent()` adapter + a worked example (`alex`, migrated field-by-field from `tier1_research.js`)
5. `core/tools/tool-contract.ts` — formalizes `TOOL_SCHEMAS`'s shape, includes `LEGACY_TIER_TOOL_DEFAULTS` copied from `agentTools.js`
6. `core/plugins/plugin-contract.ts` — Tool/Agent plugin surfaces (interface only — no sandbox; see `ARCHITECTURE.md` §11 before registering anything non-`built-in`)
7. `core/config/env.ts` — typed env validation using your actual `.env.example` keys, plus the versioned pricing table fix for the Sept 1, 2026 Sonnet pricing change
8. `core/di/container.ts` — composition root, same pattern as `runToolCallLoop`'s injected `callModel`/`callTool`
9. `core/pipeline/mission-pipeline.ts` — wraps `runOrchestration()` without changing it, adds the new Reflection stage

## Day 1 — the smallest real step (ARCHITECTURE.md §19, phases 1a–1b)

**1.** Drop `core/kernel/*` in. Nothing calls it yet — this is a no-risk, unused-code commit.

**2.** At your composition root (new file, e.g. `lib/composition-root.ts`):

```typescript
import { InMemoryEventBus } from '@/core/kernel/event-bus';
import { createLogger } from '@/core/kernel/logger';
import { initContainer } from '@/core/di/container';
import { InMemoryToolRegistry } from '@/core/tools/tool-contract';
import { logEvent } from '@/lib/orchestrator/OrchestratorV3'; // export it if not already exported

const eventBus = new InMemoryEventBus();
eventBus.subscribeAll(async (event) => {
  await logEvent(supabase, event.correlationId, event.source, event.type, event.payload);
});

initContainer({ eventBus, logger: createLogger(), toolRegistry: new InMemoryToolRegistry() });
```

**3.** In `OrchestratorV3.js`, replace one `logEvent(supabase, taskId, agent.name, 'agent_started', ...)` call site with:

```typescript
await eventBus.publish({
  type: 'agent.execution.started',
  correlationId: taskId,
  source: agent.name,
  payload: { /* whatever logEvent's desc/metadata carried */ },
});
```

Verify `execution_log` rows are byte-identical before/after. Repeat per call site, at your own pace.

That's the entire first milestone. Everything else in `ARCHITECTURE.md` §19 builds on it incrementally — no step requires the ones after it to already be done.
