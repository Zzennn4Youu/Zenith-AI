/**
 * core/config/env.ts
 *
 * One typed, validated source of truth for every environment variable —
 * replaces scattered `process.env.X` reads across lib/**.js. Every key
 * below is copied directly from the repo's own .env.example; nothing
 * invented, nothing renamed. Throws at import time (boot), not at the
 * first call site that happens to touch a missing var in production.
 *
 * Add zod if it isn't already a dependency:
 *   npm install zod
 */

import { z } from 'zod';

/** Vercel/Next.js env vars are always strings — booleans arrive as "true"/"false". */
const booleanString = z.enum(['true', 'false']).transform((v) => v === 'true');

const EnvSchema = z.object({
  // --- AI provider ---
  ANTHROPIC_API_KEY: z.string().min(1, 'ANTHROPIC_API_KEY is required'),

  // --- Supabase ---
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),

  // --- Billing (Midtrans) ---
  MIDTRANS_CLIENT_KEY: z.string().min(1),
  MIDTRANS_SERVER_KEY: z.string().min(1),
  MIDTRANS_IS_PRODUCTION: booleanString,
  NEXT_PUBLIC_MIDTRANS_CLIENT_KEY: z.string().min(1),
  NEXT_PUBLIC_MIDTRANS_IS_PRODUCTION: booleanString,

  // --- Web Push ---
  VAPID_PUBLIC_KEY: z.string().min(1),
  VAPID_PRIVATE_KEY: z.string().min(1),
  NEXT_PUBLIC_VAPID_PUBLIC_KEY: z.string().min(1),

  // --- Admin / cron / ops ---
  ADMIN_SECRET: z.string().min(16, 'ADMIN_SECRET should be a long random string, e.g. `openssl rand -hex 32`'),
  CRON_SECRET: z.string().min(16),
  /** Comma-separated list in .env — kept as a raw string here; split at the call site (today's convention). */
  OWNER_USER_IDS: z.string().optional(),
});

export type Env = z.infer<typeof EnvSchema>;

function loadEnv(): Env {
  const result = EnvSchema.safeParse(process.env);
  if (!result.success) {
    const missing = result.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
    throw new Error(`[core/config/env] Invalid environment configuration:\n${missing}`);
  }
  return result.data;
}

/** Import this, not process.env, from anywhere under core/ or lib/. Throws once, loudly, at boot. */
export const env = loadEnv();

// ── Concrete fix for ARCHITECTURE.md §3.5 / §12 ──────────────────────────
// Replaces modelTiers.js's hardcoded pricing + "update this by hand on
// Sept 1" comment with a small versioned table. Same runtime behavior on
// both sides of the date — correct by construction instead of by memory.

export type ModelTierId = 'spark' | 'core' | 'apex';

interface PricingEntry {
  effectiveFrom: string; // ISO date
  priceIn: number; // USD per million input tokens
  priceOut: number; // USD per million output tokens
}

const PRICING_HISTORY: Record<ModelTierId, PricingEntry[]> = {
  spark: [{ effectiveFrom: '2026-01-01', priceIn: 1, priceOut: 5 }],
  core: [
    { effectiveFrom: '2026-01-01', priceIn: 2, priceOut: 10 },
    { effectiveFrom: '2026-09-01', priceIn: 3, priceOut: 15 },
  ],
  apex: [{ effectiveFrom: '2026-01-01', priceIn: 5, priceOut: 25 }],
};

/**
 * Picks the entry with the latest effectiveFrom <= asOf. Verify current
 * actual rates at https://docs.claude.com before relying on these exact
 * numbers in production — this table's job is the *mechanism* (dated,
 * versioned, no hand-updating required), not being the permanent source
 * of truth for pricing.
 */
export function resolvePricing(tier: ModelTierId, asOf: Date = new Date()): PricingEntry {
  const history = PRICING_HISTORY[tier];
  const applicable = history
    .filter((e) => new Date(e.effectiveFrom).getTime() <= asOf.getTime())
    .sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom));
  return applicable[0] ?? history[0];
}
