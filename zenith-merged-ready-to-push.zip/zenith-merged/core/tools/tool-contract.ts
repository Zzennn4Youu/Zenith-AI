/**
 * core/tools/tool-contract.ts
 *
 * Formalizes the shape lib/orchestrator/agentTools.js's TOOL_SCHEMAS
 * already has (name, description, input_schema — the exact shape the
 * Anthropic Messages API's `tools` parameter expects) and adds what's
 * currently missing: a stable id for permission-checking against an
 * AgentManifest's allowedTools list, declared network/auth requirements,
 * and a reference to the actual execute() implementation. See
 * ARCHITECTURE.md §11.
 */

import type { AgentManifest } from '../agents/agent-manifest';

/** Matches the Anthropic Messages API tool schema shape exactly — no translation layer needed at the call site in executeAgentWithRetry(). */
export interface ToolInputSchema {
  type: 'object';
  properties: Record<string, { type: string; description?: string }>;
  required?: string[];
}

export interface ToolDefinition {
  /** Stable id, matches today's TOOL_SCHEMAS keys, e.g. "get_coin_price". */
  id: string;
  name: string;
  description: string;
  input_schema: ToolInputSchema;
}

export interface ToolExecutionContext {
  agentId: string;
  missionId: string;
  timeoutMs: number;
  retries: number;
}

export type ToolResult =
  | { success: true; result: unknown }
  | { success: false; error: string };

export interface ToolPermissions {
  /** Every tool today implicitly has full network access. This makes that explicit and auditable. */
  network: boolean;
  /** Name of the env var holding the required key, if any — e.g. "COINGECKO_API_KEY". Lets a future admin UI show "this tool needs a key" without reading source. */
  requiresApiKey?: string;
}

export interface ToolPlugin {
  definition: ToolDefinition;
  permissions: ToolPermissions;
  execute(input: unknown, ctx: ToolExecutionContext): Promise<ToolResult>;
}

export interface ToolRegistry {
  register(tool: ToolPlugin): void;
  get(id: string): ToolPlugin | undefined;
  /**
   * Resolves an agent's actual callable tool list: intersects the
   * manifest's allowedTools with what's registered, falling back to a
   * tier default (today's TIER_TOOL_SETS) only when allowedTools is
   * empty — preserves today's convenience without making the tier the
   * source of truth going forward.
   */
  listForAgent(manifest: AgentManifest, tierDefaults?: Record<number, string[]>): ToolDefinition[];
}

export class InMemoryToolRegistry implements ToolRegistry {
  private tools = new Map<string, ToolPlugin>();

  register(tool: ToolPlugin): void {
    this.tools.set(tool.definition.id, tool);
  }

  get(id: string): ToolPlugin | undefined {
    return this.tools.get(id);
  }

  listForAgent(manifest: AgentManifest, tierDefaults: Record<number, string[]> = {}): ToolDefinition[] {
    const ids =
      manifest.tools.allowedTools.length > 0
        ? manifest.tools.allowedTools
        : tierDefaults[manifest.identity.tier] ?? [];

    return ids
      .map((id) => this.tools.get(id)?.definition)
      .filter((def): def is ToolDefinition => Boolean(def));
  }
}

/**
 * Today's TIER_TOOL_SETS from agentTools.js, unchanged — passed as the
 * `tierDefaults` fallback above so agents that haven't migrated to an
 * explicit allowedTools list yet keep working exactly as before.
 */
export const LEGACY_TIER_TOOL_DEFAULTS: Record<number, string[]> = {
  1: ['web_search', 'news_search'],
  4: ['get_coin_price', 'get_ohlcv', 'get_market_chart', 'get_fear_greed', 'get_top_coins'],
};
