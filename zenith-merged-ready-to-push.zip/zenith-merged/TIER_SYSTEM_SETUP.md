# 3-Tier Model System — Setup Guide

## The tiers

| Tier | Name | Model | Price (in/out per MTok) | Who gets it |
|---|---|---|---|---|
| 1 | **Zenith Spark** | `claude-haiku-4-5-20251001` | $1 / $5 | Free users, simple requests |
| 2 | **Zenith Core** | `claude-sonnet-5` | $2 / $10 → $3/$15 after Aug 31 2026 | Free users, complex requests |
| 3 | **Zenith Apex** | `claude-opus-4-8` | $5 / $25 | Paid users, always, no daily limit |

Free users are auto-routed between Spark and Core by a quick heuristic on
their request (length + keywords like "analyze", "strategy", "compare",
etc. — see `classifyComplexity()` in `lib/orchestrator/modelTiers.js`),
capped at **20 requests/day combined**. Paid users always get Apex with no
cap, for every request.

⚠️ **Reminder for Sept 1, 2026**: Sonnet 5's $2/$10 is introductory pricing
that reverts to standard $3/$15 after Aug 31, 2026. Update `priceIn`/`priceOut`
for the `core` tier in `lib/orchestrator/modelTiers.js` on that date so cost
tracking stays accurate.

## 1. Run the new migration

Apply `supabase/migrations/008_subscriptions_and_usage.sql`. It creates:
- `user_subscriptions` — one row per user, `tier` = `'free'` or `'paid'`
- `orchestration_usage_daily` — daily request counter for free users
- `increment_daily_usage()` — the only way usage gets written (see below)

Both tables block direct writes from a user's own client on purpose — RLS
only allows reading your own row. This stops a technically-savvy free user
from just flipping their own tier to `'paid'` or zeroing their own usage
counter via a direct Supabase REST call with their own valid JWT.

## 2. Environment variables

```
SUPABASE_SERVICE_ROLE_KEY=<from Supabase dashboard → Settings → API — same one used by the Web Push cron job, if you set that up already>
ADMIN_SECRET=<any long random string, e.g. `openssl rand -hex 32`>
```

## 3. Granting paid access (until a real payment gateway is wired up)

There's no Stripe/Midtrans/Xendit integration here — that's a separate
feature. For now, `/api/admin/set-tier` is a manual stand-in:

```bash
curl -X POST https://<your-app>/api/admin/set-tier \
  -H "Authorization: Bearer <ADMIN_SECRET>" \
  -H "Content-Type: application/json" \
  -d '{"userId": "<their-supabase-user-id>", "tier": "paid"}'
```

Use `"tier": "free"` to revoke. When you do integrate real payments, point
the webhook handler at the same upsert logic in that route instead of
calling it manually.

## 4. What changed in the orchestrator

`runOrchestration()` now resolves a model tier *before* anything else runs
— a free user who's hit their daily limit gets rejected immediately (no
Supervisor call, no memory recall, no cost incurred) with a clear message
in `finalOutput` explaining the limit and suggesting an upgrade. That
message flows through `/api/orchestrate` and into the chat exactly like any
other response, so no changes were needed there.

Every LLM call in a run (Supervisor, each of the 100 agents, Fusion) now
uses that run's resolved tier's model and pricing — previously everything
was hardcoded to `claude-sonnet-4-6` with fixed $3/$15 pricing.

## 5. UI

- The chat header now shows a small badge: `7/20 today` for free users, or
  `⚡ Zenith Apex` for paid users. Refreshes every 60s, plus immediately
  after a non-streaming request completes.
- **Not wired**: the streaming request path (`startStream(...)`) doesn't
  trigger an immediate badge refresh, since that function isn't part of
  this Phase 6 bundle — the 60s poll will pick up the change within a
  minute regardless.
