/**
 * ZENITH AI v2 — Push Service Worker
 *
 * Must be served from the site root (/sw.js) for its push scope to cover the
 * whole origin. Next.js serves anything under /public/ at the root path
 * automatically, so this file at public/sw.js becomes https://yourapp/sw.js.
 *
 * Two jobs:
 *   1. 'push'            — server sent a push message, show a notification
 *   2. 'notificationclick' — user tapped the notification, focus/open the app
 */

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { title: 'Zenith Alert', body: event.data ? event.data.text() : '' };
  }

  const title = data.title || 'Zenith Alert';
  const options = {
    body: data.body || '',
    icon: data.icon || '/icon-192.png',
    badge: data.badge || '/icon-192.png',
    tag: data.tag, // same tag replaces an existing unread notification instead of stacking
    data: { url: data.url || '/' },
    requireInteraction: false,
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // Focus an already-open tab if one exists, rather than opening a duplicate
      for (const client of clientList) {
        if ('focus' in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow(targetUrl);
    })
  );
});
