# Web Push Notifications — Setup Guide

New feature: alerts now reach you via a real OS-level push notification even
when no browser tab is open, on top of the existing in-app SSE experience.

## How it works

- `/api/alerts/stream` (existing) still runs the live in-app toast/badge —
  but only while a tab is open, since it's driven by an SSE connection.
- `/api/cron/check-alerts` (new) runs independently of any open tab. An
  **external** scheduler calls it every 1-2 minutes; it checks every user's
  active alerts and sends Web Push for anything that fires.
- Vercel's own Cron Jobs cap Hobby-plan projects to once/day — nowhere near
  frequent enough for price alerts — so this uses an external scheduler
  instead. The route itself has no such limit.

## 1. Install the package

```bash
npm install web-push
```

## 2. Run the new migration

Apply `supabase/migrations/007_push_subscriptions.sql` (same way you've run
the others — Supabase SQL editor or CLI).

## 3. Environment variables

A real VAPID key pair, already generated and ready to use (or generate your
own anytime with `npx web-push generate-vapid-keys`):

```
VAPID_PUBLIC_KEY=BP9gTvU68vU0kEfbMZIlluGUWho9T7UMI3Gafspbkfe--vaAJ3PgM0Xw9Ulp9v2cYYU9QPR23i5zYpKnSo1ldZ4
VAPID_PRIVATE_KEY=UOnSFT6oULk3UQdAl1YaAQsK-uiw3EIaLD6FIxB78UI
NEXT_PUBLIC_VAPID_PUBLIC_KEY=BP9gTvU68vU0kEfbMZIlluGUWho9T7UMI3Gafspbkfe--vaAJ3PgM0Xw9Ulp9v2cYYU9QPR23i5zYpKnSo1ldZ4
```

Two more you need to add yourself:

```
SUPABASE_SERVICE_ROLE_KEY=<from Supabase dashboard → Settings → API — keep this secret, server-only, never NEXT_PUBLIC_>
CRON_SECRET=<any long random string you generate yourself, e.g. `openssl rand -hex 32`>
```

Add all of these in Vercel → Project → Settings → Environment Variables (and
your local `.env`).

## 4. Set up the external scheduler (cron-job.org)

1. Create a free account at cron-job.org.
2. New cron job:
   - URL: `https://<your-app>.vercel.app/api/cron/check-alerts`
   - Schedule: every 1-2 minutes
   - **Request method**: GET
   - **Custom header**: `Authorization: Bearer <your CRON_SECRET value>`
3. Save and enable. cron-job.org will now hit that URL on schedule; the
   route rejects any request without the correct header.

## 5. Icons (cosmetic, not blocking)

`public/sw.js` references `/icon-192.png` for the notification icon. If that
file doesn't exist yet in `/public`, browsers just fall back to a default
icon — nothing breaks. Add a 192×192 PNG there whenever convenient for a
branded notification icon.

## 6. Using it

The Alerts panel now shows an "Enable" toggle for push notifications right
below the header. Once a user enables it:
- Browser asks for notification permission
- Subscription is saved to `push_subscriptions`
- From then on, `/api/cron/check-alerts` will push to them on every fire,
  tab open or not
