/**
 * /api/memory — Agent Memory CRUD
 *
 * GET  /api/memory?type=fact&search=bitcoin&limit=20&offset=0
 *      → list user's memories
 *
 * POST /api/memory
 *      body: { action, ...params }
 *
 *      action: 'remember'  { content, type, tags, importance, expiresInDays }
 *      action: 'forget'    { id }
 *      action: 'forget_type' { type }
 *      action: 'recall'    { query, limit, types }
 *      action: 'stats'
 */

import { createClient }  from '@supabase/supabase-js';
import { AgentMemory }   from '../../../lib/memory/AgentMemory.js';
import { extractBearerToken } from '../../../lib/security/middleware.js';

// ── Auth helper ──────────────────────────────────────────────────────────────

async function authenticate(request) {
  const tk = extractBearerToken(request);
  if (!tk.valid) return { ok: false, status: 401, error: 'Unauthorized' };

  // Attach the user's JWT as the Authorization header so subsequent .from()
  // calls run under their identity (required for RLS — getUser() alone only
  // validates the token, it doesn't attach it to this client's requests).
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: `Bearer ${tk.token}` } } },
  );

  const { data: { user }, error } = await supabase.auth.getUser(tk.token);
  if (error || !user) return { ok: false, status: 401, error: 'Unauthorized' };

  return { ok: true, user, supabase };
}

// ── GET ──────────────────────────────────────────────────────────────────────

export async function GET(request) {
  const auth = await authenticate(request);
  if (!auth.ok) return Response.json({ error: auth.error }, { status: auth.status });

  const { searchParams } = new URL(request.url);
  const type   = searchParams.get('type')   || null;
  const search = searchParams.get('search') || '';
  const limit  = parseInt(searchParams.get('limit')  ?? '50');
  const offset = parseInt(searchParams.get('offset') ?? '0');

  try {
    const memory = new AgentMemory(auth.supabase, auth.user.id);
    const result = await memory.list({ type, search, limit, offset });
    return Response.json({ success: true, ...result });
  } catch (e) {
    return Response.json({ success: false, error: e.message }, { status: 500 });
  }
}

// ── POST ─────────────────────────────────────────────────────────────────────

export async function POST(request) {
  const auth = await authenticate(request);
  if (!auth.ok) return Response.json({ error: auth.error }, { status: auth.status });

  let body;
  try { body = await request.json(); }
  catch { return Response.json({ error: 'Invalid JSON' }, { status: 400 }); }

  const { action, ...params } = body;
  const memory = new AgentMemory(auth.supabase, auth.user.id);

  try {
    switch (action) {

      case 'remember': {
        const { content, type, tags, importance, expiresInDays } = params;
        if (!content) return Response.json({ error: 'content required' }, { status: 400 });
        const result = await memory.remember(content, { type, tags, importance, expiresInDays });
        return Response.json({ success: true, memory: result });
      }

      case 'forget': {
        const { id } = params;
        if (!id) return Response.json({ error: 'id required' }, { status: 400 });
        await memory.forget(id);
        return Response.json({ success: true });
      }

      case 'forget_type': {
        const { type } = params;
        if (!type) return Response.json({ error: 'type required' }, { status: 400 });
        await memory.forgetByType(type);
        return Response.json({ success: true });
      }

      case 'recall': {
        const { query = '', limit = 10, types = null } = params;
        const results = await memory.recall(query, { limit, types });
        return Response.json({ success: true, memories: results });
      }

      case 'stats': {
        const stats = await memory.stats();
        return Response.json({ success: true, stats });
      }

      default:
        return Response.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (e) {
    return Response.json({ success: false, error: e.message }, { status: 500 });
  }
}
