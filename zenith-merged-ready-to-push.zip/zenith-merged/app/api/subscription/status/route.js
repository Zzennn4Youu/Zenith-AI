/**
 * GET /api/subscription/status
 *
 * Returns the current user's subscription tier and today's free-tier usage,
 * for display in the UI (e.g. a header badge showing "Zenith Spark/Core —
 * 7/20 today" or "Zenith Apex — Unlimited").
 */

import { createClient }       from '@supabase/supabase-js';
import { extractBearerToken } from '../../../../lib/security/middleware.js';
import { isOwner }            from '../../../../lib/orchestrator/modelTiers.js';

const FREE_DAILY_LIMIT = 20; // keep in sync with lib/orchestrator/modelTiers.js

export async function GET(request) {
  const tk = extractBearerToken(request);
  if (!tk.valid) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: `Bearer ${tk.token}` } } },
  );
  const { data: { user }, error: authError } = await supabase.auth.getUser(tk.token);
  if (authError || !user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  if (isOwner(user.id)) {
    return Response.json({ success: true, tier: 'owner', usedToday: 0, limit: null });
  }

  try {
    const { data: sub } = await supabase
      .from('user_subscriptions')
      .select('tier')
      .eq('user_id', user.id)
      .maybeSingle();

    const tier = sub?.tier === 'paid' ? 'paid' : 'free';

    if (tier === 'paid') {
      return Response.json({ success: true, tier, usedToday: 0, limit: null });
    }

    const today = new Date().toISOString().slice(0, 10);
    const { data: usage } = await supabase
      .from('orchestration_usage_daily')
      .select('request_count')
      .eq('user_id', user.id)
      .eq('usage_date', today)
      .maybeSingle();

    return Response.json({
      success: true, tier,
      usedToday: usage?.request_count ?? 0,
      limit: FREE_DAILY_LIMIT,
    });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
