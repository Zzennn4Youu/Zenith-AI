/**
 * POST /api/billing/checkout
 *
 * Authenticated user requests to subscribe to Zenith Apex. Creates a
 * Midtrans Snap transaction and returns the token for the frontend to open
 * with `snap.pay(token, ...)`. QRIS shows automatically within the
 * gopay/e-wallet flow on desktop — see lib/billing/midtrans.js.
 */

import { createClient }         from '@supabase/supabase-js';
import { extractBearerToken }   from '../../../../lib/security/middleware.js';
import { createSubscriptionCharge } from '../../../../lib/billing/midtrans.js';

export async function POST(request) {
  const tk = extractBearerToken(request);
  if (!tk.valid) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: `Bearer ${tk.token}` } } },
  );
  const { data: { user }, error: authError } = await supabase.auth.getUser(tk.token);
  if (authError || !user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { token, orderId, amountIdr } = await createSubscriptionCharge(
      user.id, user.email, user.user_metadata?.full_name,
    );

    // Record the pending transaction now, keyed by order_id, so the webhook
    // can look up which user this payment belongs to without trusting
    // anything in the webhook payload for that mapping — it only trusts
    // order_id as a lookup key into a row we created ourselves.
    const { error: insertError } = await supabase
      .from('payment_transactions')
      .insert({ user_id: user.id, order_id: orderId, amount: amountIdr, status: 'pending' });
    if (insertError) throw new Error(insertError.message);

    return Response.json({ success: true, token, orderId, amountIdr });
  } catch (e) {
    console.error('[Billing] checkout failed:', e);
    return Response.json({ error: e.message }, { status: 500 });
  }
}
