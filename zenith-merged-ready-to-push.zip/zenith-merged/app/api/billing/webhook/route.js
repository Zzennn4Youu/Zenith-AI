/**
 * POST /api/billing/webhook
 *
 * Midtrans calls this server-to-server whenever a transaction's status
 * changes — no user session involved, so this uses a service-role client
 * throughout. Verifies the notification's signature via the official
 * midtrans-client library before trusting anything in the payload.
 *
 * Idempotent by design: order_id is UNIQUE in payment_transactions, and we
 * only call extend_subscription() on a genuinely new settlement, never on
 * a repeat notification for an order already recorded as settled — Midtrans
 * explicitly documents that duplicate notifications can occur and must not
 * cause duplicate processing. The same idempotency check protects the
 * refund/chargeback path below: revoke_subscription() only fires once per
 * order, the first time it flips from settled to refunded/charged-back.
 */

import { createClient }     from '@supabase/supabase-js';
import { verifyNotification, SUBSCRIPTION_DAYS } from '../../../../lib/billing/midtrans.js';

const REFUND_LIKE_STATUSES = ['refund', 'partial_refund', 'chargeback', 'partial_chargeback'];

export async function POST(request) {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
  );

  try {
    const body = await request.json();

    // Throws if the signature doesn't check out — treat as rejected, not
    // a processing error, so a forged notification never reaches the DB.
    let status;
    try {
      status = await verifyNotification(body);
    } catch (e) {
      console.warn('[Billing Webhook] signature verification failed:', e.message);
      return Response.json({ error: 'Invalid signature' }, { status: 403 });
    }

    const { order_id, transaction_status, fraud_status, payment_type } = status;

    // Look up the pending record by order_id rather than trusting anything
    // derived from the order_id string itself beyond using it as a lookup key.
    const { data: existing } = await supabase
      .from('payment_transactions')
      .select('id, user_id, status')
      .eq('order_id', order_id)
      .maybeSingle();

    if (!existing) {
      // We have no record of creating this order — either checkout wasn't
      // recorded (shouldn't happen, see checkout route) or this is
      // unsolicited. Nothing to extend/revoke since there's no known user_id.
      console.warn('[Billing Webhook] notification for unknown order_id:', order_id);
      return Response.json({ success: true, note: 'unknown order_id, recorded nothing' });
    }

    const wasSettled = existing.status === 'settlement' || existing.status === 'capture';

    await supabase
      .from('payment_transactions')
      .update({
        status: transaction_status,
        payment_type,
        raw_notification: body,
        updated_at: new Date().toISOString(),
      })
      .eq('order_id', order_id);

    const isSuccess = (transaction_status === 'settlement' || transaction_status === 'capture')
      && (!fraud_status || fraud_status === 'accept');

    if (isSuccess && !wasSettled) {
      const { error: extendError } = await supabase.rpc('extend_subscription', {
        p_user_id: existing.user_id,
        p_days: SUBSCRIPTION_DAYS,
      });
      if (extendError) {
        console.error('[Billing Webhook] extend_subscription failed:', extendError.message);
        return Response.json({ error: 'Failed to extend subscription' }, { status: 500 });
      }
    }

    // Refund/chargeback on an order that previously contributed extended
    // days — claw those days back. Gated on `wasSettled` (the status
    // *before* this notification) so this only fires once per order, the
    // first time it transitions from settled to reversed; a repeat
    // refund/chargeback notification for the same already-reversed order
    // (existing.status already refund/chargeback) is a no-op here.
    // Partial refunds/chargebacks are treated the same as full ones for
    // now (revoke the full period) — proportional handling would need
    // Midtrans's refund_amount, which isn't parsed out here yet.
    if (REFUND_LIKE_STATUSES.includes(transaction_status) && wasSettled) {
      const { error: revokeError } = await supabase.rpc('revoke_subscription', {
        p_user_id: existing.user_id,
        p_days: SUBSCRIPTION_DAYS,
      });
      if (revokeError) {
        console.error('[Billing Webhook] revoke_subscription failed:', revokeError.message);
        return Response.json({ error: 'Failed to revoke subscription' }, { status: 500 });
      }
    }

    return Response.json({ success: true });
  } catch (e) {
    console.error('[Billing Webhook] failed:', e);
    return Response.json({ error: e.message }, { status: 500 });
  }
}
