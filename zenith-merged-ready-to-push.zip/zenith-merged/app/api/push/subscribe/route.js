/**
 * /api/push/subscribe
 *
 * POST   — save/upsert a browser's push subscription for the current user
 * DELETE — remove a subscription (e.g. user disables push notifications)
 *   body: { endpoint, keys: { p256dh, auth } }
 */

import { createClient }       from '@supabase/supabase-js';
import { extractBearerToken } from '../../../../lib/security/middleware.js';

async function authenticate(request) {
  const tk = extractBearerToken(request);
  if (!tk.valid) return { ok: false, status: 401 };

  // Attach the user's JWT so .from() calls run under their identity for RLS
  // (getUser(token) alone only validates the token, it doesn't attach it).
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: `Bearer ${tk.token}` } } },
  );
  const { data: { user }, error } = await supabase.auth.getUser(tk.token);
  if (error || !user) return { ok: false, status: 401 };
  return { ok: true, user, supabase };
}

export async function POST(request) {
  const auth = await authenticate(request);
  if (!auth.ok) return Response.json({ error: 'Unauthorized' }, { status: auth.status });

  try {
    const body = await request.json();
    const { endpoint, keys } = body || {};

    if (!endpoint || !keys?.p256dh || !keys?.auth) {
      return Response.json({ error: 'endpoint and keys.p256dh/keys.auth required' }, { status: 400 });
    }

    const { error } = await auth.supabase
      .from('push_subscriptions')
      .upsert({
        user_id:    auth.user.id,
        endpoint,
        p256dh:     keys.p256dh,
        auth:       keys.auth,
        user_agent: request.headers.get('user-agent') || null,
      }, { onConflict: 'endpoint' });

    if (error) throw new Error(error.message);
    return Response.json({ success: true });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(request) {
  const auth = await authenticate(request);
  if (!auth.ok) return Response.json({ error: 'Unauthorized' }, { status: auth.status });

  try {
    const body = await request.json();
    const { endpoint } = body || {};
    if (!endpoint) return Response.json({ error: 'endpoint required' }, { status: 400 });

    const { error } = await auth.supabase
      .from('push_subscriptions')
      .delete()
      .eq('endpoint', endpoint)
      .eq('user_id', auth.user.id); // belt-and-suspenders on top of RLS

    if (error) throw new Error(error.message);
    return Response.json({ success: true });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
