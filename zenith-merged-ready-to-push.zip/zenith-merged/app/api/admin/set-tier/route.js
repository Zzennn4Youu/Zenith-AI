/**
 * POST /api/admin/set-tier
 * body: { userId, tier: 'free' | 'paid' }
 *
 * Manually grants/revokes Zenith Apex access. This is a stand-in for a real
 * payment webhook (Stripe/Midtrans/Xendit/etc), which isn't part of this
 * feature — use this to activate paid users manually (e.g. after a bank
 * transfer) until a real payment flow is wired up.
 *
 * Protected by ADMIN_SECRET, same pattern as CRON_SECRET on the alerts
 * cron job — a long random string only you know, sent as a Bearer token.
 */

import { createClient } from '@supabase/supabase-js';

export async function POST(request) {
  const authHeader = request.headers.get('authorization');
  if (!process.env.ADMIN_SECRET || authHeader !== `Bearer ${process.env.ADMIN_SECRET}`) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { userId, tier } = await request.json();
    if (!userId || !['free', 'paid'].includes(tier)) {
      return Response.json({ error: 'userId and tier ("free" or "paid") required' }, { status: 400 });
    }

    // Service-role client — deliberately bypasses RLS. Regular users have no
    // write policy on user_subscriptions at all (see migration 008); this
    // trusted, secret-gated route is the only place tier changes happen
    // until a real payment webhook replaces it.
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );

    const { error } = await supabase
      .from('user_subscriptions')
      .upsert({
        user_id: userId,
        tier,
        activated_at: tier === 'paid' ? new Date().toISOString() : null,
        updated_at: new Date().toISOString(),
      });

    if (error) throw new Error(error.message);
    return Response.json({ success: true, userId, tier });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
