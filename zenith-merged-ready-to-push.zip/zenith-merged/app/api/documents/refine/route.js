/**
 * POST /api/documents/refine
 * Streaming AI inline text refinement for the Document Editor.
 * Returns Server-Sent Events stream of the refined text.
 *
 * Body: { selectedText, action, customPrompt, language }
 * Auth: Bearer <supabase_access_token>
 *
 * Actions: improve | shorten | expand | fix_grammar | make_formal
 *          make_casual | translate | custom
 */

import { Anthropic }    from '@anthropic-ai/sdk';
import { createClient } from '@supabase/supabase-js';
import { extractBearerToken } from '../../../../lib/security/middleware.js';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── System prompt per action ─────────────────────────────────────────────────

const SYSTEM = `You are an expert writing assistant embedded inside a document editor.
When asked to refine text, return ONLY the refined text — no preamble, no explanation,
no markdown fences, no quotes. Output exactly what should replace the selected text.`;

function buildPrompt(action, selectedText, opts = {}) {
  switch (action) {
    case 'improve':
      return `Rewrite the following text to be clearer, more professional, and more engaging.
Preserve the original meaning and approximate length.

Selected text:
"""
${selectedText}
"""`;

    case 'shorten':
      return `Shorten the following text to approximately 50% of its original length.
Preserve all key information. Keep the same tone.

Selected text:
"""
${selectedText}
"""`;

    case 'expand':
      return `Expand the following text to approximately double its length.
Add relevant detail, examples, or explanation. Keep the same tone and voice.

Selected text:
"""
${selectedText}
"""`;

    case 'fix_grammar':
      return `Fix all grammar, spelling, punctuation, and style errors in the following text.
Preserve the original wording as closely as possible — only correct mistakes.

Selected text:
"""
${selectedText}
"""`;

    case 'make_formal':
      return `Rewrite the following text in a formal, professional tone suitable for
business documents, reports, or official correspondence.

Selected text:
"""
${selectedText}
"""`;

    case 'make_casual':
      return `Rewrite the following text in a friendly, natural, conversational tone.
Make it feel approachable and human.

Selected text:
"""
${selectedText}
"""`;

    case 'translate':
      return `Translate the following text to ${opts.language || 'English'}.
Preserve the tone, style, and level of formality. Output only the translation.

Selected text:
"""
${selectedText}
"""`;

    case 'custom':
      return `${opts.customPrompt || 'Improve the following text.'}

Selected text:
"""
${selectedText}
"""`;

    default:
      return `Improve the following text:\n\n${selectedText}`;
  }
}

const VALID_ACTIONS = new Set([
  'improve', 'shorten', 'expand', 'fix_grammar',
  'make_formal', 'make_casual', 'translate', 'custom',
]);

// Bounds worst-case cost per request — this endpoint isn't wired into the
// orchestrator's costTracking, so an oversized request here is invisible
// spend that wouldn't show up anywhere. 8000 chars is generous for the
// "select a range and refine" use case this is designed for.
const MAX_SELECTION_CHARS     = 8000;
const MAX_CUSTOM_PROMPT_CHARS = 500;

// ── Auth helper ──────────────────────────────────────────────────────────────

async function getUser(request) {
  const tk = extractBearerToken(request);
  if (!tk.valid) return { ok: false, status: 401, error: tk.error };

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  );
  const { data: { user }, error } = await supabase.auth.getUser(tk.token);
  if (error || !user) return { ok: false, status: 401, error: 'Unauthorized' };
  return { ok: true, user };
}

// ── POST handler ─────────────────────────────────────────────────────────────

export async function POST(request) {
  const auth = await getUser(request);
  if (!auth.ok) {
    return new Response(JSON.stringify({ error: auth.error }), { status: auth.status });
  }

  let body;
  try { body = await request.json(); }
  catch { return new Response(JSON.stringify({ error: 'Invalid JSON' }), { status: 400 }); }

  const {
    selectedText,
    action      = 'improve',
    customPrompt = '',
    language    = 'Indonesian',
  } = body;

  if (!selectedText?.trim()) {
    return new Response(JSON.stringify({ error: 'selectedText is required' }), { status: 400 });
  }
  if (selectedText.length > MAX_SELECTION_CHARS) {
    return new Response(JSON.stringify({
      error: `Selection too long (max ${MAX_SELECTION_CHARS} characters) — select a smaller range.`,
    }), { status: 400 });
  }
  if (customPrompt.length > MAX_CUSTOM_PROMPT_CHARS) {
    return new Response(JSON.stringify({
      error: `Custom instruction too long (max ${MAX_CUSTOM_PROMPT_CHARS} characters).`,
    }), { status: 400 });
  }
  if (!VALID_ACTIONS.has(action)) {
    return new Response(JSON.stringify({ error: `Unknown action: ${action}` }), { status: 400 });
  }

  const userPrompt = buildPrompt(action, selectedText.trim(), { customPrompt, language });

  // ── SSE stream ─────────────────────────────────────────────────────────────
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));

      try {
        const response = await anthropic.messages.stream({
          model:      'claude-sonnet-4-6',
          max_tokens: 1500,
          system:     SYSTEM,
          messages:   [{ role: 'user', content: userPrompt }],
        });

        for await (const event of response) {
          if (
            event.type === 'content_block_delta' &&
            event.delta?.type === 'text_delta'
          ) {
            send({ type: 'token', text: event.delta.text });
          }
        }

        send({ type: 'done' });
      } catch (err) {
        send({ type: 'error', message: err.message || 'Stream failed' });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type':     'text/event-stream',
      'Cache-Control':    'no-cache',
      'Connection':       'keep-alive',
      'X-Accel-Buffering':'no',
    },
  });
}
