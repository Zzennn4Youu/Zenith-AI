/**
 * /api/alerts — Alert CRUD + trigger history
 *
 * GET  /api/alerts                    → list user's alerts
 * GET  /api/alerts?history=1&limit=20 → list triggered notifications
 *
 * POST /api/alerts
 *   action: 'create'  { symbol, type, threshold, timeframe, signalType, label, recurring }
 *   action: 'update'  { id, ...fields }
 *   action: 'delete'  { id }
 *   action: 'toggle'  { id, status }   — 'active' | 'disabled'
 *   action: 'mark_read' { id }          — mark a trigger notification as read
 *   action: 'mark_all_read'
 */

import { createClient }       from '@supabase/supabase-js';
import { extractBearerToken } from '../../../lib/security/middleware.js';

async function authenticate(request) {
  const tk = extractBearerToken(request);
  if (!tk.valid) return { ok: false, status: 401 };

  // IMPORTANT: attach the user's access token as the client's Authorization
  // header. supabase.auth.getUser(token) below only *validates* the JWT — it
  // does not attach it to this client's PostgREST requests. Without this,
  // every .from() call below would run as the anon role, and RLS policies
  // (USING auth.uid() = user_id) would silently block all reads and reject
  // all writes.
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: `Bearer ${tk.token}` } } },
  );
  const { data: { user }, error } = await supabase.auth.getUser(tk.token);
  if (error || !user) return { ok: false, status: 401 };
  return { ok: true, user, supabase };
}

const VALID_TYPES = ['price_above','price_below','pct_change','smc_signal','smc_score_above'];
const MAX_ACTIVE_ALERTS = 50; // per user

// ── GET ──────────────────────────────────────────────────────────────────────

export async function GET(request) {
  const auth = await authenticate(request);
  if (!auth.ok) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(request.url);

  if (searchParams.get('history') === '1') {
    const limit = Math.min(100, parseInt(searchParams.get('limit') ?? '20'));
    const { data, error } = await auth.supabase
      .from('alert_triggers')
      .select('*')
      .eq('user_id', auth.user.id)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) return Response.json({ error: error.message }, { status: 500 });

    const { count: unreadCount } = await auth.supabase
      .from('alert_triggers')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', auth.user.id)
      .eq('read', false);

    return Response.json({ success: true, triggers: data ?? [], unreadCount: unreadCount ?? 0 });
  }

  const { data, error } = await auth.supabase
    .from('alerts')
    .select('*')
    .eq('user_id', auth.user.id)
    .order('created_at', { ascending: false });

  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({ success: true, alerts: data ?? [] });
}

// ── POST ─────────────────────────────────────────────────────────────────────

export async function POST(request) {
  const auth = await authenticate(request);
  if (!auth.ok) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  let body;
  try { body = await request.json(); }
  catch { return Response.json({ error: 'Invalid JSON' }, { status: 400 }); }

  const { action, ...params } = body;

  try {
    switch (action) {

      case 'create': {
        const { symbol, type, threshold, timeframe, signalType, label, recurring } = params;
        if (!symbol || !type) return Response.json({ error: 'symbol and type required' }, { status: 400 });
        if (!VALID_TYPES.includes(type)) return Response.json({ error: `Unknown type: ${type}` }, { status: 400 });
        if (type !== 'smc_signal' && (threshold === undefined || threshold === null)) {
          return Response.json({ error: 'threshold required for this alert type' }, { status: 400 });
        }

        // Cap active alerts per user — unbounded growth here makes
        // AlertChecker.runCycle() (sequential, per-user) take longer every
        // 15s cycle and increases MEXC API call volume proportionally.
        const { count: activeCount } = await auth.supabase
          .from('alerts')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', auth.user.id)
          .eq('status', 'active');
        if ((activeCount ?? 0) >= MAX_ACTIVE_ALERTS) {
          return Response.json(
            { error: `Maximum of ${MAX_ACTIVE_ALERTS} active alerts reached. Disable or delete one first.` },
            { status: 400 },
          );
        }

        const { data, error } = await auth.supabase
          .from('alerts')
          .insert({
            user_id:     auth.user.id,
            symbol:      symbol.toUpperCase(),
            type,
            threshold:   threshold ?? null,
            timeframe:   timeframe ?? '4h',
            signal_type: signalType ?? null,
            label:       label ?? null,
            recurring:   !!recurring,
          })
          .select()
          .single();

        if (error) throw error;
        return Response.json({ success: true, alert: data });
      }

      case 'update': {
        const { id, ...fields } = params;
        if (!id) return Response.json({ error: 'id required' }, { status: 400 });

        const allowed = ['threshold','timeframe','signal_type','label','recurring','symbol','type'];
        const updatePayload = {};
        for (const k of allowed) if (k in fields) updatePayload[k] = fields[k];

        const { data, error } = await auth.supabase
          .from('alerts')
          .update(updatePayload)
          .eq('id', id)
          .eq('user_id', auth.user.id)
          .select()
          .single();

        if (error) throw error;
        return Response.json({ success: true, alert: data });
      }

      case 'delete': {
        const { id } = params;
        if (!id) return Response.json({ error: 'id required' }, { status: 400 });
        await auth.supabase.from('alerts').delete().eq('id', id).eq('user_id', auth.user.id);
        return Response.json({ success: true });
      }

      case 'toggle': {
        const { id, status } = params;
        if (!id || !status) return Response.json({ error: 'id and status required' }, { status: 400 });
        const { data, error } = await auth.supabase
          .from('alerts')
          .update({ status })
          .eq('id', id)
          .eq('user_id', auth.user.id)
          .select()
          .single();
        if (error) throw error;
        return Response.json({ success: true, alert: data });
      }

      case 'mark_read': {
        const { id } = params;
        if (!id) return Response.json({ error: 'id required' }, { status: 400 });
        await auth.supabase.from('alert_triggers').update({ read: true }).eq('id', id).eq('user_id', auth.user.id);
        return Response.json({ success: true });
      }

      case 'mark_all_read': {
        await auth.supabase.from('alert_triggers').update({ read: true }).eq('user_id', auth.user.id).eq('read', false);
        return Response.json({ success: true });
      }

      default:
        return Response.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (e) {
    return Response.json({ success: false, error: e.message }, { status: 500 });
  }
}
