/**
 * POST /api/alerts/backtest
 * body: { symbol, type, threshold, timeframe, signalType, lookbackDays, forwardWindowHours }
 *
 * Simulates how an alert — as configured in the create form, before it's
 * even saved — would have performed over a historical window: how many
 * times it would have fired, and what happened to price in the following
 * `forwardWindowHours` after each fire.
 *
 * Reuses the exact same getMexcKlines/runMTFAnalysis functions AlertChecker
 * itself calls for the SMC-based types (rather than a separate
 * re-implementation), and mirrors evaluate()'s exact crossing/dedup logic
 * for price_above, price_below, smc_score_above, and smc_signal, so backtest
 * results stay consistent with how the live checker actually behaves.
 *
 * pct_change intentionally differs from a literal replay: the live checker
 * has no dedup for it (fires on every single 15s check cycle for as long as
 * |Δ24h%| stays over the threshold), which candle-by-candle would produce
 * hundreds of near-duplicate "fires" during any sustained move — not a
 * useful backtest metric. This groups consecutive qualifying candles into
 * one episode instead, using the same crossing pattern as the other types.
 *
 * ASSUMPTION TO VERIFY: this assumes getMexcKlines() returns objects shaped
 * like { time, open, high, low, close, volume } (matching PriceChart.jsx's
 * own parsing of raw MEXC klines). If lib/tools/integrations/MEXC.js
 * actually uses different field names, the `.time` / `.close` accesses
 * below need updating to match.
 */

import { createClient }       from '@supabase/supabase-js';
import { extractBearerToken } from '../../../../lib/security/middleware.js';
import { getMexcKlines }      from '../../../../lib/tools/integrations/MEXC.js';
import { runMTFAnalysis }     from '../../../../lib/analysis/SMCAnalyzer.js';
import { backtestPriceType, computeForwardOutcomes } from '../../../../lib/alerts/backtestEngine.js';

export const maxDuration = 60; // seconds — generous, well under the 300s Hobby ceiling

const VALID_TYPES    = ['price_above', 'price_below', 'pct_change', 'smc_signal', 'smc_score_above'];
const SMC_TIMEFRAMES = ['1h', '4h', '1d'];
const MEXC_INTERVAL  = { '15m': '15m', '1h': '60m', '4h': '4h', '1d': '1d' };
const TF_MINUTES     = { '15m': 15, '1h': 60, '4h': 240, '1d': 1440 };

const MAX_KLINES_PER_REQUEST = 1000; // conservative assumption for a single exchange API call
const MAX_SMC_SAMPLES        = 100;  // caps expensive runMTFAnalysis calls per backtest
const SMC_WARMUP_BARS        = 100;  // matches AlertChecker._getSmcAnalysis's own per-call window
const BACKTEST_RATE_LIMIT    = 10;   // per hour per user — each call can trigger up to 100 SMC evaluations + several MEXC fetches, so this is deliberately tighter than routine CRUD limits

export async function POST(request) {
  // This previously had no authentication at all — anyone on the internet
  // could trigger the full backtest workload (up to 100 runMTFAnalysis
  // calls plus multiple large MEXC kline fetches) with zero limit. Every
  // other write/compute-heavy route in this app requires auth; this one
  // was missed.
  const tk = extractBearerToken(request);
  if (!tk.valid) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: `Bearer ${tk.token}` } } },
  );
  const { data: { user }, error: authError } = await supabase.auth.getUser(tk.token);
  if (authError || !user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const { data: withinLimit, error: rlError } = await supabase.rpc('check_and_log_action_rate_limit', {
    p_action: 'alerts_backtest', p_limit: BACKTEST_RATE_LIMIT, p_window_minutes: 60,
  });
  if (rlError) return Response.json({ error: 'Rate limit check failed' }, { status: 500 });
  if (!withinLimit) {
    return Response.json(
      { error: `Rate limit reached (${BACKTEST_RATE_LIMIT} backtests/hour). Try again later.` },
      { status: 429 },
    );
  }

  try {
    const body = await request.json();
    const {
      symbol, type, threshold, timeframe = '4h', signalType,
      lookbackDays: reqLookbackDays = 30, forwardWindowHours = 24,
    } = body || {};

    if (!symbol || !type) {
      return Response.json({ error: 'symbol and type required' }, { status: 400 });
    }
    if (!VALID_TYPES.includes(type)) {
      return Response.json({ error: `Unknown type: ${type}` }, { status: 400 });
    }
    if (type !== 'smc_signal' && (threshold === undefined || threshold === null || threshold === '')) {
      return Response.json({ error: 'threshold required for this alert type' }, { status: 400 });
    }

    const lookbackDays = Math.min(Math.max(1, Number(reqLookbackDays) || 30), 90);
    const isSmc = type === 'smc_signal' || type === 'smc_score_above';
    // price_above/price_below/pct_change don't collect a timeframe in the
    // create form (it's nulled on create for those types) — use fine-grained
    // 15m candles for them, closer to the live checker's near-continuous
    // ticker-based evaluation than a slower display timeframe would be.
    const tf = isSmc ? timeframe : '15m';
    const tfMinutes = TF_MINUTES[tf] ?? 15;

    const desiredCandles = Math.ceil((lookbackDays * 24 * 60) / tfMinutes) + SMC_WARMUP_BARS;
    const candleLimit = Math.min(desiredCandles, MAX_KLINES_PER_REQUEST);

    const iv = MEXC_INTERVAL[tf] ?? tf;
    const candles = await getMexcKlines(symbol, iv, candleLimit);
    if (!candles?.length) {
      return Response.json({ error: 'No historical data returned for this symbol/timeframe' }, { status: 502 });
    }

    const actualLookbackDays = Math.max(
      1, Math.floor(((candles.length - SMC_WARMUP_BARS) * tfMinutes) / (24 * 60)),
    );

    // Warm-up offset before we start evaluating — SMC needs a full window for
    // meaningful swing/BOS detection; pct_change needs ~24h of prior bars to
    // compare against; price_above/below don't strictly need any but share
    // the same small buffer for simplicity.
    const warmupBars = isSmc
      ? Math.min(SMC_WARMUP_BARS, candles.length - 1)
      : Math.min(Math.max(1, Math.round((24 * 60) / tfMinutes)), candles.length - 1);

    const events = isSmc
      ? await backtestSmcType({
          type,
          threshold: threshold !== undefined && threshold !== null && threshold !== '' ? Number(threshold) : null,
          signalType, symbol, timeframe: tf, candles, startIdx: warmupBars,
        })
      : backtestPriceType({ type, threshold: Number(threshold), candles, startIdx: warmupBars, tfMinutes });

    // Forward-outcome for each fire
    const forwardCandleOffset = Math.max(1, Math.round((forwardWindowHours * 60) / tfMinutes));
    const results = computeForwardOutcomes(events, candles, forwardCandleOffset);

    const settled = results.filter(r => !r.pending);
    const withDirection = settled.filter(r => r.win !== null);
    const wins = withDirection.filter(r => r.win).length;
    const avgReturnPct = settled.length ? settled.reduce((s, r) => s + r.pctReturn, 0) / settled.length : null;
    const bestReturnPct  = settled.length ? Math.max(...settled.map(r => r.pctReturn)) : null;
    const worstReturnPct = settled.length ? Math.min(...settled.map(r => r.pctReturn)) : null;

    return Response.json({
      success: true,
      symbol, type, timeframe: tf,
      requestedLookbackDays: lookbackDays,
      actualLookbackDays,
      forwardWindowHours,
      totalFires: results.length,
      settledFires: settled.length,
      pendingFires: results.length - settled.length,
      winRate: withDirection.length ? (wins / withDirection.length) * 100 : null,
      avgReturnPct, bestReturnPct, worstReturnPct,
      events: results.map(r => ({
        time: r.time, price: r.price, message: r.message,
        outcome: r.outcome, pctReturn: r.pctReturn, win: r.win, pending: r.pending,
      })),
    });
  } catch (e) {
    console.error('[Backtest] failed:', e);
    return Response.json({ error: e.message }, { status: 500 });
  }
}

// ── Price-based types (price_above / price_below / pct_change) ──────────────
// ── SMC-based types (smc_signal / smc_score_above) ───────────────────────────
async function backtestSmcType({ type, threshold, signalType, symbol, timeframe, candles, startIdx }) {
  // runMTFAnalysis needs all three SMC timeframes — fetch the other two here
  // and slice all three by index/timestamp at each sampled point, simulating
  // "as of this point in time" exactly like AlertChecker._getSmcAnalysis does
  // for a live snapshot, just re-run repeatedly across history.
  const otherTfs = SMC_TIMEFRAMES.filter(t => t !== timeframe);
  const otherSeries = {};
  for (const tf of otherTfs) {
    const iv = MEXC_INTERVAL[tf] ?? tf;
    otherSeries[tf] = await getMexcKlines(symbol, iv, MAX_KLINES_PER_REQUEST);
  }

  const totalSteps = candles.length - startIdx;
  const sampleEvery = Math.max(1, Math.ceil(totalSteps / MAX_SMC_SAMPLES));

  const events = [];
  let lastScore = 0;
  let lastSigHash = null;

  for (let i = startIdx; i < candles.length; i += sampleEvery) {
    const asOfTime = candles[i].time;
    const klinesMap = { [timeframe]: candles.slice(0, i + 1).slice(-SMC_WARMUP_BARS) };

    let missingHistory = false;
    for (const tf of otherTfs) {
      const idx = findLastIndexAtOrBefore(otherSeries[tf], asOfTime);
      if (idx < 0) { missingHistory = true; break; }
      klinesMap[tf] = otherSeries[tf].slice(0, idx + 1).slice(-SMC_WARMUP_BARS);
    }
    if (missingHistory) continue;

    let an;
    try {
      an = await runMTFAnalysis(symbol, klinesMap);
    } catch {
      continue; // one bad sample point shouldn't fail the whole backtest
    }

    if (type === 'smc_score_above') {
      const score = an?.weightedScore ?? 0;
      const wasBelow = lastScore < threshold;
      if (wasBelow && score >= threshold) {
        events.push({
          index: i, time: asOfTime, price: candles[i].close,
          direction: null, // a score alone doesn't imply a directional bet
          message: `SMC score reached ${score}/100`,
        });
      }
      lastScore = score;
    } else { // smc_signal
      const sig = an?.timeframes?.[timeframe]?.signal;
      if (!sig || sig.type === 'NEUTRAL') continue;
      const matches = !signalType || sig.type === signalType;
      const sigHash = Math.round((sig.entry ?? 0) * 100);
      const isNew = lastSigHash !== sigHash;
      if (matches && isNew) {
        events.push({
          index: i, time: asOfTime, price: sig.entry ?? candles[i].close,
          direction: sig.type === 'LONG' ? 'bullish' : sig.type === 'SHORT' ? 'bearish' : null,
          message: `SMC ${sig.type} signal, entry ${typeof sig.entry === 'number' ? sig.entry.toFixed(4) : sig.entry}`,
        });
      }
      lastSigHash = sigHash;
    }
  }
  return events;
}

function findLastIndexAtOrBefore(series, time) {
  // series is chronological (ascending time) — linear scan is fine at this
  // scale (≤1000 candles, ≤100 sampled calls per backtest)
  let idx = -1;
  for (let j = 0; j < series.length; j++) {
    if (series[j].time <= time) idx = j; else break;
  }
  return idx;
}
