/**
 * GET /api/alerts/stream?token=<access_token>
 *
 * SSE stream that polls the user's active alerts every 15 seconds and
 * pushes `trigger` events when a condition fires. Also sends periodic
 * `heartbeat` events to keep the connection alive.
 *
 * Note: native browser EventSource cannot set custom headers, so auth
 * is passed via query param here (token-in-URL pattern, scoped to this
 * read-mostly polling endpoint only).
 *
 * Stream closes automatically after MAX_DURATION_MS to force client
 * reconnect (avoids unbounded serverless function runtime).
 *
 * IMPORTANT — Vercel duration limit: Hobby plans have a hard 300s ceiling
 * on function duration that no config can raise; Pro/Enterprise default to
 * 300s too unless `maxDuration` is raised explicitly (up to 800s). Without
 * this export, this route would run on the platform default and get killed
 * by a 504 FUNCTION_INVOCATION_TIMEOUT well before reaching a 10-minute
 * MAX_DURATION_MS. Keeping both at 300s/270s (with a margin) means our own
 * graceful close+reconnect always fires first, on every plan.
 */

import { createClient }   from '@supabase/supabase-js';
import { AlertChecker }   from '../../../../lib/alerts/AlertChecker.js';

export const maxDuration = 300; // seconds — Vercel Hobby's hard ceiling; safe on Pro/Enterprise too

const CHECK_INTERVAL_MS = 15_000;
const MAX_DURATION_MS   = 270_000; // 4.5 min — closes ~30s before the 300s platform limit, client auto-reconnects

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const token = searchParams.get('token');

  if (!token || token.split('.').length !== 3) {
    return new Response('Unauthorized', { status: 401 });
  }

  // Attach the token as the Authorization header so every .from() call made
  // by AlertChecker below runs under the user's identity (RLS requires this —
  // getUser(token) alone only validates the JWT, it doesn't attach it).
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: `Bearer ${token}` } } },
  );

  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    return new Response('Unauthorized', { status: 401 });
  }

  const checker = new AlertChecker(supabase, user.id);
  const encoder = new TextEncoder();
  const state   = { stopped: false }; // shared between start() and cancel()

  const stream = new ReadableStream({
    async start(controller) {
      const send = (event, data) => {
        try {
          controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
        } catch { /* controller may already be closed */ }
      };

      send('connected', { ts: Date.now() });

      const stopTimer = setTimeout(() => { state.stopped = true; }, MAX_DURATION_MS);

      const loop = async () => {
        while (!state.stopped) {
          try {
            const fired = await checker.runCycle();
            for (const f of fired) {
              send('trigger', {
                alertId: f.alert.id,
                symbol:  f.alert.symbol,
                type:    f.alert.type,
                message: f.message,
                triggerId: f.trigger?.id,
                ts: Date.now(),
              });
            }
          } catch (e) {
            send('error', { message: e.message });
          }

          send('heartbeat', { ts: Date.now() });

          // Sleep in small increments so we notice `state.stopped` promptly
          for (let waited = 0; waited < CHECK_INTERVAL_MS && !state.stopped; waited += 1000) {
            await new Promise(r => setTimeout(r, 1000));
          }
        }
        clearTimeout(stopTimer);
        send('closing', { reason: 'max_duration_reached' });
        try { controller.close(); } catch { /* already closed */ }
      };

      loop();
    },

    cancel() {
      // Client disconnected — signal the loop to stop on its next check
      state.stopped = true;
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type':      'text/event-stream',
      'Cache-Control':      'no-cache',
      'Connection':         'keep-alive',
      'X-Accel-Buffering':  'no',
    },
  });
}
