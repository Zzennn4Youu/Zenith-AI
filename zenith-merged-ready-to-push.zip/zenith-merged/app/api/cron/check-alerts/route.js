/**
 * /api/cron/check-alerts
 *
 * Triggered by an EXTERNAL scheduler (e.g. cron-job.org) every 1-2 minutes —
 * NOT by Vercel's own Cron Jobs, which cap Hobby-plan projects to once per
 * day (far too infrequent for price/SMC alerts). The route itself has no
 * frequency limit; only Vercel's built-in scheduler does. See the setup
 * note for how to configure the external scheduler.
 *
 * This is what makes alerts actually reach a user when no browser tab is
 * open: /api/alerts/stream only runs AlertChecker.runCycle() while an SSE
 * connection is active, which requires an open tab. This route runs
 * independently of that, for every user with at least one active alert, and
 * delivers Web Push notifications instead of (or in addition to) the
 * in-app SSE toast for whoever fires.
 *
 * Security: verifies a shared secret (CRON_SECRET) sent as a Bearer token
 * by the external scheduler — anyone hitting this URL without it is
 * rejected, since this route intentionally bypasses RLS with the
 * service-role key to read across ALL users.
 */

import { createClient }  from '@supabase/supabase-js';
import { AlertChecker }  from '../../../../lib/alerts/AlertChecker.js';
import { sendPushToUser } from '../../../../lib/push/sendPush.js';

export const maxDuration = 60; // seconds — generous but still well under the 300s Hobby ceiling

function buildPushPayload(fired) {
  const { alert, message } = fired;
  return {
    title: `🔔 ${alert.symbol} Alert`,
    body:  message,
    url:   '/', // deep-link into a specific view once the app supports it
    tag:   `alert-${alert.id}`,
  };
}

export async function GET(request) {
  const authHeader = request.headers.get('authorization');
  if (!process.env.CRON_SECRET || authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // Service-role client — deliberately bypasses RLS. This is a trusted,
  // secret-gated server job that needs to read across every user's alerts;
  // there is no per-user JWT available in a scheduled-job context. Each
  // AlertChecker call below still explicitly scopes its own queries by
  // `.eq('user_id', ...)`, so per-user isolation is enforced at the
  // application level even though RLS isn't the one doing it here.
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
  );

  try {
    const { data: rows, error } = await supabase
      .from('alerts')
      .select('user_id')
      .eq('status', 'active');

    if (error) throw new Error(error.message);

    const userIds = [...new Set((rows ?? []).map(r => r.user_id))];
    let totalFired = 0, totalPushSent = 0, totalPushFailed = 0;
    const perUserErrors = [];

    for (const userId of userIds) {
      try {
        const checker = new AlertChecker(supabase, userId);
        const fired = await checker.runCycle();
        totalFired += fired.length;

        for (const f of fired) {
          const { sent, failed } = await sendPushToUser(supabase, userId, buildPushPayload(f));
          totalPushSent += sent;
          totalPushFailed += failed;
        }
      } catch (e) {
        // One user's failure (bad data, transient API error) shouldn't stop
        // the rest of the batch from being checked.
        perUserErrors.push(`${userId}: ${e.message}`);
      }
    }

    return Response.json({
      success: true,
      usersChecked: userIds.length,
      alertsFired: totalFired,
      pushSent: totalPushSent,
      pushFailed: totalPushFailed,
      errors: perUserErrors,
    });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
