/**
 * /api/cron/expire-subscriptions
 *
 * Runs once daily via the same external scheduler as check-alerts. Two jobs:
 *
 *   1. Downgrade any 'paid' subscription whose expires_at has passed back to
 *      'free'. Not strictly required for correctness (resolveModelForUser
 *      already checks expires_at live on every request), but keeps
 *      user_subscriptions.tier an accurate reflection of who's currently
 *      paying, which matters for any reporting/analytics built on it later.
 *
 *   2. Send a Web Push reminder to subscriptions expiring within the next 2
 *      days that haven't renewed yet — QRIS/GoPay payments require the user
 *      to actively scan and pay each cycle (there's no silent auto-charge),
 *      so a reminder meaningfully reduces accidental non-renewal.
 */

import { createClient }   from '@supabase/supabase-js';
import { sendPushToUser } from '../../../../lib/push/sendPush.js';

export const maxDuration = 60;

export async function GET(request) {
  const authHeader = request.headers.get('authorization');
  if (!process.env.CRON_SECRET || authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
  );

  try {
    const now = new Date();
    const in2Days = new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000);

    // 1. Downgrade expired
    const { data: expired, error: expiredErr } = await supabase
      .from('user_subscriptions')
      .update({ tier: 'free', updated_at: now.toISOString() })
      .eq('tier', 'paid')
      .lt('expires_at', now.toISOString())
      .select('user_id');
    if (expiredErr) throw new Error(expiredErr.message);

    // 2. Remind expiring-soon (still paid, not yet expired, within window)
    const { data: expiringSoon, error: expiringErr } = await supabase
      .from('user_subscriptions')
      .select('user_id, expires_at')
      .eq('tier', 'paid')
      .gte('expires_at', now.toISOString())
      .lte('expires_at', in2Days.toISOString());
    if (expiringErr) throw new Error(expiringErr.message);

    let remindersSent = 0;
    for (const sub of expiringSoon ?? []) {
      const daysLeft = Math.max(1, Math.ceil((new Date(sub.expires_at) - now) / (24 * 60 * 60 * 1000)));
      const { sent } = await sendPushToUser(supabase, sub.user_id, {
        title: '⚡ Zenith Apex expiring soon',
        body: `Your subscription renews in ${daysLeft} day${daysLeft === 1 ? '' : 's'} — renew now to keep uninterrupted access.`,
        url: '/',
        tag: 'subscription-reminder',
      });
      remindersSent += sent;
    }

    return Response.json({
      success: true,
      downgraded: expired?.length ?? 0,
      remindersSent,
    });
  } catch (e) {
    console.error('[Cron expire-subscriptions] failed:', e);
    return Response.json({ error: e.message }, { status: 500 });
  }
}
